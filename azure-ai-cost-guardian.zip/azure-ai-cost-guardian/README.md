# Azure AI Cost Guardian

Tagline: Intelligent Model Routing for Zero-Waste AI Consumption

## Problem Statement
Many AI applications route all requests to expensive models, even when simpler requests can be handled by lower-cost tiers. This project introduces a transparent decision layer before model execution.

## MVP Objective
Build a local, explainable MVP that analyzes prompts, recommends logical model tiers, estimates cost impact, supports user override, and records privacy-conscious telemetry.

## High-Level Architecture
- Streamlit interface (Analyze and Route page + Savings Dashboard page)
- Request orchestration layer
- Deterministic prompt analysis and routing modules
- Cost estimation and comparison module
- Azure OpenAI client adapter and Demo responder adapter
- Local JSON telemetry storage

## Execution Modes
- Demo Mode: no Azure credentials required; synthetic outputs clearly labeled.
- Azure Mode: requires valid Azure OpenAI configuration and deployment mappings.

## Current Implementation Status
This repository currently includes Prompt 2 through Prompt 6C MVP progress.

Current mode:
- Demo Mode

Completed in the current stage:
- Prompt Analysis
- Token Estimation
- Complexity Scoring
- Routing Engine
- Cost Comparison Logic
- Demo Execution
- Azure OpenAI Integration
- Azure Mode
- Request Orchestration
- Telemetry
- Streamlit User Interface
- Customer-friendly experience redesign
- High-quality deterministic Demo Mode responses
- Automatic internal capability selection with one-click customer flow
- Explainable optimization message with administrator-only technical detail
- AI Usage Dashboard for governance visibility
- Dormant Azure integration code retained for future authorized testing

Still pending in this stage:
- Azure Deployment Validation

## Customer Value
Azure AI Cost Guardian helps organizations use the right level of AI capability for each workload, keeping routine requests efficient while reserving premium reasoning for complex business-critical work.

The current customer experience is intentionally simple: enter a request, select Get Result, read the generated result, and read one short optimization explanation. Internal routing mechanics, complexity scoring, confidence, token estimation, and policy detail remain available only in collapsed administrator-oriented technical details.

Demo presentation notes:
- Demo Mode results are deterministic local demonstrations with no live AI service call.
- The four built-in examples return curated deterministic responses for summarization, business email drafting, TLS vs mTLS explanation, and secure cloud architecture concepts.
- For non-curated prompts, Demo Mode returns a category-aligned demonstration response and clearly indicates that live AI integration is required for prompt-specific generated content.
- Sidebar labels are customer-facing: Cost Guardian and AI Usage Dashboard.

For the current hackathon phase:
- The prototype does not call a live Azure OpenAI resource.
- Responses are deterministic and synthetic.
- No API key is required.
- Azure setup is not required for the current demo.
- Live Azure integration remains a future enhancement requiring an approved resource, authentication method, and deployments.
- The prototype must not be represented as an official Microsoft product.

## Local Prerequisites
- Python 3.12
- pip

## Planned Local Installation Commands
```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Environment Variable Guidance
Copy .env.example to .env and provide local values as needed.

Key notes:
- APP_MODE=demo works without Azure credentials.
- APP_MODE=azure requires endpoint, API version, API key, and deployment mappings.
- Deployment mappings are Azure deployment names, not model family names.
- STORE_RAW_CONTENT must remain false in this MVP.

## Security and Privacy Principles
- Do not store secrets in source control.
- Do not persist raw prompts or generated responses in telemetry.
- Do not persist prompt hashes in MVP telemetry.
- Use safe, non-sensitive error reporting.

## Pricing Configuration Warning
The pricing configuration template intentionally uses null values for unverified rates.
Verified pricing must be supplied before presenting real cost comparisons.

## Project Structure
```text
azure-ai-cost-guardian/
├── app.py
├── config.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── pages/
├── config/
├── services/
├── models/
├── data/
└── tests/
```

## MVP Scope
In scope for MVP:
- Explainable routing logic
- Cost estimation from configurable pricing
- User override before execution
- Demo Mode + Azure Mode
- Privacy-conscious metadata telemetry

Out of scope for MVP:
- Terraform/Bicep
- CI/CD and cloud deployment automation
- Kubernetes/Redis/API Management
- Multi-agent orchestration
- Advanced anomaly detection
- Production-scale data platforms

## Future Roadmap
- Full Streamlit UX implementation
- Azure execution and telemetry persistence implementation
- Enhanced policy governance
- Optional Microsoft Entra authentication path

## Screenshots (Pending)
Screenshots will be added after UI implementation is complete.

## Azure Setup (Pending Implementation)
Detailed Azure setup instructions will be added when Azure integration is implemented.

## Disclaimer
This is an independent hackathon MVP and is not an official Microsoft product.
