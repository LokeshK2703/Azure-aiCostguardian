"""Project Story page — hackathon narrative, problem, approach, and impact."""

from __future__ import annotations

import streamlit as st

PAGE_TITLE = "Project Story"

SIDEBAR_CSS = """
<style>
[data-testid="stSidebarNav"] { display: none; }
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #001428 0%, #002b5e 100%);
    border-right: 1px solid #0050a0;
}
.cg-side-brand { padding: 0.65rem 0.5rem 0.6rem; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 0.7rem; }
.cg-side-brand-row { display: flex; align-items: center; gap: 0.45rem; margin-bottom: 0.18rem; }
.cg-side-brand-name { color: #ffffff; font-size: 0.8rem; font-weight: 700; }
.cg-side-brand-sub { color: #7ab8d9; font-size: 0.7rem; padding-left: 0.1rem; }
.cg-side-title { color: #7ab8d9; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 0.5rem; font-weight: 700; padding: 0 0.25rem; }
.cg-side-item { color: #c8dff0; font-size: 0.9rem; padding: 0.42rem 0.55rem; border-radius: 6px; margin-bottom: 0.22rem; }
.cg-side-item-active { background: rgba(0, 120, 212, 0.3); border: 1px solid rgba(0, 120, 212, 0.6); color: #ffffff; font-weight: 700; }
</style>
"""

PAGE_CSS = """
<style>
.stApp { background: #EEF4FB; color: #1e293b; }
.stApp h1, .stApp h2, .stApp h3, .stApp h4 { color: #001F3D !important; }
[data-testid="stMarkdownContainer"] p { color: #1e293b; }
[data-testid="stMarkdownContainer"] li { color: #1e293b; }
[data-testid="stMarkdownContainer"] { color: #1e293b; }
[data-testid="stCaptionContainer"] { color: #475569 !important; }
.story-hero {
    background: linear-gradient(135deg, #001428 0%, #002b5e 55%, #0050a0 100%);
    color: #ffffff;
    border-radius: 12px;
    border: 1px solid #0078D4;
    padding: 1.5rem 1.6rem;
    margin-bottom: 1.2rem;
    box-shadow: 0 4px 18px rgba(0, 120, 212, 0.22);
}
.story-hero-title { font-size: 1.5rem; font-weight: 800; margin-bottom: 0.25rem; letter-spacing: -0.02em; }
.story-hero-sub { color: #a8d4f5; font-size: 0.9rem; line-height: 1.5; }
.story-card {
    border: 1px solid #C7DEF8;
    border-radius: 10px;
    background: #ffffff;
    padding: 1.2rem 1.3rem;
    margin-bottom: 1rem;
    box-shadow: 0 1px 5px rgba(0,120,212,0.06);
}
.story-card-accent {
    border-left: 4px solid #0078D4;
}
.story-card-green {
    border-left: 4px solid #107C10;
}
.story-card-purple {
    border-left: 4px solid #5C2D91;
}
.story-card-title {
    font-size: 1rem;
    font-weight: 800;
    color: #001F3D;
    margin-bottom: 0.7rem;
}
.story-section-label {
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #0078D4;
    margin-bottom: 0.5rem;
}
.problem-stat {
    background: #FFF8F0;
    border: 1px solid #FFD9A0;
    border-radius: 8px;
    padding: 0.85rem 1rem;
    margin-bottom: 0.6rem;
}
.problem-stat-value { font-size: 1.6rem; font-weight: 800; color: #C45000; }
.problem-stat-label { font-size: 0.85rem; color: #6B4800; margin-top: 0.1rem; }
.outcome-item {
    display: flex;
    align-items: flex-start;
    gap: 0.55rem;
    padding: 0.5rem 0;
    border-bottom: 1px solid #EEF2F7;
    font-size: 0.88rem;
    color: #1e293b;
}
.outcome-icon { flex-shrink: 0; font-size: 1rem; }
.timeline-item {
    display: flex;
    gap: 0.75rem;
    margin-bottom: 0.8rem;
    align-items: flex-start;
}
.timeline-dot {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: #0078D4;
    color: white;
    font-size: 0.75rem;
    font-weight: 800;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    margin-top: 0.1rem;
}
.timeline-content-title { font-size: 0.9rem; font-weight: 800; color: #001F3D; }
.timeline-content-desc { font-size: 0.83rem; color: #475569; margin-top: 0.1rem; }
.impact-number {
    text-align: center;
    padding: 0.9rem 0.5rem;
    border: 1px solid #C7DEF8;
    border-radius: 10px;
    background: #ffffff;
}
.impact-number-value { font-size: 1.8rem; font-weight: 800; color: #0078D4; }
.impact-number-label { font-size: 0.8rem; color: #475569; font-weight: 600; margin-top: 0.15rem; }
</style>
"""


def _render_sidebar() -> None:
    st.markdown(SIDEBAR_CSS, unsafe_allow_html=True)
    if hasattr(st, "page_link"):
        with st.sidebar:
            st.markdown(
                """
                <div class="cg-side-brand">
                    <div class="cg-side-brand-row">
                        <svg width="16" height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <rect x="0" y="0" width="9" height="9" fill="#F25022"/>
                            <rect x="11" y="0" width="9" height="9" fill="#7FBA00"/>
                            <rect x="0" y="11" width="9" height="9" fill="#00A4EF"/>
                            <rect x="11" y="11" width="9" height="9" fill="#FFB900"/>
                        </svg>
                        <span class="cg-side-brand-name">Microsoft</span>
                    </div>
                    <div class="cg-side-brand-sub">Azure AI Foundry</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.markdown('<div class="cg-side-title">Navigation</div>', unsafe_allow_html=True)
            try:
                st.page_link("app.py", label="💬 Chat & Analyze")
                st.page_link("pages/1_Savings_Dashboard.py", label="📊 AI Usage Dashboard")
                st.page_link("pages/2_Architecture.py", label="🏗 Architecture")
                st.markdown('<div class="cg-side-item cg-side-item-active">📖 Project Story</div>', unsafe_allow_html=True)
                st.page_link("pages/4_About.py", label="ℹ️ About")
            except Exception:
                st.caption("💬 Chat & Analyze")
                st.caption("📊 AI Usage Dashboard")
                st.caption("🏗 Architecture")
                st.markdown('<div class="cg-side-item cg-side-item-active">📖 Project Story</div>', unsafe_allow_html=True)
                st.caption("ℹ️ About")


def main() -> None:
    st.set_page_config(page_title=f"{PAGE_TITLE} — Azure AI Cost Guardian", layout="wide")
    _render_sidebar()
    st.markdown(PAGE_CSS, unsafe_allow_html=True)

    st.markdown(
        """
        <div class="story-hero">
            <div style="display:flex;align-items:center;gap:0.6rem;margin-bottom:0.55rem;">
                <svg width="18" height="18" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0">
                    <rect x="0" y="0" width="9" height="9" fill="#F25022"/>
                    <rect x="11" y="0" width="9" height="9" fill="#7FBA00"/>
                    <rect x="0" y="11" width="9" height="9" fill="#00A4EF"/>
                    <rect x="11" y="11" width="9" height="9" fill="#FFB900"/>
                </svg>
                <span style="color:rgba(255,255,255,0.75);font-size:0.78rem;font-weight:600;">Microsoft · Azure AI Foundry · Hackathon 2026</span>
            </div>
            <div class="story-hero-title">📖 Project Story</div>
            <div class="story-hero-sub">
                Why we built Azure AI Cost Guardian — the problem, the approach, the solution, and what it means for enterprise AI adoption.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    col1, col2 = st.columns([1.1, 1])

    with col1:
        # Problem
        st.markdown('<div class="story-card story-card-accent">', unsafe_allow_html=True)
        st.markdown('<div class="story-card-title">🔍 The Problem</div>', unsafe_allow_html=True)
        st.markdown('<div class="story-section-label">The hidden cost of defaulting to premium AI</div>', unsafe_allow_html=True)
        st.markdown(
            """
            Most enterprise AI applications route **every request to the most powerful — and most expensive — model available**, regardless of what the task actually requires.

            Asking GPT-5.4 to summarise a three-line meeting note is like hiring a surgeon to apply a bandage. The result is the same, but the cost is vastly different.

            This creates three compounding problems for organisations:
            - **Runaway AI spend** with no visibility into where cost is generated
            - **No governance layer** between users and expensive model capacity
            - **No audit trail** to justify AI consumption to FinOps or compliance teams
            """,
            unsafe_allow_html=True,
        )
        st.markdown(
            """
            <div class="problem-stat">
                <div class="problem-stat-value">60 – 80%</div>
                <div class="problem-stat-label">of enterprise AI requests are routine tasks that do not require premium model reasoning capacity.</div>
            </div>
            <div class="problem-stat">
                <div class="problem-stat-value">~25×</div>
                <div class="problem-stat-label">cost difference between an economy-tier model and a premium-tier model for the same routine output.</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.markdown("</div>", unsafe_allow_html=True)

        # Approach
        st.markdown('<div class="story-card story-card-accent">', unsafe_allow_html=True)
        st.markdown('<div class="story-card-title">⚡ Our Approach</div>', unsafe_allow_html=True)
        st.markdown('<div class="story-section-label">Intelligent routing — not model replacement</div>', unsafe_allow_html=True)
        st.markdown(
            """
            Azure AI Cost Guardian sits as a **transparent governance layer** between users and Azure OpenAI. It does not change what users can ask — it changes *which model answers*.

            The routing decision is:
            - **Deterministic** — same input always produces the same routing decision
            - **Explainable** — every decision has a reason visible to the user
            - **Configurable** — thresholds, weights, and tier mappings are policy-driven
            - **Privacy-safe** — prompt and response content are never stored
            """,
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        # How we built it
        st.markdown('<div class="story-card story-card-purple">', unsafe_allow_html=True)
        st.markdown('<div class="story-card-title">🛠 How We Built It</div>', unsafe_allow_html=True)
        st.markdown('<div class="story-section-label">Built on Azure AI Foundry in a single hackathon sprint</div>', unsafe_allow_html=True)
        timeline = [
            ("1", "Defined the routing policy", "9 weighted signal dimensions, 3 complexity tiers, configurable thresholds stored as versioned JSON."),
            ("2", "Built the prompt analyser", "Fully deterministic keyword-based classifier — no ML model needed. Fast, explainable, zero latency overhead."),
            ("3", "Deployed 3 GPT-5.4 models", "routine-model (nano), balanced-model (mini), premium-model (full) via Azure AI Foundry — Global Standard."),
            ("4", "Wired the Azure OpenAI client", "Full error-category mapping, timeout handling, usage token extraction."),
            ("5", "Added telemetry and cost tracking", "Privacy-safe atomic writes. Estimated vs actual cost comparison per request."),
            ("6", "Built the Streamlit UI", "5-page app — Chat, Dashboard, Architecture, Story, About — with Microsoft/Azure brand design."),
        ]
        for num, title, desc in timeline:
            st.markdown(
                f"""
                <div class="timeline-item">
                    <div class="timeline-dot">{num}</div>
                    <div>
                        <div class="timeline-content-title">{title}</div>
                        <div class="timeline-content-desc">{desc}</div>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        st.markdown("</div>", unsafe_allow_html=True)

        # Impact
        st.markdown('<div class="story-card story-card-green">', unsafe_allow_html=True)
        st.markdown('<div class="story-card-title">📈 Impact & Outcomes</div>', unsafe_allow_html=True)
        st.markdown('<div class="story-section-label">What Cost Guardian delivers for enterprise teams</div>', unsafe_allow_html=True)

        imp_cols = st.columns(3)
        imp_cols[0].markdown('<div class="impact-number"><div class="impact-number-value">3</div><div class="impact-number-label">Live GPT-5.4 model tiers</div></div>', unsafe_allow_html=True)
        imp_cols[1].markdown('<div class="impact-number"><div class="impact-number-value">9</div><div class="impact-number-label">Routing signal dimensions</div></div>', unsafe_allow_html=True)
        imp_cols[2].markdown('<div class="impact-number"><div class="impact-number-value">0</div><div class="impact-number-label">Prompts stored in telemetry</div></div>', unsafe_allow_html=True)

        outcomes = [
            ("💰", "Significant cost reduction for routine AI workloads routed away from premium capacity."),
            ("📊", "Full audit trail of every AI request — tier used, cost, latency, complexity score."),
            ("🔒", "Privacy-by-design: no prompt or response content ever written to disk."),
            ("⚙️", "Policy-driven routing that FinOps and compliance teams can review and adjust."),
            ("🚀", "Zero code changes needed in consuming applications — drop-in routing layer."),
            ("📖", "Every routing decision is explainable — users see why a tier was selected."),
        ]
        for icon, text in outcomes:
            st.markdown(
                f'<div class="outcome-item"><span class="outcome-icon">{icon}</span><span>{text}</span></div>',
                unsafe_allow_html=True,
            )
        st.markdown("</div>", unsafe_allow_html=True)

    st.caption("Azure AI Cost Guardian · Hackathon Prototype · Not an official Microsoft product.")


if __name__ == "__main__":
    main()
