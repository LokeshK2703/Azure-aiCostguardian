"""Administrator-focused AI usage dashboard for Azure AI Cost Guardian."""

from __future__ import annotations

from collections import Counter
from decimal import Decimal

import plotly.express as px
import streamlit as st

from config import load_app_config
from models.enums import ComplexityLevel, LogicalTier, ValueOrigin
from models.response_models import TelemetryRecord
from services.telemetry import read_telemetry_records
from ui.presentation import complexity_descriptor

APP_TITLE = "AI Usage Dashboard"
APP_SUBTITLE = "See how Cost Guardian allocates AI capacity across requests."


def _render_sidebar_navigation() -> None:
    st.markdown(
        """
        <style>
        [data-testid="stSidebarNav"] { display: none; }
        [data-testid="stSidebar"] {
            background: linear-gradient(180deg, #001428 0%, #002b5e 100%);
            border-right: 1px solid #0050a0;
        }
        .cg-side-brand {
            padding: 0.65rem 0.5rem 0.6rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 0.7rem;
        }
        .cg-side-brand-row {
            display: flex;
            align-items: center;
            gap: 0.45rem;
            margin-bottom: 0.18rem;
        }
        .cg-side-brand-name {
            color: #ffffff;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.02em;
        }
        .cg-side-brand-sub {
            color: #7ab8d9;
            font-size: 0.7rem;
            padding-left: 0.1rem;
        }
        .cg-side-title {
            color: #7ab8d9;
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            margin-bottom: 0.5rem;
            font-weight: 700;
            padding: 0 0.25rem;
        }
        .cg-side-item {
            color: #c8dff0;
            font-size: 0.9rem;
            padding: 0.42rem 0.55rem;
            border-radius: 6px;
            margin-bottom: 0.22rem;
        }
        .cg-side-item-active {
            background: rgba(0, 120, 212, 0.3);
            border: 1px solid rgba(0, 120, 212, 0.6);
            color: #ffffff;
            font-weight: 700;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )
    if hasattr(st, "page_link"):
        with st.sidebar:
            st.markdown(
                """
                <div class="cg-side-brand">
                    <div class="cg-side-brand-row">
                        <svg width="16" height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <rect x="0" y="0" width="9" height="9" fill="#F25022"/>
                            <rect x="11" y="0" width="9" height="9" fill="#7FBA00"/>
                            <rect x="0" y="11" width="9" height="9" fill="#00A4EF"/>
                            <rect x="11" y="11" width="9" height="9" fill="#FFB900"/>
                        </svg>
                        <span class="cg-side-brand-name">Microsoft</span>
                    </div>
                    <div class="cg-side-brand-sub">Azure AI Foundry</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.markdown('<div class="cg-side-title">Navigation</div>', unsafe_allow_html=True)
            try:
                st.page_link("app.py", label="💬 Chat & Analyze")
                st.markdown('<div class="cg-side-item cg-side-item-active">📊 AI Usage Dashboard</div>', unsafe_allow_html=True)
                st.page_link("pages/2_Architecture.py", label="🏗 Architecture")
                st.page_link("pages/3_Project_Story.py", label="📖 Project Story")
                st.page_link("pages/4_About.py", label="ℹ️ About")
            except Exception:
                st.caption("💬 Chat & Analyze")
                st.markdown('<div class="cg-side-item cg-side-item-active">📊 AI Usage Dashboard</div>', unsafe_allow_html=True)
                st.caption("🏗 Architecture")
                st.caption("📖 Project Story")
                st.caption("ℹ️ About")


def _load_config():
    return load_app_config(allow_unverified_pricing_preview=True)


def _bucket_records_by_day(records: list[TelemetryRecord]) -> list[dict[str, int]]:
    counts: dict[str, int] = {}
    for record in sorted(records, key=lambda item: item.timestamp_utc):
        bucket = record.timestamp_utc.strftime("%Y-%m-%d")
        counts[bucket] = counts.get(bucket, 0) + 1
    return [{"date": key, "workloads": value} for key, value in counts.items()]


def _complexity_distribution(records: list[TelemetryRecord]) -> list[dict[str, int]]:
    ordered_levels = [ComplexityLevel.LOW, ComplexityLevel.MEDIUM, ComplexityLevel.HIGH]
    counts = Counter(record.complexity_level for record in records)
    return [{"assessment": complexity_descriptor(level), "workloads": counts.get(level, 0)} for level in ordered_levels]


def _pricing_is_available(records: list[TelemetryRecord]) -> bool:
    return any(record.estimated_savings_amount is not None for record in records)


def _actual_pricing_is_available(records: list[TelemetryRecord]) -> bool:
    return any(record.actual_savings_amount is not None for record in records)


def _sum_decimal(values: list[Decimal | None]) -> Decimal:
    total = Decimal("0")
    for value in values:
        if value is not None:
            total += value
    return total


def _tier_counts(records: list[TelemetryRecord]) -> Counter[LogicalTier]:
    return Counter(record.executed_tier for record in records)


def main() -> None:
    st.set_page_config(page_title=APP_TITLE, layout="wide")
    _render_sidebar_navigation()
    config = _load_config()
    records = read_telemetry_records(config.runtime.TELEMETRY_FILE_PATH)

    # ── Dark theme styles ────────────────────────────────────────────────────
    st.markdown(
        """
        <style>
        /* Base */
        .stApp { background: #0A0E1A !important; color: #F0F6FF; }
        .stApp h1, .stApp h2, .stApp h3,
        .stApp h4, .stApp h5, .stApp h6 { color: #F0F6FF !important; }
        [data-testid="stMarkdownContainer"] p  { color: #C8D8EC; }
        [data-testid="stMarkdownContainer"]    { color: #C8D8EC; }
        [data-testid="stCaptionContainer"]     { color: #8BAAC8 !important; }

        /* Metrics */
        .stMetric label                         { color: #8BAAC8 !important; }
        .stMetric [data-testid="stMetricValue"] { color: #F0F6FF !important; }

        /* Container borders */
        [data-testid="stVerticalBlockBorderWrapper"] > div {
            background: rgba(255,255,255,0.03) !important;
            border-color: rgba(255,255,255,0.09) !important;
        }

        /* ── Hero bar ── */
        .dash-hero {
            background: linear-gradient(135deg, #050C1C 0%, #0D1B35 55%, #0A2A5E 100%);
            border: 1px solid rgba(0,120,212,0.45);
            border-radius: 14px;
            padding: 1.4rem 1.6rem;
            margin-bottom: 1.2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            box-shadow: 0 8px 32px rgba(0,120,212,0.18), 0 0 0 1px rgba(80,230,255,0.06);
            position: relative;
            overflow: hidden;
        }
        .dash-hero::before {
            content: "";
            position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background: radial-gradient(ellipse at 15% 50%, rgba(0,120,212,0.12) 0%, transparent 60%),
                        radial-gradient(ellipse at 85% 50%, rgba(80,230,255,0.06) 0%, transparent 60%);
            pointer-events: none;
        }
        .dash-hero-left  { display: flex; align-items: center; gap: 1rem; position: relative; }
        .dash-hero-right { display: flex; align-items: center; gap: 0.55rem; position: relative; }
        .dash-hero-icon {
            width: 46px; height: 46px; border-radius: 10px;
            background: rgba(0,120,212,0.25);
            border: 1px solid rgba(80,230,255,0.35);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.3rem; flex-shrink: 0;
            box-shadow: 0 0 16px rgba(80,230,255,0.15);
        }
        .dash-hero-title { font-size: 1.35rem; font-weight: 800; color: #F0F6FF; margin: 0; letter-spacing: -0.02em; }
        .dash-hero-sub   { font-size: 0.82rem; color: #8BAAC8; margin-top: 0.12rem; }
        .dash-hero-chip  {
            display: inline-flex; align-items: center; gap: 0.3rem;
            border: 1px solid rgba(255,255,255,0.15); border-radius: 999px;
            padding: 0.22rem 0.65rem; font-size: 0.72rem;
            color: rgba(255,255,255,0.75); background: rgba(255,255,255,0.07);
            font-weight: 600; letter-spacing: 0.02em;
        }
        .dash-badge-live {
            display: inline-flex; align-items: center; gap: 0.3rem;
            border: 1px solid rgba(74,222,128,0.55); border-radius: 999px;
            padding: 0.22rem 0.75rem; font-size: 0.72rem;
            color: #86EFAC; background: rgba(22,101,52,0.35);
            font-weight: 700; letter-spacing: 0.03em;
        }
        .dash-badge-demo {
            display: inline-flex; align-items: center; gap: 0.3rem;
            border: 1px solid rgba(255,255,255,0.2); border-radius: 999px;
            padding: 0.22rem 0.75rem; font-size: 0.72rem;
            color: #94A3B8; background: rgba(255,255,255,0.07);
            font-weight: 700; letter-spacing: 0.03em;
        }

        /* ── Page subtitle band ── */
        .dash-sub-band {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.07);
            border-radius: 10px;
            padding: 0.9rem 1.25rem;
            margin-bottom: 1.1rem;
            display: flex; align-items: center; gap: 1rem;
        }
        .dash-page-title { font-size: 1.55rem; font-weight: 800; color: #F0F6FF; letter-spacing: -0.02em; }
        .dash-page-sub   { font-size: 0.9rem; color: #8BAAC8; margin-top: 0.1rem; }

        /* ── KPI metric cards ── */
        [data-testid="stMetric"] {
            border: 1px solid rgba(255,255,255,0.09);
            border-radius: 12px;
            background: rgba(255,255,255,0.04);
            padding: 1rem 1rem;
            box-shadow: none;
            min-height: 110px;
            position: relative;
            overflow: hidden;
        }
        [data-testid="stMetricLabel"] { font-size: 0.82rem; font-weight: 600; color: #8BAAC8 !important; }
        [data-testid="stMetricValue"] { font-size: 1.9rem; font-weight: 800; color: #F0F6FF !important; }

        /* Colored top borders per KPI */
        .kpi-total  [data-testid="stMetric"] { border-top: 3px solid #0078D4 !important; }
        .kpi-eco    [data-testid="stMetric"] { border-top: 3px solid #4ADE80 !important; }
        .kpi-bal    [data-testid="stMetric"] { border-top: 3px solid #60A5FA !important; }
        .kpi-prem   [data-testid="stMetric"] { border-top: 3px solid #A78BFA !important; }
        .kpi-spend  [data-testid="stMetric"] { border-top: 3px solid #0078D4 !important; }
        .kpi-base   [data-testid="stMetric"] { border-top: 3px solid #8BAAC8 !important; }
        .kpi-save   [data-testid="stMetric"] { border-top: 3px solid #4ADE80 !important; }

        /* ── Empty state ── */
        .dash-empty {
            border: 1px dashed rgba(0,120,212,0.35);
            border-radius: 12px;
            background: rgba(0,120,212,0.05);
            padding: 2rem 1rem;
            text-align: center;
            color: #8BAAC8;
        }
        .dash-empty-icon  { font-size: 1.6rem; margin-bottom: 0.5rem; }
        .dash-empty-title { font-size: 1.05rem; font-weight: 700; color: #C8D8EC; margin-bottom: 0.2rem; }
        .dash-empty-sub   { font-size: 0.9rem; }

        /* ── Chart containers ── */
        .dash-chart-card {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 12px;
            padding: 1.1rem 1.2rem 0.6rem;
            margin-bottom: 1rem;
        }
        .dash-chart-title {
            font-size: 0.95rem; font-weight: 700; color: #F0F6FF;
            margin-bottom: 0.15rem;
        }
        .dash-chart-sub {
            font-size: 0.78rem; color: #8BAAC8;
            margin-bottom: 0.7rem;
        }

        /* ── Section label ── */
        .dash-section-label {
            font-size: 0.72rem; color: #8BAAC8; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.1em;
            margin-bottom: 0.55rem; margin-top: 1rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    # ── Hero bar ─────────────────────────────────────────────────────────────
    _app_mode = config.runtime.APP_MODE
    _ms_logo = (
        '<svg width="18" height="18" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"'
        ' style="display:inline-block;vertical-align:middle;flex-shrink:0">'
        '<rect x="0" y="0" width="9" height="9" fill="#F25022"/>'
        '<rect x="11" y="0" width="9" height="9" fill="#7FBA00"/>'
        '<rect x="0" y="11" width="9" height="9" fill="#00A4EF"/>'
        '<rect x="11" y="11" width="9" height="9" fill="#FFB900"/>'
        "</svg>"
    )
    _azure_logo = (
        '<svg width="14" height="14" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"'
        ' style="display:inline-block;vertical-align:middle;flex-shrink:0">'
        '<path d="M13.2 2.2L3.8 18.6h7.1l2.3-4 3.7 6.4h7.1z" fill="#50E6FF"/>'
        "</svg>"
    )
    from models.enums import AppMode as _AppMode
    _badge = (
        '<span class="dash-badge-live">⚡ Azure Live</span>'
        if _app_mode == _AppMode.AZURE
        else '<span class="dash-badge-demo">Demo Mode</span>'
    )
    st.markdown(
        f"""
        <div class="dash-hero">
            <div class="dash-hero-left">
                {_ms_logo}
                <div class="dash-hero-icon">🛡️</div>
                <div>
                    <div class="dash-hero-title">Azure AI Cost Guardian</div>
                    <div class="dash-hero-sub">Use the Right AI. Not the Most Expensive One.</div>
                </div>
            </div>
            <div class="dash-hero-right">
                <span class="dash-hero-chip">{_azure_logo}&nbsp;Azure AI Foundry</span>
                {_badge}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ── Page title ────────────────────────────────────────────────────────────
    st.markdown(
        f"""
        <div class="dash-sub-band">
            <div>
                <div class="dash-page-title">📊 {APP_TITLE}</div>
                <div class="dash-page-sub">{APP_SUBTITLE}</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ── Empty state ───────────────────────────────────────────────────────────
    if not records:
        st.markdown(
            """
            <div class="dash-empty">
                <div class="dash-empty-icon">📄 → ⚡ → ✅</div>
                <div class="dash-empty-title">No requests analyzed yet.</div>
                <div class="dash-empty-sub">Submit a request on the Chat page to see optimization insights here.</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        return

    tier_counts = _tier_counts(records)

    # ── KPI metrics — tier counts ─────────────────────────────────────────────
    st.markdown('<div class="dash-section-label">Request Volume by Tier</div>', unsafe_allow_html=True)
    kpi_cols = st.columns(4)
    with kpi_cols[0]:
        st.markdown('<div class="kpi-total">', unsafe_allow_html=True)
        st.metric("📋 Requests Processed", f"{len(records)}")
        st.markdown("</div>", unsafe_allow_html=True)
    with kpi_cols[1]:
        st.markdown('<div class="kpi-eco">', unsafe_allow_html=True)
        st.metric("⚡ Cost-Efficient Selections", f"{tier_counts.get(LogicalTier.ECONOMY, 0)}")
        st.markdown("</div>", unsafe_allow_html=True)
    with kpi_cols[2]:
        st.markdown('<div class="kpi-bal">', unsafe_allow_html=True)
        st.metric("⚖️ Standard Selections", f"{tier_counts.get(LogicalTier.BALANCED, 0)}")
        st.markdown("</div>", unsafe_allow_html=True)
    with kpi_cols[3]:
        st.markdown('<div class="kpi-prem">', unsafe_allow_html=True)
        st.metric("🧠 Premium Selections", f"{tier_counts.get(LogicalTier.ADVANCED, 0)}")
        st.markdown("</div>", unsafe_allow_html=True)

    # ── KPI metrics — spend (if available) ───────────────────────────────────
    if _actual_pricing_is_available(records):
        st.markdown('<div class="dash-section-label">Actual Spend</div>', unsafe_allow_html=True)
        actual_cols = st.columns(3)
        with actual_cols[0]:
            st.markdown('<div class="kpi-spend">', unsafe_allow_html=True)
            st.metric(
                "💵 Actual Routed Spend",
                f"${_sum_decimal([record.actual_routed_cost for record in records]):.6f}",
            )
            st.markdown("</div>", unsafe_allow_html=True)
        with actual_cols[1]:
            st.markdown('<div class="kpi-base">', unsafe_allow_html=True)
            st.metric(
                "💰 Actual Premium Spend",
                f"${_sum_decimal([record.actual_baseline_cost for record in records]):.6f}",
            )
            st.markdown("</div>", unsafe_allow_html=True)
        with actual_cols[2]:
            st.markdown('<div class="kpi-save">', unsafe_allow_html=True)
            st.metric(
                "✅ Actual Savings",
                f"${_sum_decimal([record.actual_savings_amount for record in records]):.6f}",
            )
            st.markdown("</div>", unsafe_allow_html=True)

    # ── Charts row 1 ─────────────────────────────────────────────────────────
    st.markdown('<div class="dash-section-label">Capacity & Volume Analytics</div>', unsafe_allow_html=True)
    chart_cols = st.columns(2)

    with chart_cols[0]:
        st.markdown(
            '<div class="dash-chart-card">'
            '<div class="dash-chart-title">AI Capability Allocation</div>'
            '<div class="dash-chart-sub">Distribution of requests across Economy, Standard, and Premium tiers</div>',
            unsafe_allow_html=True,
        )
        tier_data = [
            {"Capacity": "Cost-Efficient", "requests": tier_counts.get(LogicalTier.ECONOMY, 0)},
            {"Capacity": "Standard",       "requests": tier_counts.get(LogicalTier.BALANCED, 0)},
            {"Capacity": "Premium",        "requests": tier_counts.get(LogicalTier.ADVANCED, 0)},
        ]
        fig = px.pie(
            tier_data,
            names="requests",
            values="requests",
            color="Capacity",
            color_discrete_map={
                "Cost-Efficient": "#4ADE80",
                "Standard":       "#60A5FA",
                "Premium":        "#A78BFA",
            },
            template="plotly_dark",
            hole=0.42,
        )
        fig.update_traces(
            textinfo="label+percent",
            textfont_size=12,
            marker=dict(line=dict(color="#0A0E1A", width=2)),
        )
        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            legend=dict(font=dict(color="#8BAAC8", size=11)),
            margin=dict(t=8, b=8, l=8, r=8),
            height=280,
        )
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with chart_cols[1]:
        st.markdown(
            '<div class="dash-chart-card">'
            '<div class="dash-chart-title">Request Volume Over Time</div>'
            '<div class="dash-chart-sub">Daily workload count showing usage trends</div>',
            unsafe_allow_html=True,
        )
        time_data = _bucket_records_by_day(records)
        fig = px.line(
            time_data,
            x="date",
            y="workloads",
            markers=True,
            template="plotly_dark",
        )
        fig.update_traces(
            line=dict(color="#0078D4", width=2.5),
            marker=dict(color="#50E6FF", size=7, line=dict(color="#0A0E1A", width=1.5)),
        )
        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis=dict(
                title="Date",
                gridcolor="rgba(255,255,255,0.05)",
                color="#8BAAC8",
                title_font=dict(color="#8BAAC8", size=11),
            ),
            yaxis=dict(
                title="Workloads",
                gridcolor="rgba(255,255,255,0.05)",
                color="#8BAAC8",
                title_font=dict(color="#8BAAC8", size=11),
            ),
            margin=dict(t=8, b=8, l=8, r=8),
            height=280,
        )
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    # ── Charts row 2 ─────────────────────────────────────────────────────────
    st.markdown('<div class="dash-section-label">Complexity & Cost Avoidance</div>', unsafe_allow_html=True)
    chart_cols2 = st.columns(2)

    with chart_cols2[0]:
        st.markdown(
            '<div class="dash-chart-card">'
            '<div class="dash-chart-title">Workload Complexity Distribution</div>'
            '<div class="dash-chart-sub">Breakdown of requests by assessed complexity level</div>',
            unsafe_allow_html=True,
        )
        complexity_data = _complexity_distribution(records)
        fig = px.bar(
            complexity_data,
            x="assessment",
            y="workloads",
            color="assessment",
            color_discrete_map={
                "Routine":  "#4ADE80",
                "Moderate": "#FBBF24",
                "Complex":  "#A78BFA",
            },
            template="plotly_dark",
        )
        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            showlegend=False,
            xaxis=dict(
                title="Complexity",
                gridcolor="rgba(255,255,255,0.04)",
                color="#8BAAC8",
                title_font=dict(color="#8BAAC8", size=11),
            ),
            yaxis=dict(
                title="Workloads",
                gridcolor="rgba(255,255,255,0.05)",
                color="#8BAAC8",
                title_font=dict(color="#8BAAC8", size=11),
            ),
            bargap=0.35,
            margin=dict(t=8, b=8, l=8, r=8),
            height=280,
        )
        fig.update_traces(marker_line_color="rgba(0,0,0,0)", marker_line_width=0)
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with chart_cols2[1]:
        if not _pricing_is_available(records):
            st.markdown(
                '<div class="dash-chart-card" style="display:flex;align-items:center;justify-content:center;min-height:320px;">'
                '<div style="text-align:center;color:#8BAAC8;">'
                '<div style="font-size:1.4rem;margin-bottom:0.4rem">💰</div>'
                '<div style="font-weight:700;color:#C8D8EC;margin-bottom:0.2rem">Cost Reporting Pending</div>'
                '<div style="font-size:0.85rem">Cost reporting will be enabled after approved pricing is configured.</div>'
                "</div></div>",
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                '<div class="dash-chart-card">'
                '<div class="dash-chart-title">Estimated Cost Avoidance</div>'
                '<div class="dash-chart-sub">Per-request savings achieved through intelligent tier selection</div>',
                unsafe_allow_html=True,
            )
            savings_points = [
                {
                    "date": record.timestamp_utc.strftime("%Y-%m-%d"),
                    "estimated_cost_avoidance": float(record.estimated_savings_amount or 0),
                }
                for record in sorted(records, key=lambda item: item.timestamp_utc)
                if record.estimated_savings_amount is not None
                and record.value_origins.get("estimated_savings_amount") != ValueOrigin.UNAVAILABLE
            ]
            if not savings_points:
                st.caption("Cost reporting will be enabled after approved pricing is configured.")
            else:
                fig = px.line(
                    savings_points,
                    x="date",
                    y="estimated_cost_avoidance",
                    markers=True,
                    template="plotly_dark",
                )
                fig.update_traces(
                    line=dict(color="#4ADE80", width=2.5),
                    marker=dict(color="#22C55E", size=7, line=dict(color="#0A0E1A", width=1.5)),
                    fill="tozeroy",
                    fillcolor="rgba(74,222,128,0.08)",
                )
                fig.update_layout(
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    xaxis=dict(
                        title="Date",
                        gridcolor="rgba(255,255,255,0.04)",
                        color="#8BAAC8",
                        title_font=dict(color="#8BAAC8", size=11),
                    ),
                    yaxis=dict(
                        title="Est. Cost Avoidance ($)",
                        gridcolor="rgba(255,255,255,0.05)",
                        color="#8BAAC8",
                        title_font=dict(color="#8BAAC8", size=11),
                    ),
                    margin=dict(t=8, b=8, l=8, r=8),
                    height=280,
                )
                st.plotly_chart(fig, use_container_width=True)
            st.markdown("</div>", unsafe_allow_html=True)


if __name__ == "__main__":
    main()
