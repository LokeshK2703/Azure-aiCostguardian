"""About page — ownership, tech stack, version, disclaimer, and contact."""

from __future__ import annotations

import streamlit as st

PAGE_TITLE = "About"

SIDEBAR_CSS = """
<style>
[data-testid="stSidebarNav"] { display: none; }
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #001428 0%, #002b5e 100%);
    border-right: 1px solid #0050a0;
}
.cg-side-brand { padding: 0.65rem 0.5rem 0.6rem; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 0.7rem; }
.cg-side-brand-row { display: flex; align-items: center; gap: 0.45rem; margin-bottom: 0.18rem; }
.cg-side-brand-name { color: #ffffff; font-size: 0.8rem; font-weight: 700; }
.cg-side-brand-sub { color: #7ab8d9; font-size: 0.7rem; padding-left: 0.1rem; }
.cg-side-title { color: #7ab8d9; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 0.5rem; font-weight: 700; padding: 0 0.25rem; }
.cg-side-item { color: #c8dff0; font-size: 0.9rem; padding: 0.42rem 0.55rem; border-radius: 6px; margin-bottom: 0.22rem; }
.cg-side-item-active { background: rgba(0, 120, 212, 0.3); border: 1px solid rgba(0, 120, 212, 0.6); color: #ffffff; font-weight: 700; }
</style>
"""

PAGE_CSS = """
<style>
.stApp { background: #EEF4FB; color: #1e293b; }
.stApp h1, .stApp h2, .stApp h3, .stApp h4 { color: #001F3D !important; }
[data-testid="stMarkdownContainer"] p { color: #1e293b; }
[data-testid="stMarkdownContainer"] li { color: #1e293b; }
[data-testid="stMarkdownContainer"] { color: #1e293b; }
[data-testid="stCaptionContainer"] { color: #475569 !important; }
.about-hero {
    background: linear-gradient(135deg, #001428 0%, #002b5e 55%, #0050a0 100%);
    color: #ffffff;
    border-radius: 12px;
    border: 1px solid #0078D4;
    padding: 1.4rem 1.5rem;
    margin-bottom: 1.2rem;
    box-shadow: 0 4px 18px rgba(0, 120, 212, 0.22);
}
.about-hero-title { font-size: 1.5rem; font-weight: 800; margin-bottom: 0.2rem; letter-spacing: -0.02em; }
.about-hero-sub { color: #a8d4f5; font-size: 0.9rem; }
.about-card {
    border: 1px solid #C7DEF8;
    border-radius: 10px;
    background: #ffffff;
    padding: 1.2rem 1.3rem;
    margin-bottom: 1rem;
    box-shadow: 0 1px 5px rgba(0,120,212,0.06);
}
.about-card-title {
    font-size: 1rem;
    font-weight: 800;
    color: #001F3D;
    margin-bottom: 0.7rem;
}
.about-section-label {
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #0078D4;
    margin-bottom: 0.6rem;
}
.tech-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.3rem;
    border: 1px solid #C7DEF8;
    border-radius: 6px;
    padding: 0.35rem 0.65rem;
    font-size: 0.82rem;
    font-weight: 700;
    color: #003B70;
    background: #EEF6FF;
    margin: 0.2rem;
}
.version-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.4rem 0;
    border-bottom: 1px solid #EEF2F7;
    font-size: 0.87rem;
}
.version-key { color: #475569; font-weight: 600; }
.version-val { color: #001F3D; font-weight: 700; }
.disclaimer-box {
    background: #FFF8F0;
    border: 1px solid #FFD9A0;
    border-left: 4px solid #FF8C00;
    border-radius: 8px;
    padding: 0.9rem 1rem;
    font-size: 0.86rem;
    color: #6B4800;
    line-height: 1.55;
}
.scope-item {
    display: flex;
    align-items: flex-start;
    gap: 0.5rem;
    padding: 0.42rem 0;
    border-bottom: 1px solid #EEF2F7;
    font-size: 0.87rem;
    color: #1e293b;
}
</style>
"""


def _render_sidebar() -> None:
    st.markdown(SIDEBAR_CSS, unsafe_allow_html=True)
    if hasattr(st, "page_link"):
        with st.sidebar:
            st.markdown(
                """
                <div class="cg-side-brand">
                    <div class="cg-side-brand-row">
                        <svg width="16" height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <rect x="0" y="0" width="9" height="9" fill="#F25022"/>
                            <rect x="11" y="0" width="9" height="9" fill="#7FBA00"/>
                            <rect x="0" y="11" width="9" height="9" fill="#00A4EF"/>
                            <rect x="11" y="11" width="9" height="9" fill="#FFB900"/>
                        </svg>
                        <span class="cg-side-brand-name">Microsoft</span>
                    </div>
                    <div class="cg-side-brand-sub">Azure AI Foundry</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.markdown('<div class="cg-side-title">Navigation</div>', unsafe_allow_html=True)
            try:
                st.page_link("app.py", label="💬 Chat & Analyze")
                st.page_link("pages/1_Savings_Dashboard.py", label="📊 AI Usage Dashboard")
                st.page_link("pages/2_Architecture.py", label="🏗 Architecture")
                st.page_link("pages/3_Project_Story.py", label="📖 Project Story")
                st.markdown('<div class="cg-side-item cg-side-item-active">ℹ️ About</div>', unsafe_allow_html=True)
            except Exception:
                st.caption("💬 Chat & Analyze")
                st.caption("📊 AI Usage Dashboard")
                st.caption("🏗 Architecture")
                st.caption("📖 Project Story")
                st.markdown('<div class="cg-side-item cg-side-item-active">ℹ️ About</div>', unsafe_allow_html=True)


def main() -> None:
    st.set_page_config(page_title=f"{PAGE_TITLE} — Azure AI Cost Guardian", layout="wide")
    _render_sidebar()
    st.markdown(PAGE_CSS, unsafe_allow_html=True)

    st.markdown(
        """
        <div class="about-hero">
            <div style="display:flex;align-items:center;gap:0.6rem;margin-bottom:0.5rem;">
                <svg width="18" height="18" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0">
                    <rect x="0" y="0" width="9" height="9" fill="#F25022"/>
                    <rect x="11" y="0" width="9" height="9" fill="#7FBA00"/>
                    <rect x="0" y="11" width="9" height="9" fill="#00A4EF"/>
                    <rect x="11" y="11" width="9" height="9" fill="#FFB900"/>
                </svg>
                <span style="color:rgba(255,255,255,0.75);font-size:0.78rem;font-weight:600;">Microsoft · Azure AI Foundry · Hackathon 2026</span>
            </div>
            <div class="about-hero-title">ℹ️ About</div>
            <div class="about-hero-sub">Ownership, scope, tech stack, version, and disclaimer for Azure AI Cost Guardian.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    col1, col2 = st.columns(2)

    with col1:
        # Ownership
        st.markdown('<div class="about-card">', unsafe_allow_html=True)
        st.markdown('<div class="about-card-title">👤 Ownership & Context</div>', unsafe_allow_html=True)
        st.markdown('<div class="about-section-label">Who built this and why</div>', unsafe_allow_html=True)
        ownership = [
            ("Builder", "Lokesh Kumar"),
            ("Context", "Microsoft Hackathon 2026"),
            ("Platform", "Azure AI Foundry"),
            ("Category", "AI FinOps / Cost Governance"),
            ("Approach", "Intelligent Model Routing"),
            ("Status", "Hackathon Prototype — MVP"),
        ]
        for key, val in ownership:
            st.markdown(
                f'<div class="version-row"><span class="version-key">{key}</span><span class="version-val">{val}</span></div>',
                unsafe_allow_html=True,
            )
        st.markdown("</div>", unsafe_allow_html=True)

        # Version
        st.markdown('<div class="about-card">', unsafe_allow_html=True)
        st.markdown('<div class="about-card-title">🔖 Version & Configuration</div>', unsafe_allow_html=True)
        st.markdown('<div class="about-section-label">Runtime details</div>', unsafe_allow_html=True)
        versions = [
            ("App Version", "1.0.0-hackathon"),
            ("Routing Policy", "v1.0"),
            ("Pricing Schema", "v1.0"),
            ("API Version", "2025-01-01-preview"),
            ("Model Tier — Economy", "gpt-5.4-nano (routine-model)"),
            ("Model Tier — Balanced", "gpt-5.4-mini (balanced-model)"),
            ("Model Tier — Advanced", "gpt-5.4 (premium-model)"),
            ("Telemetry Retention", "1000 records · 30 days"),
            ("Raw Content Stored", "Never — privacy enforced"),
        ]
        for key, val in versions:
            st.markdown(
                f'<div class="version-row"><span class="version-key">{key}</span><span class="version-val">{val}</span></div>',
                unsafe_allow_html=True,
            )
        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        # Tech stack
        st.markdown('<div class="about-card">', unsafe_allow_html=True)
        st.markdown('<div class="about-card-title">🧰 Tech Stack</div>', unsafe_allow_html=True)
        st.markdown('<div class="about-section-label">Technologies powering this prototype</div>', unsafe_allow_html=True)

        st.markdown("**Cloud & AI**", unsafe_allow_html=True)
        cloud = [
            ("☁️", "Azure AI Foundry"),
            ("🤖", "Azure OpenAI — GPT-5.4 family"),
            ("🌐", "Global Standard Deployment"),
        ]
        for icon, name in cloud:
            st.markdown(f'<span class="tech-badge">{icon} {name}</span>', unsafe_allow_html=True)

        st.markdown("<br>**Application**", unsafe_allow_html=True)
        app_stack = [
            ("🐍", "Python 3.12"),
            ("📊", "Streamlit 1.60"),
            ("✅", "Pydantic v2"),
            ("📦", "openai SDK"),
            ("🔢", "tiktoken"),
            ("📈", "Plotly"),
            ("⚙️", "pydantic-settings"),
            ("🧪", "pytest"),
        ]
        for icon, name in app_stack:
            st.markdown(f'<span class="tech-badge">{icon} {name}</span>', unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

        # Scope
        st.markdown('<div class="about-card">', unsafe_allow_html=True)
        st.markdown('<div class="about-card-title">🗂 Scope & What This Is Not</div>', unsafe_allow_html=True)
        st.markdown('<div class="about-section-label">Boundaries of this MVP prototype</div>', unsafe_allow_html=True)
        in_scope = [
            ("✅", "Complexity-based prompt routing across 3 model tiers"),
            ("✅", "Deterministic, explainable routing decisions"),
            ("✅", "Per-request cost estimation and telemetry"),
            ("✅", "Privacy-safe audit trail (no prompt/response stored)"),
            ("✅", "Live Azure OpenAI execution via AI Foundry"),
        ]
        out_scope = [
            ("🚫", "Not a production-grade API gateway"),
            ("🚫", "Not multi-tenant or user-auth enabled"),
            ("🚫", "Not an official Microsoft product or service"),
            ("🚫", "Rate card uses estimated GPT-5.4 pricing — verify against live Azure rates for billing accuracy"),
        ]
        for icon, text in in_scope:
            st.markdown(f'<div class="scope-item"><span>{icon}</span><span>{text}</span></div>', unsafe_allow_html=True)
        for icon, text in out_scope:
            st.markdown(f'<div class="scope-item"><span>{icon}</span><span style="color:#b91c1c">{text}</span></div>', unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

        # Disclaimer
        st.markdown(
            """
            <div class="disclaimer-box">
                ⚠️ <strong>Disclaimer</strong><br><br>
                This is a hackathon prototype built for demonstration purposes. It is not an official Microsoft product,
                service, or recommendation. Cost calculations are real — estimated costs use pre-execution token projections
                and actual costs use real Azure token usage returned after each API call. However, the rate card values
                ($ per million tokens) are estimates based on the GPT-4.1 family and should be verified against current
                Azure AI Foundry pricing for billing-accurate numbers. Do not enter confidential, customer-identifiable,
                or production-sensitive information into this prototype.
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.caption("Azure AI Cost Guardian · v1.0.0-hackathon · Not an official Microsoft product.")


if __name__ == "__main__":
    main()
