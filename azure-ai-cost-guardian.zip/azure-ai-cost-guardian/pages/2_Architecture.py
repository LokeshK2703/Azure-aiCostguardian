"""Architecture page — system design, routing logic, and privacy boundaries."""

from __future__ import annotations

import streamlit as st

PAGE_TITLE = "Architecture"

SIDEBAR_CSS = """
<style>
[data-testid="stSidebarNav"] { display: none; }
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #001428 0%, #002b5e 100%);
    border-right: 1px solid #0050a0;
}
.cg-side-brand { padding: 0.65rem 0.5rem 0.6rem; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 0.7rem; }
.cg-side-brand-row { display: flex; align-items: center; gap: 0.45rem; margin-bottom: 0.18rem; }
.cg-side-brand-name { color: #ffffff; font-size: 0.8rem; font-weight: 700; letter-spacing: 0.02em; }
.cg-side-brand-sub { color: #7ab8d9; font-size: 0.7rem; padding-left: 0.1rem; }
.cg-side-title { color: #7ab8d9; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 0.5rem; font-weight: 700; padding: 0 0.25rem; }
.cg-side-item { color: #c8dff0; font-size: 0.9rem; padding: 0.42rem 0.55rem; border-radius: 6px; margin-bottom: 0.22rem; }
.cg-side-item-active { background: rgba(0, 120, 212, 0.3); border: 1px solid rgba(0, 120, 212, 0.6); color: #ffffff; font-weight: 700; }
</style>
"""

PAGE_CSS = """
<style>
.stApp { background: #EEF4FB; color: #1e293b; }
.stApp h1, .stApp h2, .stApp h3, .stApp h4 { color: #001F3D !important; }
[data-testid="stMarkdownContainer"] p { color: #1e293b; }
[data-testid="stMarkdownContainer"] li { color: #1e293b; }
[data-testid="stMarkdownContainer"] { color: #1e293b; }
[data-testid="stCaptionContainer"] { color: #475569 !important; }
.arch-hero {
    background: linear-gradient(135deg, #001428 0%, #002b5e 55%, #0050a0 100%);
    color: #ffffff;
    border-radius: 12px;
    border: 1px solid #0078D4;
    padding: 1.3rem 1.5rem;
    margin-bottom: 1.2rem;
    box-shadow: 0 4px 18px rgba(0, 120, 212, 0.22);
}
.arch-hero-title { font-size: 1.5rem; font-weight: 800; margin-bottom: 0.2rem; letter-spacing: -0.02em; }
.arch-hero-sub { color: #a8d4f5; font-size: 0.9rem; }
.arch-card {
    border: 1px solid #C7DEF8;
    border-radius: 10px;
    background: #ffffff;
    padding: 1.2rem 1.3rem;
    margin-bottom: 1rem;
    box-shadow: 0 1px 5px rgba(0,120,212,0.06);
}
.arch-card-title {
    font-size: 1rem;
    font-weight: 800;
    color: #001F3D;
    margin-bottom: 0.6rem;
    display: flex;
    align-items: center;
    gap: 0.4rem;
}
.arch-section-label {
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #0078D4;
    margin-bottom: 0.5rem;
}
.pipeline-step {
    background: #EEF6FF;
    border: 1px solid #C7DEF8;
    border-left: 4px solid #0078D4;
    border-radius: 8px;
    padding: 0.7rem 0.9rem;
    margin-bottom: 0.5rem;
}
.pipeline-step-num {
    font-size: 0.7rem;
    font-weight: 800;
    color: #0078D4;
    text-transform: uppercase;
    letter-spacing: 0.08em;
}
.pipeline-step-title { font-size: 0.95rem; font-weight: 800; color: #001F3D; }
.pipeline-step-desc { font-size: 0.84rem; color: #475569; margin-top: 0.18rem; }
.tier-row {
    display: flex;
    gap: 0.6rem;
    margin-bottom: 0.6rem;
}
.tier-card {
    flex: 1;
    border-radius: 8px;
    padding: 0.85rem;
    border: 1px solid;
}
.tier-economy { background: #DFF6DD; border-color: #9FD89F; }
.tier-balanced { background: #EEF6FF; border-color: #C7DEF8; }
.tier-premium { background: #F9F0FF; border-color: #D8B4FE; }
.tier-name { font-size: 0.8rem; font-weight: 800; margin-bottom: 0.18rem; }
.tier-economy .tier-name { color: #107C10; }
.tier-balanced .tier-name { color: #0050A0; }
.tier-premium .tier-name { color: #5C2D91; }
.tier-model { font-size: 0.78rem; color: #334155; font-weight: 600; margin-bottom: 0.1rem; }
.tier-range { font-size: 0.76rem; color: #64748b; }
.factor-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.3rem 0;
    border-bottom: 1px solid #EEF2F7;
    font-size: 0.86rem;
}
.factor-name { color: #334155; font-weight: 600; }
.factor-weight {
    background: #EEF6FF;
    color: #0050A0;
    border-radius: 999px;
    padding: 0.1rem 0.5rem;
    font-size: 0.75rem;
    font-weight: 700;
}
.privacy-item {
    display: flex;
    align-items: flex-start;
    gap: 0.5rem;
    padding: 0.45rem 0;
    border-bottom: 1px solid #EEF2F7;
    font-size: 0.87rem;
    color: #334155;
}
.privacy-icon { flex-shrink: 0; }
</style>
"""


def _render_sidebar() -> None:
    st.markdown(SIDEBAR_CSS, unsafe_allow_html=True)
    if hasattr(st, "page_link"):
        with st.sidebar:
            st.markdown(
                """
                <div class="cg-side-brand">
                    <div class="cg-side-brand-row">
                        <svg width="16" height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <rect x="0" y="0" width="9" height="9" fill="#F25022"/>
                            <rect x="11" y="0" width="9" height="9" fill="#7FBA00"/>
                            <rect x="0" y="11" width="9" height="9" fill="#00A4EF"/>
                            <rect x="11" y="11" width="9" height="9" fill="#FFB900"/>
                        </svg>
                        <span class="cg-side-brand-name">Microsoft</span>
                    </div>
                    <div class="cg-side-brand-sub">Azure AI Foundry</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.markdown('<div class="cg-side-title">Navigation</div>', unsafe_allow_html=True)
            try:
                st.page_link("app.py", label="💬 Chat & Analyze")
                st.page_link("pages/1_Savings_Dashboard.py", label="📊 AI Usage Dashboard")
                st.markdown('<div class="cg-side-item cg-side-item-active">🏗 Architecture</div>', unsafe_allow_html=True)
                st.page_link("pages/3_Project_Story.py", label="📖 Project Story")
                st.page_link("pages/4_About.py", label="ℹ️ About")
            except Exception:
                st.caption("💬 Chat & Analyze")
                st.caption("📊 AI Usage Dashboard")
                st.markdown('<div class="cg-side-item cg-side-item-active">🏗 Architecture</div>', unsafe_allow_html=True)
                st.caption("📖 Project Story")
                st.caption("ℹ️ About")


def _pipeline_step(num: str, title: str, desc: str) -> None:
    st.markdown(
        f"""
        <div class="pipeline-step">
            <div class="pipeline-step-num">Step {num}</div>
            <div class="pipeline-step-title">{title}</div>
            <div class="pipeline-step-desc">{desc}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def main() -> None:
    st.set_page_config(page_title=f"{PAGE_TITLE} — Azure AI Cost Guardian", layout="wide")
    _render_sidebar()
    st.markdown(PAGE_CSS, unsafe_allow_html=True)

    st.markdown(
        """
        <div class="arch-hero">
            <div style="display:flex;align-items:center;gap:0.6rem;margin-bottom:0.5rem;">
                <svg width="18" height="18" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0">
                    <rect x="0" y="0" width="9" height="9" fill="#F25022"/>
                    <rect x="11" y="0" width="9" height="9" fill="#7FBA00"/>
                    <rect x="0" y="11" width="9" height="9" fill="#00A4EF"/>
                    <rect x="11" y="11" width="9" height="9" fill="#FFB900"/>
                </svg>
                <span style="color:rgba(255,255,255,0.75);font-size:0.78rem;font-weight:600;">Microsoft · Azure AI Foundry</span>
            </div>
            <div class="arch-hero-title">🏗 System Architecture</div>
            <div class="arch-hero-sub">How Azure AI Cost Guardian analyses, routes, and governs every AI request.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ── Pipeline ────────────────────────────────────────────────────────
    st.markdown('<div class="arch-card">', unsafe_allow_html=True)
    st.markdown('<div class="arch-card-title">⚡ End-to-End Request Pipeline</div>', unsafe_allow_html=True)
    st.markdown('<div class="arch-section-label">Every request follows this 6-step path in under 200 ms overhead</div>', unsafe_allow_html=True)

    _pipeline_step("1", "Prompt Intake", "User submits a natural-language prompt via the Chat & Analyze UI. No content is persisted at this stage.")
    _pipeline_step("2", "Complexity Analysis", "The Prompt Analyzer scores the request across 9 weighted signal dimensions (task type, length, reasoning terms, multi-step indicators, architecture/security language, code generation signals, and output structure). Score range: 0 – 10.")
    _pipeline_step("3", "Token Estimation", "tiktoken (cl100k_base encoding) estimates input and output token counts using per-task output ratios. This feeds into the cost comparison before execution.")
    _pipeline_step("4", "Model Routing", "The Model Router maps the complexity score to a logical tier (Economy / Balanced / Advanced) and computes a routing confidence score (40 – 95%). Boundary penalties and short-prompt penalties are applied.")
    _pipeline_step("5", "Azure OpenAI Execution", "The selected deployment is called via the Azure OpenAI SDK. Response text, latency, and actual token usage are captured. All three GPT-5.4 deployments are available.")
    _pipeline_step("6", "Telemetry & Cost", "Operational metadata (no prompt or response text) is written atomically to a local JSON store. Estimated and actual costs are computed against the baseline (Advanced tier).")

    st.markdown("</div>", unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    # ── Model Tier Mapping ───────────────────────────────────────────────
    with col1:
        st.markdown('<div class="arch-card">', unsafe_allow_html=True)
        st.markdown('<div class="arch-card-title">🎯 Model Tier Mapping</div>', unsafe_allow_html=True)
        st.markdown('<div class="arch-section-label">Complexity score → logical tier → Azure deployment</div>', unsafe_allow_html=True)
        st.markdown(
            """
            <div class="tier-row">
                <div class="tier-card tier-economy">
                    <div class="tier-name">Economy</div>
                    <div class="tier-model">gpt-5.4-nano · routine-model</div>
                    <div class="tier-range">Score 0.0 – 4.0 · Routine tasks</div>
                </div>
            </div>
            <div class="tier-row">
                <div class="tier-card tier-balanced">
                    <div class="tier-name">Balanced</div>
                    <div class="tier-model">gpt-5.4-mini · balanced-model</div>
                    <div class="tier-range">Score 4.0 – 7.0 · Moderate tasks</div>
                </div>
            </div>
            <div class="tier-row">
                <div class="tier-card tier-premium">
                    <div class="tier-name">Advanced</div>
                    <div class="tier-model">gpt-5.4 · premium-model</div>
                    <div class="tier-range">Score 7.0 – 10.0 · Complex tasks</div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.markdown("</div>", unsafe_allow_html=True)

        # ── Routing criteria ─────────────────────────────────────────────
        st.markdown('<div class="arch-card">', unsafe_allow_html=True)
        st.markdown('<div class="arch-card-title">📐 Routing Criteria — Signal Weights</div>', unsafe_allow_html=True)
        st.markdown('<div class="arch-section-label">Weights applied to compute the complexity score (must sum to 1.0)</div>', unsafe_allow_html=True)
        factors = [
            ("Task Type Prior", "18%"),
            ("Prompt Length", "16%"),
            ("Requested Operations", "12%"),
            ("Reasoning Terminology", "12%"),
            ("Code Generation Signals", "12%"),
            ("Multi-step Indicators", "10%"),
            ("Architecture / Security Terms", "10%"),
            ("Requested Output Size", "5%"),
            ("Requested Output Structure", "5%"),
        ]
        for name, weight in factors:
            st.markdown(
                f'<div class="factor-row"><span class="factor-name">{name}</span><span class="factor-weight">{weight}</span></div>',
                unsafe_allow_html=True,
            )
        st.markdown("</div>", unsafe_allow_html=True)

    # ── Error handling + Privacy ─────────────────────────────────────────
    with col2:
        st.markdown('<div class="arch-card">', unsafe_allow_html=True)
        st.markdown('<div class="arch-card-title">🛡️ Error Handling & Fallback Behaviour</div>', unsafe_allow_html=True)
        st.markdown('<div class="arch-section-label">Every Azure OpenAI error is caught and categorised — no unhandled exceptions reach the UI</div>', unsafe_allow_html=True)
        errors = [
            ("🔑", "Authentication / Authorization", "Caught as BLOCKED. Displayed safely — no key material exposed."),
            ("🚫", "Deployment Not Found (404)", "Caught as DEPLOYMENT_UNAVAILABLE. User sees a clean message."),
            ("⏱️", "Timeout (60 s default)", "Caught as TIMEOUT. Retryable flag set for the UI."),
            ("🌐", "Network / Connection Error", "Caught as NETWORK. Retryable. Telemetry still written."),
            ("📈", "Rate Limit (429)", "Caught as RATE_LIMIT. Retryable. No retry loop — user-driven."),
            ("⚠️", "Bad Request / Content Filter", "Caught as DEPLOYMENT_UNAVAILABLE or SERVICE error."),
            ("❓", "Unexpected Exception", "Caught as UNKNOWN. Stack trace never surfaced to UI."),
        ]
        for icon, title, desc in errors:
            st.markdown(
                f"""
                <div class="privacy-item">
                    <span class="privacy-icon">{icon}</span>
                    <div><strong style="color:#001F3D">{title}</strong><br><span style="color:#475569;font-size:0.82rem">{desc}</span></div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="arch-card">', unsafe_allow_html=True)
        st.markdown('<div class="arch-card-title">🔒 Privacy & Telemetry Boundaries</div>', unsafe_allow_html=True)
        st.markdown('<div class="arch-section-label">What is and is not retained in the local telemetry store</div>', unsafe_allow_html=True)
        stored = [
            ("✅", "Task category (e.g. summarization, code)"),
            ("✅", "Complexity score and level"),
            ("✅", "Recommended and executed tier"),
            ("✅", "Token counts (estimated and actual)"),
            ("✅", "Latency in milliseconds"),
            ("✅", "Estimated and actual cost amounts"),
            ("✅", "Execution status and error category"),
        ]
        not_stored = [
            ("🚫", "Prompt text — never persisted"),
            ("🚫", "Response text — never persisted"),
            ("🚫", "API keys or credentials"),
            ("🚫", "User identity or session info"),
        ]
        for icon, label in stored:
            st.markdown(f'<div class="privacy-item"><span class="privacy-icon">{icon}</span><span>{label}</span></div>', unsafe_allow_html=True)
        for icon, label in not_stored:
            st.markdown(f'<div class="privacy-item"><span class="privacy-icon">{icon}</span><span style="color:#b91c1c">{label}</span></div>', unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

    st.caption("Azure AI Cost Guardian · Hackathon Prototype · Not an official Microsoft product.")


if __name__ == "__main__":
    main()
