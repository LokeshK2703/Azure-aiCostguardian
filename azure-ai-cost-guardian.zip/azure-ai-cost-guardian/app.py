"""Minimal customer journey Streamlit entrypoint for Azure AI Cost Guardian."""

from __future__ import annotations

import streamlit as st

from config import AppConfig, load_app_config
from models.enums import AppMode
from models.request_models import PromptRequest
from models.response_models import CostComparison, OrchestrationResult
from services.request_orchestrator import execute_request
from ui.presentation import (
    execution_status_label,
    optimization_explanation,
    optimization_reasons,
    pricing_available,
    pricing_unavailable_caption,
    response_text_for_display,
    selection_source_label,
)

APP_TITLE = "Azure AI Cost Guardian"
APP_SUBTITLE = "Use the Right AI. Not the Most Expensive One."
APP_SUPPORTING_TEXT = (
    "Cost Guardian automatically evaluates requests and reserves premium AI capability only when it creates real value."
)
DEMO_NOTICE = "Demo Mode: Results are generated locally using deterministic examples. No live AI service is called."
DEFAULT_PROMPT = "Summarize these meeting notes into five key decisions and action items."
EXAMPLE_PROMPTS = [
    ("Summarize Notes", "Summarize these meeting notes into five key decisions and action items."),
    ("Draft Email", "Draft a business email requesting project timeline confirmation and next steps."),
    ("Explain Concept", "Explain the difference between TLS and mTLS with a practical enterprise example."),
    (
        "Secure Architecture",
        "Design a secure multi-region Azure AI landing zone for a healthcare organization with private connectivity, identity governance, monitoring, disaster recovery, and compliance controls.",
    ),
]

CAPABILITY_LABELS = {
    "economy": "Cost-Efficient",
    "balanced": "Standard",
    "advanced": "Premium",
}

DECISION_SOURCE_LABELS = {
    "recommendation": "Automatic Recommendation",
    "user_override": "Administrator Override",
    "not_started": "Not Started",
}

WORKLOAD_TYPE_LABELS = {
    "summarization": "Summarization",
    "email": "Email Drafting",
    "documentation": "Documentation",
    "technical_explanation": "Technical Explanation",
    "architecture_design": "Architecture Design",
    "code_generation": "Software Development",
    "general_qa": "General Question",
}


def _load_config() -> AppConfig:
    return load_app_config(allow_unverified_pricing_preview=True)


def _ensure_session_state() -> None:
    defaults = {
        "business_need": DEFAULT_PROMPT,
        "last_orchestration": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def _set_example_prompt(prompt: str) -> None:
    st.session_state.business_need = prompt
    st.session_state.last_orchestration = None


def _title_text(value: str) -> str:
    return value.replace("_", " ").strip().title()


def _workload_label(raw_value: str) -> str:
    return WORKLOAD_TYPE_LABELS.get(raw_value, _title_text(raw_value))


def _capability_label(raw_value: str) -> str:
    return CAPABILITY_LABELS.get(raw_value, _title_text(raw_value))


def _decision_source_label(raw_value: str) -> str:
    return DECISION_SOURCE_LABELS.get(raw_value, _title_text(raw_value))


def _render_sidebar_navigation() -> None:
    st.markdown(
        """
        <style>
        [data-testid="stSidebarNav"] { display: none; }
        [data-testid="stSidebar"] {
            background: linear-gradient(180deg, #001428 0%, #002b5e 100%);
            border-right: 1px solid #0050a0;
        }
        .cg-side-brand {
            padding: 0.65rem 0.5rem 0.6rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 0.7rem;
        }
        .cg-side-brand-row {
            display: flex;
            align-items: center;
            gap: 0.45rem;
            margin-bottom: 0.18rem;
        }
        .cg-side-brand-name {
            color: #ffffff;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.02em;
        }
        .cg-side-brand-sub {
            color: #7ab8d9;
            font-size: 0.7rem;
            padding-left: 0.1rem;
        }
        .cg-side-title {
            color: #7ab8d9;
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            margin-bottom: 0.5rem;
            font-weight: 700;
            padding: 0 0.25rem;
        }
        .cg-side-item {
            color: #c8dff0;
            font-size: 0.9rem;
            padding: 0.42rem 0.55rem;
            border-radius: 6px;
            margin-bottom: 0.22rem;
        }
        .cg-side-item-active {
            background: rgba(0, 120, 212, 0.3);
            border: 1px solid rgba(0, 120, 212, 0.6);
            color: #ffffff;
            font-weight: 700;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )
    if hasattr(st, "page_link"):
        with st.sidebar:
            st.markdown(
                """
                <div class="cg-side-brand">
                    <div class="cg-side-brand-row">
                        <svg width="16" height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <rect x="0" y="0" width="9" height="9" fill="#F25022"/>
                            <rect x="11" y="0" width="9" height="9" fill="#7FBA00"/>
                            <rect x="0" y="11" width="9" height="9" fill="#00A4EF"/>
                            <rect x="11" y="11" width="9" height="9" fill="#FFB900"/>
                        </svg>
                        <span class="cg-side-brand-name">Microsoft</span>
                    </div>
                    <div class="cg-side-brand-sub">Azure AI Foundry</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.markdown('<div class="cg-side-title">Navigation</div>', unsafe_allow_html=True)
            try:
                st.markdown('<div class="cg-side-item cg-side-item-active">💬 Chat & Analyze</div>', unsafe_allow_html=True)
                st.page_link("pages/1_Savings_Dashboard.py", label="📊 AI Usage Dashboard")
                st.page_link("pages/2_Architecture.py", label="🏗 Architecture")
                st.page_link("pages/3_Project_Story.py", label="📖 Project Story")
                st.page_link("pages/4_About.py", label="ℹ️ About")
            except Exception:
                st.markdown('<div class="cg-side-item cg-side-item-active">💬 Chat & Analyze</div>', unsafe_allow_html=True)
                st.caption("📊 AI Usage Dashboard")
                st.caption("🏗 Architecture")
                st.caption("📖 Project Story")
                st.caption("ℹ️ About")


def _render_layout_styles() -> None:
    st.markdown(
        """
        <style>
        /* ── Base dark theme ── */
        .stApp {
            background: #0A0E1A !important;
            color: #F0F6FF;
        }
        .stApp h1, .stApp h2, .stApp h3,
        .stApp h4, .stApp h5, .stApp h6 {
            color: #F0F6FF !important;
        }
        [data-testid="stMarkdownContainer"] p  { color: #C8D8EC; }
        [data-testid="stMarkdownContainer"] li { color: #C8D8EC; }
        [data-testid="stMarkdownContainer"]    { color: #C8D8EC; }
        [data-testid="stCaptionContainer"]     { color: #8BAAC8 !important; }

        /* ── Expander ── */
        [data-testid="stExpander"] {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px;
        }
        [data-testid="stExpander"] summary { color: #C8D8EC !important; }
        [data-testid="stExpander"] [data-testid="stMarkdownContainer"] { color: #C8D8EC; }
        [data-testid="stExpanderDetails"] { background: transparent; }

        /* ── Metrics ── */
        .stMetric label                           { color: #8BAAC8 !important; }
        .stMetric [data-testid="stMetricValue"]   { color: #F0F6FF !important; }

        /* ── Text area ── */
        [data-testid="stTextArea"] textarea {
            background: rgba(255,255,255,0.05) !important;
            border: 1px solid rgba(255,255,255,0.12) !important;
            color: #F0F6FF !important;
            border-radius: 8px !important;
        }
        [data-testid="stTextArea"] textarea::placeholder { color: #8BAAC8 !important; }
        [data-testid="stTextArea"] textarea:focus {
            border-color: #0078D4 !important;
            box-shadow: 0 0 0 2px rgba(0,120,212,0.25) !important;
        }
        [data-testid="stTextArea"] label { color: #8BAAC8 !important; }

        /* ── Info / success / warning banners ── */
        [data-testid="stAlert"] {
            background: rgba(0,120,212,0.12) !important;
            border: 1px solid rgba(0,120,212,0.35) !important;
            border-radius: 8px !important;
            color: #C8D8EC !important;
        }

        /* ── Primary button ── */
        div[data-testid="stButton"] > button[kind="primary"] {
            background: linear-gradient(135deg, #0078D4 0%, #005A9E 100%) !important;
            color: #ffffff !important;
            border: 1px solid rgba(80,230,255,0.3) !important;
            border-radius: 8px !important;
            font-weight: 700 !important;
            font-size: 1rem !important;
            letter-spacing: 0.02em !important;
            box-shadow: 0 4px 16px rgba(0,120,212,0.35) !important;
            transition: all 0.2s ease !important;
        }
        div[data-testid="stButton"] > button[kind="primary"]:hover {
            background: linear-gradient(135deg, #005A9E 0%, #004080 100%) !important;
            box-shadow: 0 6px 24px rgba(0,120,212,0.5) !important;
            transform: translateY(-1px) !important;
        }

        /* ── Secondary / example buttons ── */
        div[data-testid="stButton"] > button:not([kind="primary"]) {
            background: rgba(255,255,255,0.05) !important;
            color: #C8D8EC !important;
            border: 1px solid rgba(255,255,255,0.12) !important;
            border-radius: 8px !important;
            font-size: 0.83rem !important;
            font-weight: 600 !important;
            transition: all 0.18s ease !important;
        }
        div[data-testid="stButton"] > button:not([kind="primary"]):hover {
            background: rgba(0,120,212,0.18) !important;
            border-color: rgba(0,120,212,0.5) !important;
            color: #50E6FF !important;
        }

        /* ── Hero / top bar ── */
        .cg-hero {
            background: linear-gradient(135deg, #050C1C 0%, #0D1B35 55%, #0A2A5E 100%);
            border: 1px solid rgba(0,120,212,0.45);
            border-radius: 14px;
            padding: 1.4rem 1.6rem;
            margin-bottom: 1.2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            box-shadow: 0 8px 32px rgba(0,120,212,0.18), 0 0 0 1px rgba(80,230,255,0.06);
            position: relative;
            overflow: hidden;
        }
        .cg-hero::before {
            content: "";
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: radial-gradient(ellipse at 20% 50%, rgba(0,120,212,0.12) 0%, transparent 60%),
                        radial-gradient(ellipse at 80% 50%, rgba(80,230,255,0.06) 0%, transparent 60%);
            pointer-events: none;
        }
        .cg-hero-left  { display: flex; align-items: center; gap: 1rem; position: relative; }
        .cg-hero-right { display: flex; align-items: center; gap: 0.55rem; position: relative; }

        .cg-hero-icon {
            width: 46px; height: 46px;
            border-radius: 10px;
            background: rgba(0,120,212,0.25);
            border: 1px solid rgba(80,230,255,0.35);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
            box-shadow: 0 0 16px rgba(80,230,255,0.15);
        }
        .cg-hero-title {
            font-size: 1.35rem; font-weight: 800;
            color: #F0F6FF; margin: 0; letter-spacing: -0.02em;
        }
        .cg-hero-sub {
            font-size: 0.82rem; color: #8BAAC8; margin-top: 0.12rem;
        }
        .cg-hero-chip {
            display: inline-flex; align-items: center; gap: 0.3rem;
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 999px;
            padding: 0.22rem 0.65rem;
            font-size: 0.72rem; color: rgba(255,255,255,0.75);
            background: rgba(255,255,255,0.07);
            font-weight: 600; letter-spacing: 0.02em;
        }
        .cg-badge-live {
            display: inline-flex; align-items: center; gap: 0.3rem;
            border: 1px solid rgba(74,222,128,0.55);
            border-radius: 999px;
            padding: 0.22rem 0.75rem;
            font-size: 0.72rem; color: #86EFAC;
            background: rgba(22,101,52,0.35);
            font-weight: 700; letter-spacing: 0.03em;
        }
        .cg-badge-demo {
            display: inline-flex; align-items: center; gap: 0.3rem;
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 999px;
            padding: 0.22rem 0.75rem;
            font-size: 0.72rem; color: #94A3B8;
            background: rgba(255,255,255,0.07);
            font-weight: 700; letter-spacing: 0.03em;
        }

        /* ── Dark cards ── */
        .cg-card {
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.09);
            border-radius: 12px;
            padding: 1.2rem 1.3rem;
            margin-bottom: 1rem;
        }
        .cg-card-title {
            font-size: 1rem; font-weight: 700;
            color: #F0F6FF; margin-bottom: 0.15rem;
            letter-spacing: -0.01em;
        }
        .cg-card-sub {
            color: #8BAAC8; font-size: 0.85rem; margin-bottom: 0.75rem;
        }

        /* ── Response area ── */
        .cg-response {
            background: rgba(0,120,212,0.06);
            border: 1px solid rgba(0,120,212,0.22);
            border-left: 3px solid #0078D4;
            border-radius: 8px;
            padding: 1rem 1.1rem;
            line-height: 1.7;
            color: #C8D8EC;
            font-size: 0.95rem;
        }
        .cg-response-badge {
            display: inline-flex; align-items: center; gap: 0.35rem;
            background: rgba(34,197,94,0.15);
            border: 1px solid rgba(34,197,94,0.4);
            color: #86EFAC;
            border-radius: 6px;
            padding: 0.2rem 0.6rem;
            font-size: 0.78rem; font-weight: 700;
            margin-bottom: 0.65rem;
        }

        /* ── Tier indicator rows ── */
        .cg-tier-row {
            display: flex; align-items: center;
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 8px;
            padding: 0.65rem 0.9rem;
            margin-bottom: 0.45rem;
            background: rgba(255,255,255,0.03);
            gap: 0.75rem;
            transition: all 0.2s ease;
            position: relative;
            overflow: hidden;
        }
        .cg-tier-row-selected {
            border-color: rgba(0,120,212,0.7) !important;
            background: rgba(0,120,212,0.12) !important;
            box-shadow: 0 0 18px rgba(0,120,212,0.2), inset 0 0 0 1px rgba(80,230,255,0.1);
        }
        .cg-tier-icon {
            font-size: 1.1rem; width: 28px; text-align: center; flex-shrink: 0;
        }
        .cg-tier-info { flex: 1; min-width: 0; }
        .cg-tier-name {
            font-weight: 700; font-size: 0.9rem; color: #F0F6FF;
        }
        .cg-tier-model {
            font-size: 0.75rem; color: #8BAAC8; margin-top: 0.05rem;
            font-family: 'Courier New', monospace;
        }
        .cg-tier-selected-chip {
            display: inline-flex; align-items: center; gap: 0.2rem;
            background: rgba(0,120,212,0.25);
            border: 1px solid rgba(80,230,255,0.35);
            color: #50E6FF;
            border-radius: 999px;
            padding: 0.12rem 0.5rem;
            font-size: 0.68rem; font-weight: 700;
            white-space: nowrap;
        }

        /* ── Routing decision badge ── */
        .cg-routing-badge-eff {
            display: inline-flex; align-items: center; gap: 0.35rem;
            background: rgba(74,222,128,0.12);
            border: 1px solid rgba(74,222,128,0.4);
            color: #86EFAC;
            border-radius: 8px;
            padding: 0.35rem 0.75rem;
            font-size: 0.88rem; font-weight: 700;
            margin-bottom: 0.65rem;
        }
        .cg-routing-badge-bal {
            display: inline-flex; align-items: center; gap: 0.35rem;
            background: rgba(96,165,250,0.12);
            border: 1px solid rgba(96,165,250,0.4);
            color: #93C5FD;
            border-radius: 8px;
            padding: 0.35rem 0.75rem;
            font-size: 0.88rem; font-weight: 700;
            margin-bottom: 0.65rem;
        }
        .cg-routing-badge-prem {
            display: inline-flex; align-items: center; gap: 0.35rem;
            background: rgba(167,139,250,0.12);
            border: 1px solid rgba(167,139,250,0.4);
            color: #C4B5FD;
            border-radius: 8px;
            padding: 0.35rem 0.75rem;
            font-size: 0.88rem; font-weight: 700;
            margin-bottom: 0.65rem;
        }

        /* ── Cost metric boxes ── */
        .cg-cost-box {
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 1rem 1.1rem;
            margin-bottom: 0.55rem;
        }
        .cg-cost-box-label {
            font-size: 0.78rem; color: #8BAAC8; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.06em;
            margin-bottom: 0.5rem;
        }
        .cg-cost-row {
            display: flex; justify-content: space-between; align-items: baseline;
            margin-bottom: 0.28rem;
        }
        .cg-cost-row-key   { font-size: 0.82rem; color: #8BAAC8; }
        .cg-cost-row-val   { font-size: 0.9rem;  color: #F0F6FF; font-weight: 700; font-family: 'Courier New', monospace; }
        .cg-cost-savings-val { font-size: 0.9rem; color: #4ADE80; font-weight: 700; font-family: 'Courier New', monospace; }

        /* ── Section divider ── */
        .cg-section-label {
            font-size: 0.72rem; color: #8BAAC8; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.1em;
            margin-bottom: 0.55rem; margin-top: 0.1rem;
        }

        /* ── Privacy card ── */
        .cg-privacy {
            background: rgba(0,120,212,0.07);
            border: 1px solid rgba(0,120,212,0.2);
            border-left: 3px solid #0078D4;
            border-radius: 8px;
            padding: 0.75rem 1rem;
            margin-top: 1rem;
        }
        .cg-privacy-title { color: #50E6FF; font-size: 0.85rem; font-weight: 700; margin-bottom: 0.15rem; }
        .cg-privacy-main  { color: #C8D8EC; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.1rem; }
        .cg-privacy-sub   { color: #8BAAC8; font-size: 0.79rem; }

        /* ── Example prompt chips ── */
        .cg-example-label {
            font-size: 0.72rem; color: #8BAAC8; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.08em;
            margin-bottom: 0.5rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def _render_top_header(mode: AppMode) -> None:
    ms_logo = (
        '<svg width="18" height="18" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"'
        ' style="display:inline-block;vertical-align:middle;flex-shrink:0">'
        '<rect x="0" y="0" width="9" height="9" fill="#F25022"/>'
        '<rect x="11" y="0" width="9" height="9" fill="#7FBA00"/>'
        '<rect x="0" y="11" width="9" height="9" fill="#00A4EF"/>'
        '<rect x="11" y="11" width="9" height="9" fill="#FFB900"/>'
        "</svg>"
    )
    azure_logo = (
        '<svg width="14" height="14" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"'
        ' style="display:inline-block;vertical-align:middle;flex-shrink:0">'
        '<path d="M13.2 2.2L3.8 18.6h7.1l2.3-4 3.7 6.4h7.1z" fill="#50E6FF"/>'
        "</svg>"
    )
    if mode == AppMode.AZURE:
        badge_html = '<span class="cg-badge-live">⚡ Azure Live</span>'
    else:
        badge_html = '<span class="cg-badge-demo">Demo Mode</span>'

    st.markdown(
        f"""
        <div class="cg-hero">
            <div class="cg-hero-left">
                {ms_logo}
                <div class="cg-hero-icon">🛡️</div>
                <div>
                    <div class="cg-hero-title">{APP_TITLE}</div>
                    <div class="cg-hero-sub">{APP_SUBTITLE}</div>
                </div>
            </div>
            <div class="cg-hero-right">
                <span class="cg-hero-chip">{azure_logo}&nbsp;Azure AI Foundry</span>
                {badge_html}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _render_header(mode: AppMode) -> None:
    _render_layout_styles()
    _render_top_header(mode)
    if mode == AppMode.DEMO:
        st.info(DEMO_NOTICE)
    else:
        st.success("Azure Mode: Requests are routed live to Azure OpenAI using intelligent complexity-based model selection.")


def _render_examples() -> None:
    st.markdown('<div class="cg-example-label">Quick examples</div>', unsafe_allow_html=True)
    cols = st.columns(4)
    for index, (label, prompt) in enumerate(EXAMPLE_PROMPTS):
        with cols[index]:
            st.button(label, key=f"ex_{index}", on_click=_set_example_prompt, args=(prompt,), width="stretch")


def _routing_badge_html(tier_value: str) -> str:
    if tier_value == "economy":
        return '<span class="cg-routing-badge-eff">✅ Optimized for Efficiency</span>'
    if tier_value == "balanced":
        return '<span class="cg-routing-badge-bal">⚖️ Balanced Selection</span>'
    return '<span class="cg-routing-badge-prem">🧠 Premium Capability</span>'


def _impact_message(tier_value: str) -> str:
    if tier_value == "economy":
        return "This routine request does not require premium reasoning capacity."
    if tier_value == "balanced":
        return "This request benefits from balanced capability for quality and cost."
    return "This workload contains complex technical or business requirements."


def _render_tier_indicator(selected_tier: str) -> None:
    tiers = [
        ("economy",  "⚡", "Economy",  "gpt-5.4-nano"),
        ("balanced", "⚖️", "Balanced", "gpt-5.4-mini"),
        ("advanced", "🧠", "Premium",  "gpt-5.4"),
    ]
    for tier_val, icon, name, model in tiers:
        is_selected = (tier_val == selected_tier)
        row_class = "cg-tier-row cg-tier-row-selected" if is_selected else "cg-tier-row"
        selected_chip = '<span class="cg-tier-selected-chip">✓ SELECTED</span>' if is_selected else ""
        st.markdown(
            f"""
            <div class="{row_class}">
                <span class="cg-tier-icon">{icon}</span>
                <div class="cg-tier-info">
                    <div class="cg-tier-name">{name}</div>
                    <div class="cg-tier-model">{model}</div>
                </div>
                {selected_chip}
            </div>
            """,
            unsafe_allow_html=True,
        )


def _render_cost_impact(costs: CostComparison) -> None:
    if not pricing_available(costs):
        st.caption(pricing_unavailable_caption())
        return

    has_actual = (
        costs.actual_baseline_cost is not None
        and costs.actual_routed_cost is not None
        and costs.actual_savings_amount is not None
    )

    cost_cols = st.columns(2 if has_actual else 1)

    with cost_cols[0]:
        routed_str  = f"${costs.estimated_routed_cost:.6f}"   if costs.estimated_routed_cost   is not None else "—"
        baseline_str = f"${costs.estimated_baseline_cost:.6f}" if costs.estimated_baseline_cost is not None else "—"
        savings_str  = f"${costs.estimated_savings_amount:.6f}" if costs.estimated_savings_amount is not None else "—"
        st.markdown(
            f"""
            <div class="cg-cost-box">
                <div class="cg-cost-box-label">Estimated Cost</div>
                <div class="cg-cost-row">
                    <span class="cg-cost-row-key">Routed (selected model)</span>
                    <span class="cg-cost-row-val">{routed_str}</span>
                </div>
                <div class="cg-cost-row">
                    <span class="cg-cost-row-key">Baseline (premium)</span>
                    <span class="cg-cost-row-val">{baseline_str}</span>
                </div>
                <div class="cg-cost-row" style="border-top:1px solid rgba(255,255,255,0.07);padding-top:0.28rem;margin-top:0.18rem;">
                    <span class="cg-cost-row-key">Cost avoided</span>
                    <span class="cg-cost-savings-val">{savings_str}</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    if has_actual:
        with cost_cols[1]:
            act_routed_str   = f"${costs.actual_routed_cost:.6f}"
            act_baseline_str = f"${costs.actual_baseline_cost:.6f}"
            act_savings_str  = f"${costs.actual_savings_amount:.6f}"
            st.markdown(
                f"""
                <div class="cg-cost-box">
                    <div class="cg-cost-box-label">Actual Usage Cost</div>
                    <div class="cg-cost-row">
                        <span class="cg-cost-row-key">Routed (selected model)</span>
                        <span class="cg-cost-row-val">{act_routed_str}</span>
                    </div>
                    <div class="cg-cost-row">
                        <span class="cg-cost-row-key">Baseline (premium)</span>
                        <span class="cg-cost-row-val">{act_baseline_str}</span>
                    </div>
                    <div class="cg-cost-row" style="border-top:1px solid rgba(255,255,255,0.07);padding-top:0.28rem;margin-top:0.18rem;">
                        <span class="cg-cost-row-key">Cost avoided</span>
                        <span class="cg-cost-savings-val">{act_savings_str}</span>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )


def _render_technical_details(orchestration: OrchestrationResult | None) -> None:
    with st.expander("Admin and Technical Details", expanded=False):
        st.caption("For administrators, architects, FinOps teams, and technical reviewers.")

        if (
            orchestration is None
            or orchestration.prompt_analysis is None
            or orchestration.routing_decision is None
            or orchestration.token_estimate is None
        ):
            st.caption("Run a request to view technical details.")
            return

        analysis  = orchestration.prompt_analysis
        routing   = orchestration.routing_decision
        tokens    = orchestration.token_estimate
        execution = orchestration.execution_result

        st.markdown("**Analysis**")
        st.markdown(
            "\n".join(
                [
                    f"- Workload Type: {_workload_label(analysis.task_category.value)}",
                    f"- Complexity Score: {analysis.adjusted_complexity_score:.1f}",
                    (
                        "- Estimated Usage: "
                        f"{tokens.estimated_input_tokens} input / {tokens.estimated_output_tokens} output / {tokens.estimated_total_tokens} total"
                    ),
                ]
            )
        )

        processing_time = (
            f"{execution.latency_ms} ms"
            if execution is not None and execution.latency_ms is not None
            else "Unavailable"
        )
        status_label = (
            execution_status_label(execution.execution_status)
            if execution is not None
            else "Not Started"
        )

        st.markdown("**Optimization**")
        st.markdown(
            "\n".join(
                [
                    f"- Selected Capability: {_capability_label(routing.recommended_tier.value)}",
                    f"- Decision Source: {_decision_source_label(selection_source_label(routing.selection_source))}",
                    f"- Decision Confidence: {routing.confidence}%",
                ]
            )
        )

        st.markdown("**Execution**")
        st.markdown(f"- Processing Time: {processing_time}")
        st.markdown(f"- Processing Status: {status_label}")
        if execution is not None:
            st.markdown(f"- Request ID: {execution.request_id}")


def main() -> None:
    st.set_page_config(page_title=APP_TITLE, layout="wide")
    _render_sidebar_navigation()
    _ensure_session_state()
    config = _load_config()
    forced_mode = config.runtime.APP_MODE

    _render_header(forced_mode)

    # ── Input card (full width) ──────────────────────────────────────────────
    st.markdown('<div class="cg-card">', unsafe_allow_html=True)
    st.markdown('<div class="cg-card-title">Submit Your Request</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="cg-card-sub">Cost Guardian automatically selects the most cost-effective AI model for your workload.</div>',
        unsafe_allow_html=True,
    )
    _render_examples()

    prompt = st.text_area(
        "Describe your task",
        key="business_need",
        height=160,
        placeholder="Describe the task, question, document, technical problem, or architecture requirement.",
        help="Enter a question, task, document request, technical problem, or architecture requirement.",
    )

    if st.button("Analyze & Route \u2192", type="primary", width="stretch"):
        try:
            if not prompt.strip():
                st.info("Enter a request before selecting Analyze & Route.")
            else:
                with st.spinner("Cost Guardian is analyzing and routing your request..."):
                    orchestration_result = execute_request(
                        PromptRequest(prompt=prompt, app_mode=forced_mode),
                        app_config=config,
                    )
                st.session_state.last_orchestration = orchestration_result
        except Exception as exc:
            _ = exc
            st.error("Unable to generate a result right now. Please try again.")

    st.markdown("</div>", unsafe_allow_html=True)

    # ── Results section ──────────────────────────────────────────────────────
    orchestration: OrchestrationResult | None = st.session_state.last_orchestration

    if orchestration is not None:
        res_col, decision_col, cost_col = st.columns([2, 1.2, 1], gap="medium")

        # Col 1 — AI Response
        with res_col:
            st.markdown('<div class="cg-card" style="height:100%">', unsafe_allow_html=True)
            st.markdown('<div class="cg-card-title">AI Response</div>', unsafe_allow_html=True)
            if orchestration.execution_result is not None:
                execution = orchestration.execution_result
                st.markdown(
                    '<div class="cg-response">'
                    '<div class="cg-response-badge">✅ Response Ready</div>',
                    unsafe_allow_html=True,
                )
                st.markdown(response_text_for_display(execution))
                st.markdown("</div>", unsafe_allow_html=True)
                if forced_mode == AppMode.AZURE:
                    st.caption("Live result from Azure OpenAI via intelligent model routing.")
                else:
                    st.caption("Demonstration result generated locally. No live AI service was called.")
                if execution.error is not None:
                    st.warning(f"A result could not be generated: [{execution.error.category.value}] {execution.error.message}")
            else:
                st.caption("Run a request to view the generated result.")
            st.markdown("</div>", unsafe_allow_html=True)

        # Col 2 — Routing Decision
        with decision_col:
            st.markdown('<div class="cg-card">', unsafe_allow_html=True)
            st.markdown('<div class="cg-card-title">Routing Decision</div>', unsafe_allow_html=True)
            if orchestration.routing_decision is not None and orchestration.prompt_analysis is not None:
                tier_value = orchestration.routing_decision.recommended_tier.value
                st.markdown(_routing_badge_html(tier_value), unsafe_allow_html=True)
                st.caption(_impact_message(tier_value))
                st.markdown('<div class="cg-section-label">Model Selection</div>', unsafe_allow_html=True)
                _render_tier_indicator(tier_value)
                st.markdown('<div class="cg-section-label" style="margin-top:0.8rem">Why this tier?</div>', unsafe_allow_html=True)
                reasons = optimization_reasons(orchestration.prompt_analysis, orchestration.routing_decision.recommended_tier)
                for reason in reasons[:3]:
                    st.markdown(f"- {reason}")
            else:
                st.caption("Submit a request to view the routing decision.")
            st.markdown("</div>", unsafe_allow_html=True)

        # Col 3 — Cost Impact
        with cost_col:
            st.markdown('<div class="cg-card">', unsafe_allow_html=True)
            st.markdown('<div class="cg-card-title">Cost Impact</div>', unsafe_allow_html=True)
            if orchestration.cost_comparison is not None:
                _render_cost_impact(orchestration.cost_comparison)
            else:
                st.caption("Cost data will appear here after the request runs.")
            st.markdown("</div>", unsafe_allow_html=True)

            # Business guardrails mini-card
            st.markdown(
                """
                <div class="cg-card" style="margin-top:0">
                    <div class="cg-card-title" style="margin-bottom:0.6rem">Guardrails</div>
                    <div style="font-size:0.82rem;color:#8BAAC8;margin-bottom:0.3rem">
                        <span style="color:#4ADE80;font-weight:700">✓</span> Explainable Decisions
                    </div>
                    <div style="font-size:0.82rem;color:#8BAAC8;margin-bottom:0.3rem">
                        <span style="color:#4ADE80;font-weight:700">✓</span> Governance Tracking
                    </div>
                    <div style="font-size:0.82rem;color:#8BAAC8;margin-bottom:0.3rem">
                        <span style="color:#4ADE80;font-weight:700">✓</span> Optimization Engine Active
                    </div>
                    <div style="font-size:0.82rem;color:#8BAAC8">
                        <span style="color:#4ADE80;font-weight:700">✓</span> Privacy Protection
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

    st.markdown(
        """
        <div class="cg-privacy">
            <div class="cg-privacy-title">Privacy</div>
            <div class="cg-privacy-main">Your request and generated result are not stored in telemetry.</div>
            <div class="cg-privacy-sub">Only operational metadata is retained for usage reporting. Do not enter confidential, customer-identifiable, or production-sensitive information into this hackathon prototype.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.caption("Hackathon prototype. Not an official Microsoft product.")

    _render_technical_details(orchestration)


if __name__ == "__main__":
    main()
