"""Tests for routing-policy loading and validation created in Prompt 2."""

from pathlib import Path

from config import load_routing_policy


ROUTING_POLICY_PATH = Path("config/routing_policy.json")


def test_routing_policy_loads_from_file() -> None:
    policy, warnings = load_routing_policy(ROUTING_POLICY_PATH)

    assert warnings == []
    assert policy.schema_version == "1.0"
    assert policy.complexity_thresholds.low_to_medium == 4.0
    assert policy.complexity_thresholds.medium_to_high == 7.0
    assert policy.input_limits.max_prompt_characters == 30000


def test_routing_policy_uses_embedded_defaults_when_missing(tmp_path: Path) -> None:
    missing_path = tmp_path / "missing_policy.json"

    policy, warnings = load_routing_policy(missing_path)

    assert policy.schema_version == "1.0"
    assert any("embedded defaults were applied" in warning for warning in warnings)


def test_routing_policy_uses_embedded_defaults_when_malformed_json(tmp_path: Path) -> None:
    malformed_path = tmp_path / "malformed_policy.json"
    malformed_path.write_text("{ invalid json", encoding="utf-8")

    policy, warnings = load_routing_policy(malformed_path)

    assert policy.schema_version == "1.0"
    assert any("malformed JSON" in warning for warning in warnings)


def test_routing_policy_uses_embedded_defaults_when_validation_fails(tmp_path: Path) -> None:
    invalid_path = tmp_path / "invalid_policy.json"
    invalid_path.write_text(
        """
{
  "schema_version": "1.0",
  "complexity_thresholds": {
    "low_to_medium": 8.0,
    "medium_to_high": 7.0
  },
  "task_category_priors": {},
  "complexity_factor_weights": {
    "task_prior": 0.2,
    "prompt_length": 0.2,
    "requested_operations": 0.2,
    "multi_step": 0.1,
    "reasoning_terminology": 0.1,
    "architecture_security_terminology": 0.1,
    "code_generation_indicators": 0.05,
    "requested_output_size": 0.03,
    "requested_output_structure": 0.02
  },
  "minimum_complexity_by_task": {},
  "output_token_ratios_by_task": {},
  "input_limits": {
    "max_prompt_characters": 30000,
    "max_estimated_input_tokens": 8000,
    "max_estimated_output_tokens": 2000
  },
  "confidence_policy": {
    "base_confidence": 85,
    "minimum_confidence": 40,
    "maximum_confidence": 95,
    "boundary_window": 0.5,
    "short_prompt_threshold_characters": 40,
    "boundary_penalty": -20,
    "short_or_ambiguous_penalty": -15,
    "character_fallback_penalty": -10,
    "strong_agreement_bonus": 5
  }
}
""".strip(),
        encoding="utf-8",
    )

    policy, warnings = load_routing_policy(invalid_path)

    assert policy.schema_version == "1.0"
    assert any("failed validation" in warning for warning in warnings)
