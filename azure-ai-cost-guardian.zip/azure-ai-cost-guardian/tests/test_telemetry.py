"""Tests for telemetry data contracts created in Prompt 2."""

import json
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from uuid import uuid4

import pytest
from pydantic import ValidationError

from models.enums import (
    AppMode,
    ComplexityLevel,
    ExecutionStatus,
    LogicalTier,
    SelectionSource,
    TaskCategory,
    TokenEstimationMethod,
    ValueOrigin,
)
from models.response_models import ComplexityFactor, TelemetryRecord
from services.telemetry import persist_telemetry, read_telemetry_records


def _record(*, request_id=None, timestamp_utc=None) -> TelemetryRecord:
    return TelemetryRecord(
        request_id=request_id or uuid4(),
        timestamp_utc=timestamp_utc or datetime.now(timezone.utc),
        app_mode=AppMode.DEMO,
        prompt_character_count=120,
        task_category=TaskCategory.GENERAL_QA,
        complexity_score=3.2,
        complexity_level=ComplexityLevel.LOW,
        complexity_factors=[
            ComplexityFactor(name="prompt_length", contribution=0.2, rationale="Short prompt")
        ],
        token_estimation_method=TokenEstimationMethod.TIKTOKEN,
        estimated_input_tokens=40,
        estimated_output_tokens=20,
        estimated_total_tokens=60,
        actual_input_tokens=40,
        actual_output_tokens=20,
        actual_total_tokens=60,
        recommended_tier=LogicalTier.ECONOMY,
        executed_tier=LogicalTier.ECONOMY,
        selection_source=SelectionSource.RECOMMENDATION,
        estimated_baseline_cost=Decimal("0.0200"),
        estimated_routed_cost=Decimal("0.0050"),
        estimated_savings_amount=Decimal("0.0150"),
        estimated_savings_percentage=Decimal("75.00"),
        actual_baseline_cost=Decimal("0.0200"),
        actual_routed_cost=Decimal("0.0050"),
        actual_savings_amount=Decimal("0.0150"),
        actual_savings_percentage=Decimal("75.00"),
        latency_ms=100,
        execution_status=ExecutionStatus.SUCCESS,
        value_origins={
            "estimated_routed_cost": ValueOrigin.ESTIMATED,
            "actual_routed_cost": ValueOrigin.ACTUAL,
            "latency_ms": ValueOrigin.SYNTHETIC,
        },
    )


def test_telemetry_record_excludes_raw_content_fields() -> None:
    record = _record()

    payload = record.model_dump()
    assert "prompt" not in payload
    assert "response_text" not in payload
    assert "prompt_hash" not in payload
    assert "raw_content_stored" not in payload


def test_telemetry_timestamp_is_timezone_aware_utc() -> None:
    record = TelemetryRecord(
        request_id=uuid4(),
        app_mode=AppMode.DEMO,
        prompt_character_count=50,
        task_category=TaskCategory.EMAIL,
        complexity_score=2.5,
        complexity_level=ComplexityLevel.LOW,
        token_estimation_method=TokenEstimationMethod.ENCODING_FALLBACK,
        estimated_input_tokens=10,
        estimated_output_tokens=10,
        estimated_total_tokens=20,
        recommended_tier=LogicalTier.ECONOMY,
        executed_tier=LogicalTier.ECONOMY,
        selection_source=SelectionSource.RECOMMENDATION,
        execution_status=ExecutionStatus.SUCCESS,
    )

    assert record.timestamp_utc.tzinfo is not None
    assert record.timestamp_utc.utcoffset().total_seconds() == 0


def test_telemetry_rejects_naive_timestamp() -> None:
    with pytest.raises(ValidationError):
        TelemetryRecord(
            request_id=uuid4(),
            timestamp_utc=datetime.now(),
            app_mode=AppMode.DEMO,
            prompt_character_count=50,
            task_category=TaskCategory.EMAIL,
            complexity_score=2.5,
            complexity_level=ComplexityLevel.LOW,
            token_estimation_method=TokenEstimationMethod.ENCODING_FALLBACK,
            estimated_input_tokens=10,
            estimated_output_tokens=10,
            estimated_total_tokens=20,
            recommended_tier=LogicalTier.ECONOMY,
            executed_tier=LogicalTier.ECONOMY,
            selection_source=SelectionSource.RECOMMENDATION,
            execution_status=ExecutionStatus.SUCCESS,
        )


def test_missing_file_returns_empty_records(tmp_path: Path) -> None:
    records = read_telemetry_records(tmp_path / "missing.json")
    assert records == []


def test_empty_file_returns_empty_records(tmp_path: Path) -> None:
    path = tmp_path / "telemetry.json"
    path.write_text("", encoding="utf-8")
    records = read_telemetry_records(path)
    assert records == []


def test_malformed_file_recovers_and_persists(tmp_path: Path) -> None:
    path = tmp_path / "telemetry.json"
    path.write_text("{broken", encoding="utf-8")
    persist_telemetry(_record(), path)
    records = read_telemetry_records(path)
    assert len(records) == 1


def test_atomic_write_uses_replace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    path = tmp_path / "telemetry.json"
    calls: list[tuple[str, str]] = []
    real_replace = __import__("os").replace

    def tracked_replace(src: str | Path, dst: str | Path) -> None:
        calls.append((str(src), str(dst)))
        real_replace(src, dst)

    monkeypatch.setattr("services.telemetry.os.replace", tracked_replace)
    persist_telemetry(_record(), path)
    assert len(calls) == 1
    assert path.exists()


def test_retention_enforcement_removes_expired_and_caps_records(tmp_path: Path) -> None:
    path = tmp_path / "telemetry.json"
    now = datetime.now(timezone.utc)
    stale = _record(timestamp_utc=now - timedelta(days=40))
    recent_one = _record(timestamp_utc=now - timedelta(days=2))
    recent_two = _record(timestamp_utc=now - timedelta(days=1))
    persist_telemetry(stale, path, max_records=5, retention_days=30, now=now)
    persist_telemetry(recent_one, path, max_records=5, retention_days=30, now=now)
    persist_telemetry(recent_two, path, max_records=2, retention_days=30, now=now)

    records = read_telemetry_records(path)
    assert len(records) == 2
    assert all(record.timestamp_utc >= now - timedelta(days=30) for record in records)


def test_no_raw_prompt_or_generated_response_in_stored_json(tmp_path: Path) -> None:
    path = tmp_path / "telemetry.json"
    persist_telemetry(_record(), path)
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(payload, list)
    assert len(payload) == 1
    stored = payload[0]
    assert "prompt" not in stored
    assert "response_text" not in stored
    assert "prompt_hash" not in stored


def test_uuid_request_id_preserved_in_storage(tmp_path: Path) -> None:
    path = tmp_path / "telemetry.json"
    request_id = uuid4()
    persist_telemetry(_record(request_id=request_id), path)
    records = read_telemetry_records(path)
    assert len(records) == 1
    assert records[0].request_id == request_id
