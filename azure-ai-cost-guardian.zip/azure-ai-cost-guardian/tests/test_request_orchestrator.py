"""Tests for local request orchestrator behavior."""

from __future__ import annotations

from pathlib import Path

import pytest

from config import AppConfig, ConfigurationError, ModelPricing, load_app_config
from models.enums import AppMode, ErrorCategory, ExecutionStatus, LogicalTier, SelectionSource, ValueOrigin
from models.request_models import PromptRequest
from models.response_models import ExecutionResult, SafeError
from services.request_orchestrator import execute_request
from services.telemetry import read_telemetry_records


@pytest.fixture()
def demo_config(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> AppConfig:
	monkeypatch.setenv("APP_MODE", "demo")
	monkeypatch.setenv("TELEMETRY_FILE_PATH", str(tmp_path / "telemetry.json"))
	monkeypatch.setenv("TELEMETRY_MAX_RECORDS", "1000")
	monkeypatch.setenv("TELEMETRY_RETENTION_DAYS", "30")
	return load_app_config(allow_unverified_pricing_preview=True)


def _prompt(text: str, app_mode: AppMode = AppMode.DEMO) -> PromptRequest:
	return PromptRequest(prompt=text, app_mode=app_mode)


def _priced_config(base: AppConfig) -> AppConfig:
	priced = ModelPricing.model_validate(
		{
			"schema_version": "1.0",
			"currency": "USD",
			"baseline_tier": "advanced",
			"pricing_note": "test",
			"tiers": {
				"economy": {
					"display_name": "Economy",
					"model_family_hint": "nano",
					"input_price_per_million_tokens": "0.10",
					"output_price_per_million_tokens": "0.20",
					"effective_date_note": "test",
				},
				"balanced": {
					"display_name": "Balanced",
					"model_family_hint": "mini",
					"input_price_per_million_tokens": "0.40",
					"output_price_per_million_tokens": "0.80",
					"effective_date_note": "test",
				},
				"advanced": {
					"display_name": "Advanced",
					"model_family_hint": "4o",
					"input_price_per_million_tokens": "1.00",
					"output_price_per_million_tokens": "2.00",
					"effective_date_note": "test",
				},
			},
		}
	)
	return base.model_copy(update={"model_pricing": priced})


def _unpriced_config(base: AppConfig) -> AppConfig:
	unpriced = ModelPricing.model_validate(
		{
			"schema_version": "1.0",
			"currency": "USD",
			"baseline_tier": "advanced",
			"pricing_note": "test",
			"tiers": {
				"economy": {
					"display_name": "Economy",
					"model_family_hint": "nano",
					"input_price_per_million_tokens": None,
					"output_price_per_million_tokens": None,
					"effective_date_note": "test",
				},
				"balanced": {
					"display_name": "Balanced",
					"model_family_hint": "mini",
					"input_price_per_million_tokens": None,
					"output_price_per_million_tokens": None,
					"effective_date_note": "test",
				},
				"advanced": {
					"display_name": "Advanced",
					"model_family_hint": "4o",
					"input_price_per_million_tokens": None,
					"output_price_per_million_tokens": None,
					"effective_date_note": "test",
				},
			},
		}
	)
	return base.model_copy(update={"model_pricing": unpriced})


def test_end_to_end_local_execution(demo_config: AppConfig, tmp_path: Path) -> None:
	telemetry_path = tmp_path / "telemetry.json"
	result = execute_request(
		_prompt("Summarize these meeting notes into key points."),
		app_config=demo_config,
		telemetry_file_path=telemetry_path,
	)

	assert result.prompt_analysis is not None
	assert result.token_estimate is not None
	assert result.routing_decision is not None
	assert result.execution_result is not None
	assert result.execution_result.execution_status == ExecutionStatus.SUCCESS
	assert result.telemetry_record is not None
	assert telemetry_path.exists()
	assert len(read_telemetry_records(telemetry_path)) == 1


def test_recommendation_path_uses_recommended_tier(demo_config: AppConfig, tmp_path: Path) -> None:
	result = execute_request(
		_prompt("Summarize these meeting notes into key points."),
		app_config=demo_config,
		telemetry_file_path=tmp_path / "telemetry.json",
	)

	assert result.routing_decision is not None
	assert result.execution_result is not None
	assert result.execution_result.executed_tier == result.routing_decision.recommended_tier
	assert result.execution_result.selection_source == SelectionSource.RECOMMENDATION


def test_user_override_path(demo_config: AppConfig, tmp_path: Path) -> None:
	result = execute_request(
		_prompt("Summarize these meeting notes into key points."),
		user_selected_tier=LogicalTier.ADVANCED,
		app_config=demo_config,
		telemetry_file_path=tmp_path / "telemetry.json",
	)

	assert result.execution_result is not None
	assert result.execution_result.executed_tier == LogicalTier.ADVANCED
	assert result.execution_result.selection_source == SelectionSource.USER_OVERRIDE


def test_invalid_override_rejected(demo_config: AppConfig, tmp_path: Path) -> None:
	with pytest.raises(ValueError, match="invalid"):
		execute_request(
			_prompt("Summarize these meeting notes into key points."),
			user_selected_tier="not-a-tier",
			app_config=demo_config,
			telemetry_file_path=tmp_path / "telemetry.json",
		)


def test_unavailable_tier_handling_blocks_execution(demo_config: AppConfig, tmp_path: Path) -> None:
	telemetry_path = tmp_path / "telemetry.json"
	result = execute_request(
		_prompt("Design an Azure architecture with an application tier, database, monitoring, and high availability."),
		app_config=demo_config,
		configured_tiers={LogicalTier.ECONOMY},
		telemetry_file_path=telemetry_path,
	)

	assert result.routing_decision is not None
	assert result.routing_decision.recommended_tier == LogicalTier.BALANCED
	assert result.execution_result is not None
	assert result.execution_result.execution_status == ExecutionStatus.BLOCKED
	assert result.execution_result.response_text is None
	assert result.telemetry_record is not None
	assert len(read_telemetry_records(telemetry_path)) == 1


def test_cost_calculation_integration_with_verified_pricing(demo_config: AppConfig, tmp_path: Path) -> None:
	result = execute_request(
		_prompt("Write code for a Python function class validator."),
		app_config=_priced_config(demo_config),
		telemetry_file_path=tmp_path / "telemetry.json",
	)

	assert result.cost_comparison is not None
	assert result.cost_comparison.estimated_routed_cost is not None
	assert result.cost_comparison.actual_routed_cost is not None
	assert result.telemetry_record is not None
	assert result.telemetry_record.value_origins["estimated_routed_cost"] == ValueOrigin.ESTIMATED
	assert result.telemetry_record.value_origins["actual_routed_cost"] == ValueOrigin.ACTUAL


def test_telemetry_creation_preserves_request_id(demo_config: AppConfig, tmp_path: Path) -> None:
	request = _prompt("What is tokenization?")
	result = execute_request(
		request,
		app_config=demo_config,
		telemetry_file_path=tmp_path / "telemetry.json",
	)

	assert result.telemetry_record is not None
	assert result.telemetry_record.request_id == request.request_id


def test_azure_mode_is_blocked_without_azure_execution(demo_config: AppConfig, tmp_path: Path) -> None:
	blocked_config = _priced_config(demo_config).model_copy(
		update={
			"runtime": _priced_config(demo_config).runtime.model_copy(
				update={
					"DEPLOYMENT_ECONOMY": "",
					"DEPLOYMENT_BALANCED": "",
					"DEPLOYMENT_ADVANCED": "",
				}
			)
		}
	)
	result = execute_request(
		_prompt("Explain the difference between TLS and mTLS.", app_mode=AppMode.AZURE),
		app_config=blocked_config,
		telemetry_file_path=tmp_path / "telemetry.json",
	)

	assert result.execution_result is not None
	assert result.execution_result.execution_status == ExecutionStatus.BLOCKED
	assert result.execution_result.error is not None
	assert result.execution_result.error.category == ErrorCategory.DEPLOYMENT_UNAVAILABLE


def test_azure_mode_with_unverified_pricing_rejected(demo_config: AppConfig, tmp_path: Path) -> None:
	with pytest.raises(ConfigurationError):
		execute_request(
			_prompt("Explain the difference between TLS and mTLS.", app_mode=AppMode.AZURE),
			app_config=_unpriced_config(demo_config),
			telemetry_file_path=tmp_path / "telemetry.json",
		)


def test_orchestrator_azure_mode_path(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
	monkeypatch.setenv("APP_MODE", "azure")
	monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://example.openai.azure.com")
	monkeypatch.setenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
	monkeypatch.setenv("AZURE_OPENAI_API_KEY", "test-key")
	monkeypatch.setenv("DEPLOYMENT_ECONOMY", "dep-economy")
	monkeypatch.setenv("DEPLOYMENT_BALANCED", "dep-balanced")
	monkeypatch.setenv("DEPLOYMENT_ADVANCED", "dep-advanced")
	monkeypatch.setenv("TELEMETRY_FILE_PATH", str(tmp_path / "telemetry.json"))
	config = _priced_config(load_app_config(allow_unverified_pricing_preview=True))

	def fake_execute_azure_request(request, app_config):
		return ExecutionResult(
			request_id=request.request_id,
			app_mode=request.app_mode,
			execution_status=ExecutionStatus.SUCCESS,
			executed_tier=request.selected_tier,
			selection_source=request.selection_source,
			response_text="Azure content",
			latency_ms=321,
			actual_input_tokens=111,
			actual_output_tokens=222,
			actual_total_tokens=333,
			value_origins={
				"response_text": ValueOrigin.ACTUAL,
				"latency_ms": ValueOrigin.ACTUAL,
				"actual_input_tokens": ValueOrigin.ACTUAL,
				"actual_output_tokens": ValueOrigin.ACTUAL,
				"actual_total_tokens": ValueOrigin.ACTUAL,
			},
		)

	monkeypatch.setattr("services.request_orchestrator.execute_azure_request", fake_execute_azure_request)

	result = execute_request(
		_prompt("Explain the difference between TLS and mTLS.", app_mode=AppMode.AZURE),
		app_config=config,
		telemetry_file_path=tmp_path / "telemetry.json",
	)

	assert result.execution_result is not None
	assert result.execution_result.execution_status == ExecutionStatus.SUCCESS
	assert result.execution_result.response_text == "Azure content"
	assert result.cost_comparison is not None
	assert result.cost_comparison.actual_routed_cost is not None


def test_orchestrator_demo_mode_path(monkeypatch: pytest.MonkeyPatch, demo_config: AppConfig, tmp_path: Path) -> None:
	called = {"demo": False, "azure": False}

	def fake_generate_demo_response(request):
		called["demo"] = True
		return ExecutionResult(
			request_id=request.request_id,
			app_mode=request.app_mode,
			execution_status=ExecutionStatus.SUCCESS,
			executed_tier=request.selected_tier,
			selection_source=request.selection_source,
			response_text="Demo Mode Synthetic Response\nBody",
			latency_ms=123,
			actual_input_tokens=10,
			actual_output_tokens=5,
			actual_total_tokens=15,
			value_origins={
				"response_text": ValueOrigin.SYNTHETIC,
				"latency_ms": ValueOrigin.SYNTHETIC,
				"actual_input_tokens": ValueOrigin.SYNTHETIC,
				"actual_output_tokens": ValueOrigin.SYNTHETIC,
				"actual_total_tokens": ValueOrigin.SYNTHETIC,
			},
		)

	def fake_execute_azure_request(request, app_config):
		called["azure"] = True
		return ExecutionResult(
			request_id=request.request_id,
			app_mode=request.app_mode,
			execution_status=ExecutionStatus.FAILED,
			error=SafeError(category=ErrorCategory.UNKNOWN, message="should not be called"),
		)

	monkeypatch.setattr("services.request_orchestrator.generate_demo_response", fake_generate_demo_response)
	monkeypatch.setattr("services.request_orchestrator.execute_azure_request", fake_execute_azure_request)

	result = execute_request(
		_prompt("Summarize these meeting notes into key points."),
		app_config=demo_config,
		telemetry_file_path=tmp_path / "telemetry.json",
	)

	assert called["demo"] is True
	assert called["azure"] is False
	assert result.execution_result is not None
	assert result.execution_result.execution_status == ExecutionStatus.SUCCESS
