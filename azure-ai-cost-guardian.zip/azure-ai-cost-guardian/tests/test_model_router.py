"""Tests for model router deterministic behavior and no-fallback policy."""

from __future__ import annotations

import pytest

from config import load_routing_policy
from models.enums import (
	ComplexityLevel,
	ErrorCategory,
	ExecutionStatus,
	LogicalTier,
	SelectionSource,
	TaskCategory,
	TokenEstimationMethod,
)
from models.request_models import AnalysisRequest, PromptRequest
from models.response_models import (
	ConfidenceAdjustment,
	PromptAnalysis,
	RoutingDecision,
	TokenEstimate,
)
from services.model_router import recommend_tier, resolve_executed_tier
from services.prompt_analyzer import analyze_prompt
from services.token_estimator import estimate_tokens


@pytest.fixture()
def policy():
	loaded, _ = load_routing_policy()
	return loaded


def _analysis(score: float, *, short: bool = False, ambiguous: bool = False, strong: bool = False) -> PromptAnalysis:
	return PromptAnalysis(
		prompt_character_count=100,
		meaningful_word_count=10,
		task_category=TaskCategory.GENERAL_QA,
		raw_complexity_score=score,
		adjusted_complexity_score=score,
		complexity_score=score,
		complexity_level=(
			ComplexityLevel.LOW if score < 4.0 else ComplexityLevel.MEDIUM if score < 7.0 else ComplexityLevel.HIGH
		),
		explanation="test",
		complexity_factors=[],
		classification_evidence={TaskCategory.GENERAL_QA: 1},
		is_short_prompt=short,
		is_ambiguous=ambiguous,
		strong_agreement=strong,
	)


def _tokens(method: TokenEstimationMethod = TokenEstimationMethod.TIKTOKEN) -> TokenEstimate:
	return TokenEstimate(
		method=method,
		estimated_input_tokens=100,
		estimated_output_tokens=50,
		estimated_total_tokens=150,
		explanation="test",
	)


@pytest.mark.parametrize(
	("score", "tier"),
	[
		(3.9, LogicalTier.ECONOMY),
		(4.0, LogicalTier.BALANCED),
		(6.9, LogicalTier.BALANCED),
		(7.0, LogicalTier.ADVANCED),
	],
)
def test_routing_by_score_boundaries(score: float, tier: LogicalTier, policy) -> None:
	decision = recommend_tier(_analysis(score), _tokens(), policy)
	assert decision.recommended_tier == tier


@pytest.mark.parametrize("score", [3.5, 4.5, 6.5, 7.5])
def test_boundary_penalty_applies(score: float, policy) -> None:
	decision = recommend_tier(_analysis(score), _tokens(), policy)
	boundary = next(a for a in decision.confidence_adjustments if a.name == "boundary_window_penalty")
	assert boundary.applied is True


@pytest.mark.parametrize("score", [3.4, 7.6])
def test_boundary_penalty_not_applied_outside_window(score: float, policy) -> None:
	decision = recommend_tier(_analysis(score), _tokens(), policy)
	boundary = next(a for a in decision.confidence_adjustments if a.name == "boundary_window_penalty")
	assert boundary.applied is False


def test_short_or_ambiguous_penalty_applied_once_when_both_true(policy) -> None:
	decision = recommend_tier(_analysis(5.5, short=True, ambiguous=True), _tokens(), policy)
	penalty = next(a for a in decision.confidence_adjustments if a.name == "short_or_ambiguous_penalty")
	assert penalty.applied is True
	assert decision.confidence == 70


def test_character_fallback_penalty(policy) -> None:
	decision = recommend_tier(_analysis(5.5), _tokens(TokenEstimationMethod.CHARACTER_FALLBACK), policy)
	penalty = next(a for a in decision.confidence_adjustments if a.name == "character_fallback_penalty")
	assert penalty.applied is True
	assert decision.confidence == 75


def test_strong_agreement_bonus(policy) -> None:
	decision = recommend_tier(_analysis(5.5, strong=True), _tokens(), policy)
	bonus = next(a for a in decision.confidence_adjustments if a.name == "strong_agreement_bonus")
	assert bonus.applied is True
	assert decision.confidence == 90


def test_multiple_adjustments_combine_additively(policy) -> None:
	decision = recommend_tier(
		_analysis(3.5, short=True, ambiguous=True, strong=True),
		_tokens(TokenEstimationMethod.CHARACTER_FALLBACK),
		policy,
	)
	assert decision.confidence == 45


def test_confidence_clamps_minimum(policy) -> None:
	decision = recommend_tier(
		_analysis(3.5, short=True, ambiguous=True, strong=False),
		_tokens(TokenEstimationMethod.CHARACTER_FALLBACK),
		policy,
	)
	assert decision.confidence == policy.confidence_policy.minimum_confidence


def test_confidence_clamps_maximum(policy) -> None:
	decision = recommend_tier(_analysis(5.5, strong=True), _tokens(), policy)
	assert decision.confidence <= policy.confidence_policy.maximum_confidence


def test_confidence_explanation_mentions_routing_confidence(policy) -> None:
	decision = recommend_tier(_analysis(5.5), _tokens(), policy)
	assert "routing recommendation" in decision.confidence_explanation.lower()
	assert "not generated-response correctness" in decision.confidence_scope.lower()


def test_recommendation_acceptance(policy) -> None:
	executed, source, status, error, _ = resolve_executed_tier(
		recommended_tier=LogicalTier.BALANCED,
		user_selected_tier=None,
		configured_tiers={LogicalTier.ECONOMY, LogicalTier.BALANCED, LogicalTier.ADVANCED},
	)
	assert executed == LogicalTier.BALANCED
	assert source == SelectionSource.RECOMMENDATION
	assert status == ExecutionStatus.NOT_STARTED
	assert error is None


def test_same_tier_selection_remains_recommendation() -> None:
	executed, source, *_ = resolve_executed_tier(
		recommended_tier=LogicalTier.BALANCED,
		user_selected_tier=LogicalTier.BALANCED,
		configured_tiers={LogicalTier.BALANCED, LogicalTier.ADVANCED},
	)
	assert executed == LogicalTier.BALANCED
	assert source == SelectionSource.RECOMMENDATION


def test_different_valid_tier_becomes_user_override() -> None:
	executed, source, *_ = resolve_executed_tier(
		recommended_tier=LogicalTier.BALANCED,
		user_selected_tier=LogicalTier.ADVANCED,
		configured_tiers={LogicalTier.BALANCED, LogicalTier.ADVANCED},
	)
	assert executed == LogicalTier.ADVANCED
	assert source == SelectionSource.USER_OVERRIDE


def test_invalid_user_selection_rejected() -> None:
	with pytest.raises(ValueError):
		resolve_executed_tier(
			recommended_tier=LogicalTier.BALANCED,
			user_selected_tier=LogicalTier.ECONOMY,
			configured_tiers={LogicalTier.BALANCED, LogicalTier.ADVANCED},
		)


def test_recommended_unconfigured_tier_blocks_execution(policy) -> None:
	decision = recommend_tier(
		_analysis(7.2),
		_tokens(),
		policy,
		configured_tiers={LogicalTier.ECONOMY, LogicalTier.BALANCED},
	)
	assert decision.recommended_tier == LogicalTier.ADVANCED
	assert decision.execution_status == ExecutionStatus.BLOCKED
	assert decision.error_category == ErrorCategory.DEPLOYMENT_UNAVAILABLE
	assert LogicalTier.BALANCED in decision.configured_alternatives


def test_no_automatic_fallback_occurs() -> None:
	executed, source, status, _, alternatives = resolve_executed_tier(
		recommended_tier=LogicalTier.ADVANCED,
		user_selected_tier=None,
		configured_tiers={LogicalTier.ECONOMY, LogicalTier.BALANCED},
	)
	assert executed is None
	assert source is None
	assert status == ExecutionStatus.BLOCKED
	assert alternatives == [LogicalTier.BALANCED, LogicalTier.ECONOMY]


def test_regulated_architecture_routes_to_advanced(policy) -> None:
	prompt = (
		"Design a secure multi-region Azure AI landing zone for a healthcare organization with private connectivity, "
		"identity governance, monitoring, disaster recovery, and compliance controls."
	)
	prompt_request = PromptRequest(prompt=prompt)
	seed = analyze_prompt(AnalysisRequest(prompt_request=prompt_request), policy)
	tokens = estimate_tokens(prompt_request, policy, seed.task_category)
	analysis = analyze_prompt(
		AnalysisRequest(prompt_request=prompt_request, estimated_input_tokens=tokens.estimated_input_tokens),
		policy,
	)
	decision = recommend_tier(analysis, tokens, policy)
	assert analysis.complexity_level == ComplexityLevel.HIGH
	assert decision.recommended_tier == LogicalTier.ADVANCED
	assert any(
		"Regulated or security-sensitive architecture elevated to High" in r
		for r in analysis.applied_policy_rules
	)


def test_moderate_architecture_routes_to_balanced(policy) -> None:
	prompt = "Design an Azure architecture with an application tier, database, monitoring, and high availability."
	prompt_request = PromptRequest(prompt=prompt)
	seed = analyze_prompt(AnalysisRequest(prompt_request=prompt_request), policy)
	tokens = estimate_tokens(prompt_request, policy, seed.task_category)
	analysis = analyze_prompt(
		AnalysisRequest(prompt_request=prompt_request, estimated_input_tokens=tokens.estimated_input_tokens),
		policy,
	)
	decision = recommend_tier(analysis, tokens, policy)
	assert analysis.complexity_level == ComplexityLevel.MEDIUM
	assert decision.recommended_tier == LogicalTier.BALANCED
