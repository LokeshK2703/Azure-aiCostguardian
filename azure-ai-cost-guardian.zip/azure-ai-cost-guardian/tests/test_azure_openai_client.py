"""Tests for Azure OpenAI client adapter behavior."""

from __future__ import annotations

from types import SimpleNamespace
from uuid import uuid4

import httpx
import pytest
from openai import APIConnectionError, APIError, APITimeoutError, AuthenticationError, BadRequestError, NotFoundError

from config import AppConfig, ModelPricing, load_app_config
from models.enums import AppMode, ErrorCategory, ExecutionStatus, LogicalTier, SelectionSource, ValueOrigin
from models.request_models import ExecutionRequest
from services.azure_openai_client import execute_azure_request


@pytest.fixture()
def azure_config(monkeypatch: pytest.MonkeyPatch, tmp_path) -> AppConfig:
	monkeypatch.setenv("APP_MODE", "azure")
	monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://example.openai.azure.com")
	monkeypatch.setenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
	monkeypatch.setenv("AZURE_OPENAI_API_KEY", "test-key")
	monkeypatch.setenv("DEPLOYMENT_ECONOMY", "dep-economy")
	monkeypatch.setenv("DEPLOYMENT_BALANCED", "dep-balanced")
	monkeypatch.setenv("DEPLOYMENT_ADVANCED", "dep-advanced")
	monkeypatch.setenv("TELEMETRY_FILE_PATH", str(tmp_path / "telemetry.json"))
	priced = ModelPricing.model_validate(
		{
			"schema_version": "1.0",
			"currency": "USD",
			"baseline_tier": "advanced",
			"pricing_note": "test",
			"tiers": {
				"economy": {
					"display_name": "Economy",
					"model_family_hint": "nano",
					"input_price_per_million_tokens": "0.10",
					"output_price_per_million_tokens": "0.20",
					"effective_date_note": "test",
				},
				"balanced": {
					"display_name": "Balanced",
					"model_family_hint": "mini",
					"input_price_per_million_tokens": "0.40",
					"output_price_per_million_tokens": "0.80",
					"effective_date_note": "test",
				},
				"advanced": {
					"display_name": "Advanced",
					"model_family_hint": "4o",
					"input_price_per_million_tokens": "1.00",
					"output_price_per_million_tokens": "2.00",
					"effective_date_note": "test",
				},
			},
		}
	)
	config = load_app_config(allow_unverified_pricing_preview=True)
	return config.model_copy(update={"model_pricing": priced})


def _response_obj(status_code: int = 401) -> httpx.Response:
	request = httpx.Request("POST", "https://example.openai.azure.com/openai/deployments/test/chat/completions")
	return httpx.Response(status_code=status_code, request=request)


def _request_obj() -> httpx.Request:
	return httpx.Request("POST", "https://example.openai.azure.com/openai/deployments/test/chat/completions")


def _request(tier: LogicalTier = LogicalTier.BALANCED) -> ExecutionRequest:
	return ExecutionRequest(
		request_id=uuid4(),
		prompt="Explain the difference between TLS and mTLS.",
		app_mode=AppMode.AZURE,
		selected_tier=tier,
		selection_source=SelectionSource.RECOMMENDATION,
	)


def _response(content: str = "Azure response", prompt_tokens: int | None = 10, completion_tokens: int | None = 20, total_tokens: int | None = 30):
	usage = None
	if prompt_tokens is not None or completion_tokens is not None or total_tokens is not None:
		usage = SimpleNamespace(
			prompt_tokens=prompt_tokens,
			completion_tokens=completion_tokens,
			total_tokens=total_tokens,
		)
	return SimpleNamespace(
		choices=[SimpleNamespace(message=SimpleNamespace(content=content))],
		usage=usage,
	)


def test_successful_execution(monkeypatch: pytest.MonkeyPatch, azure_config: AppConfig) -> None:
	called: dict[str, object] = {}

	class FakeClient:
		def __init__(self, **kwargs):
			called["kwargs"] = kwargs
			self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

		def create(self, **kwargs):
			called["create"] = kwargs
			return _response()

	monkeypatch.setattr("services.azure_openai_client.AzureOpenAI", FakeClient)
	monkeypatch.setattr("services.azure_openai_client.perf_counter", lambda: 10.0 if "create" not in called else 10.25)

	result = execute_azure_request(_request(), azure_config)

	assert result.execution_status == ExecutionStatus.SUCCESS
	assert result.response_text == "Azure response"
	assert result.actual_input_tokens == 10
	assert result.actual_output_tokens == 20
	assert result.actual_total_tokens == 30
	assert result.latency_ms == 250
	assert called["create"]["model"] == "dep-balanced"
	assert result.value_origins["response_text"] == ValueOrigin.ACTUAL


def test_usage_metadata_mapping(monkeypatch: pytest.MonkeyPatch, azure_config: AppConfig) -> None:
	class FakeClient:
		def __init__(self, **kwargs):
			self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

		def create(self, **kwargs):
			return _response(prompt_tokens=12, completion_tokens=34, total_tokens=46)

	monkeypatch.setattr("services.azure_openai_client.AzureOpenAI", FakeClient)
	monkeypatch.setattr("services.azure_openai_client.perf_counter", lambda: 1.0)

	result = execute_azure_request(_request(LogicalTier.ADVANCED), azure_config)

	assert result.actual_input_tokens == 12
	assert result.actual_output_tokens == 34
	assert result.actual_total_tokens == 46
	assert result.executed_tier == LogicalTier.ADVANCED


def test_missing_usage_metadata(monkeypatch: pytest.MonkeyPatch, azure_config: AppConfig) -> None:
	class FakeClient:
		def __init__(self, **kwargs):
			self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

		def create(self, **kwargs):
			return _response(prompt_tokens=None, completion_tokens=None, total_tokens=None)

	monkeypatch.setattr("services.azure_openai_client.AzureOpenAI", FakeClient)
	monkeypatch.setattr("services.azure_openai_client.perf_counter", lambda: 2.0)

	result = execute_azure_request(_request(), azure_config)

	assert result.execution_status == ExecutionStatus.SUCCESS
	assert result.actual_input_tokens is None
	assert result.value_origins["actual_input_tokens"] == ValueOrigin.UNAVAILABLE


def test_authentication_failure(monkeypatch: pytest.MonkeyPatch, azure_config: AppConfig) -> None:
	class FakeClient:
		def __init__(self, **kwargs):
			self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

		def create(self, **kwargs):
			raise AuthenticationError("bad key", response=_response_obj(401), body=None)

	monkeypatch.setattr("services.azure_openai_client.AzureOpenAI", FakeClient)

	result = execute_azure_request(_request(), azure_config)

	assert result.execution_status == ExecutionStatus.BLOCKED
	assert result.error is not None
	assert result.error.category == ErrorCategory.AUTHENTICATION


def test_deployment_unavailable(monkeypatch: pytest.MonkeyPatch, azure_config: AppConfig) -> None:
	class FakeClient:
		def __init__(self, **kwargs):
			self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

		def create(self, **kwargs):
			raise NotFoundError("missing", response=_response_obj(404), body=None)

	monkeypatch.setattr("services.azure_openai_client.AzureOpenAI", FakeClient)

	result = execute_azure_request(_request(), azure_config)

	assert result.execution_status == ExecutionStatus.BLOCKED
	assert result.error is not None
	assert result.error.category == ErrorCategory.DEPLOYMENT_UNAVAILABLE


def test_timeout(monkeypatch: pytest.MonkeyPatch, azure_config: AppConfig) -> None:
	class FakeClient:
		def __init__(self, **kwargs):
			self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

		def create(self, **kwargs):
			raise APITimeoutError(request=_request_obj())

	monkeypatch.setattr("services.azure_openai_client.AzureOpenAI", FakeClient)

	result = execute_azure_request(_request(), azure_config)

	assert result.execution_status == ExecutionStatus.FAILED
	assert result.error is not None
	assert result.error.category == ErrorCategory.TIMEOUT


def test_network_failure(monkeypatch: pytest.MonkeyPatch, azure_config: AppConfig) -> None:
	class FakeClient:
		def __init__(self, **kwargs):
			self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

		def create(self, **kwargs):
			raise APIConnectionError(message="offline", request=None)

	monkeypatch.setattr("services.azure_openai_client.AzureOpenAI", FakeClient)

	result = execute_azure_request(_request(), azure_config)

	assert result.execution_status == ExecutionStatus.FAILED
	assert result.error is not None
	assert result.error.category == ErrorCategory.NETWORK


def test_service_failure(monkeypatch: pytest.MonkeyPatch, azure_config: AppConfig) -> None:
	class FakeClient:
		def __init__(self, **kwargs):
			self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

		def create(self, **kwargs):
			raise APIError("boom", request=_request_obj(), body=None)

	monkeypatch.setattr("services.azure_openai_client.AzureOpenAI", FakeClient)

	result = execute_azure_request(_request(), azure_config)

	assert result.execution_status == ExecutionStatus.FAILED
	assert result.error is not None
	assert result.error.category == ErrorCategory.SERVICE


def test_no_automatic_fallback(monkeypatch: pytest.MonkeyPatch, azure_config: AppConfig) -> None:
	models: list[str] = []

	class FakeClient:
		def __init__(self, **kwargs):
			self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

		def create(self, **kwargs):
			models.append(kwargs["model"])
			raise BadRequestError("bad deployment", response=_response_obj(400), body=None)

	monkeypatch.setattr("services.azure_openai_client.AzureOpenAI", FakeClient)

	result = execute_azure_request(_request(LogicalTier.ADVANCED), azure_config)

	assert models == ["dep-advanced"]
	assert result.error is not None
	assert result.error.category == ErrorCategory.DEPLOYMENT_UNAVAILABLE
