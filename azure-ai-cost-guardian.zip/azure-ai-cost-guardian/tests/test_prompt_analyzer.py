"""Tests for prompt analyzer deterministic behavior."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from config import load_routing_policy
from models.enums import ComplexityLevel, TaskCategory
from models.request_models import AnalysisRequest, PromptRequest
from services.prompt_analyzer import _to_level, analyze_prompt


@pytest.fixture()
def policy():
	loaded, _ = load_routing_policy()
	return loaded


def _analyze(prompt: str, policy, estimated_tokens: int | None = None):
	request = AnalysisRequest(prompt_request=PromptRequest(prompt=prompt), estimated_input_tokens=estimated_tokens)
	return analyze_prompt(request, policy)


def _factor_value(result, name: str) -> float:
	for factor in result.complexity_factors:
		if factor.name == name:
			return float(factor.normalized_value or 0.0)
	raise AssertionError(f"Missing factor {name}")


def test_empty_prompt_rejected(policy) -> None:
	with pytest.raises(ValidationError):
		PromptRequest(prompt="")


def test_whitespace_prompt_rejected(policy) -> None:
	with pytest.raises(ValidationError):
		PromptRequest(prompt="   ")


def test_prompt_exceeding_character_limit_rejected(policy) -> None:
	p = policy.model_copy(deep=True)
	p.input_limits.max_prompt_characters = 10
	with pytest.raises(ValueError, match="max_prompt_characters"):
		_analyze("This prompt exceeds ten chars.", p)


def test_estimated_input_tokens_limit_rejected(policy) -> None:
	p = policy.model_copy(deep=True)
	p.input_limits.max_estimated_input_tokens = 5
	with pytest.raises(ValueError, match="max_estimated_input_tokens"):
		_analyze("Summarize this", p, estimated_tokens=6)


@pytest.mark.parametrize(
	("prompt", "expected"),
	[
		("Summarize these meeting notes into key points.", TaskCategory.SUMMARIZATION),
		("Draft an email reply with a subject line.", TaskCategory.EMAIL),
		("Create a readme and runbook guide for setup.", TaskCategory.DOCUMENTATION),
		("Explain the difference between TLS and mTLS.", TaskCategory.TECHNICAL_EXPLANATION),
		("Design a multi-region architecture with disaster recovery.", TaskCategory.ARCHITECTURE_DESIGN),
		("Write code for a Python function class validator.", TaskCategory.CODE_GENERATION),
		("What is tokenization?", TaskCategory.GENERAL_QA),
	],
)
def test_task_classification(prompt: str, expected: TaskCategory, policy) -> None:
	result = _analyze(prompt, policy)
	assert result.task_category == expected


def test_multi_word_phrase_detection(policy) -> None:
	result = _analyze("Please provide key points from these notes.", policy)
	assert result.task_category == TaskCategory.SUMMARIZATION


def test_category_tie_precedence(policy) -> None:
	result = _analyze("Design architecture and implement.", policy)
	assert result.task_category == TaskCategory.ARCHITECTURE_DESIGN
	assert result.category_precedence_used is True


def test_complexity_factors_normalized_and_weighted(policy) -> None:
	result = _analyze("Explain and compare alternatives with a JSON table output.", policy)
	assert all(0.0 <= (factor.normalized_value or 0.0) <= 1.0 for factor in result.complexity_factors)
	assert all((factor.weight or 0.0) >= 0.0 for factor in result.complexity_factors)


def test_weighted_factor_sum_behavior(policy) -> None:
	result = _analyze("Explain root cause and recommend a strategy in multiple sections.", policy)
	contribution_sum = sum(factor.contribution for factor in result.complexity_factors)
	assert result.raw_complexity_score == round(min(10.0, max(0.0, 10.0 * contribution_sum)), 1)


def test_complexity_level_boundaries() -> None:
	assert _to_level(3.9, 4.0, 7.0) == ComplexityLevel.LOW
	assert _to_level(4.0, 4.0, 7.0) == ComplexityLevel.MEDIUM
	assert _to_level(6.9, 4.0, 7.0) == ComplexityLevel.MEDIUM
	assert _to_level(7.0, 4.0, 7.0) == ComplexityLevel.HIGH
	assert _to_level(10.0, 4.0, 7.0) == ComplexityLevel.HIGH


def test_architecture_minimum_medium_floor(policy) -> None:
	result = _analyze("architecture", policy)
	assert result.adjusted_complexity_score >= policy.complexity_thresholds.low_to_medium
	assert result.complexity_level in (ComplexityLevel.MEDIUM, ComplexityLevel.HIGH)


def test_code_generation_minimum_medium_floor(policy) -> None:
	result = _analyze("write code", policy)
	assert result.adjusted_complexity_score >= policy.complexity_thresholds.low_to_medium


def test_security_sensitive_technical_analysis_elevates_high(policy) -> None:
	result = _analyze(
		"Explain root cause and evaluate security compliance, governance, identity, and network resilience strategy.",
		policy,
	)
	assert result.complexity_level == ComplexityLevel.HIGH


def test_simple_summarization_remains_low(policy) -> None:
	result = _analyze("Summarize this transcript.", policy)
	assert result.complexity_level == ComplexityLevel.LOW


def test_raw_and_adjusted_score_distinction(policy) -> None:
	result = _analyze("architecture", policy)
	assert result.raw_complexity_score <= result.adjusted_complexity_score
	assert len(result.applied_policy_rules) >= 1


def test_short_prompt_boundary_exactly_40_not_short(policy) -> None:
	prompt = "x" * 40
	result = _analyze(prompt, policy)
	assert result.is_short_prompt is False


def test_short_prompt_less_than_40_is_short(policy) -> None:
	result = _analyze("x" * 39, policy)
	assert result.is_short_prompt is True


def test_ambiguous_short_prompt_detection(policy) -> None:
	result = _analyze("this thing", policy)
	assert result.is_ambiguous is True
	assert any("Fewer than three meaningful words" in reason for reason in result.ambiguity_reasons)


def test_deictic_prompt_detection(policy) -> None:
	result = _analyze("fix it", policy)
	assert result.is_ambiguous is True
	assert any("deictic" in reason.lower() for reason in result.ambiguity_reasons)


def test_competing_category_ambiguity(policy) -> None:
	result = _analyze(
		"architecture implement summarize",
		policy,
	)
	assert result.is_ambiguous is True


def test_strong_agreement_true(policy) -> None:
	result = _analyze(
		"Write code and implement a Python function class with JSON output.",
		policy,
	)
	assert result.strong_agreement is True


def test_strong_agreement_false(policy) -> None:
	result = _analyze("Do this", policy)
	assert result.strong_agreement is False


def test_no_raw_prompt_in_analysis_result(policy) -> None:
	prompt = "Summarize these notes"
	result = _analyze(prompt, policy)
	dumped = result.model_dump()
	assert "prompt" not in dumped
	assert prompt not in str(dumped)


def test_basic_architecture_prompt_medium_by_floor(policy) -> None:
	basic = _analyze("Create a basic architecture diagram for a small web application.", policy)
	assert basic.task_category == TaskCategory.ARCHITECTURE_DESIGN
	assert basic.complexity_level == ComplexityLevel.MEDIUM
	assert basic.adjusted_complexity_score >= 4.0


def test_moderate_architecture_scores_higher_than_basic(policy) -> None:
	basic = _analyze("Create a basic architecture diagram for a small web application.", policy)
	moderate = _analyze(
		"Design an Azure architecture with an application tier, database, monitoring, and high availability.",
		policy,
	)
	assert moderate.raw_complexity_score > basic.raw_complexity_score


def test_regulated_architecture_scores_higher_than_moderate(policy) -> None:
	moderate = _analyze(
		"Design an Azure architecture with an application tier, database, monitoring, and high availability.",
		policy,
	)
	regulated = _analyze(
		"Design a secure multi-region Azure AI landing zone for a healthcare organization with private connectivity, identity governance, monitoring, disaster recovery, and compliance controls.",
		policy,
	)
	assert regulated.raw_complexity_score > moderate.raw_complexity_score


def test_regulated_architecture_becomes_high(policy) -> None:
	regulated = _analyze(
		"Design a secure multi-region Azure AI landing zone for a healthcare organization with private connectivity, identity governance, monitoring, disaster recovery, and compliance controls.",
		policy,
	)
	assert regulated.complexity_level == ComplexityLevel.HIGH
	assert any("Regulated or security-sensitive architecture elevated to High" in r for r in regulated.applied_policy_rules)


def test_architecture_floor_still_independent(policy) -> None:
	minimal = _analyze("architecture", policy)
	assert any("minimum complexity floor applied" in r for r in minimal.applied_policy_rules)
	assert not any("Regulated or security-sensitive architecture elevated to High" in r for r in minimal.applied_policy_rules)


def test_single_secure_not_auto_high(policy) -> None:
	result = _analyze("Design a secure architecture.", policy)
	assert result.complexity_level in (ComplexityLevel.MEDIUM,)
	assert result.adjusted_complexity_score < 7.0


def test_single_healthcare_not_auto_high(policy) -> None:
	result = _analyze("Design an architecture for healthcare.", policy)
	assert result.complexity_level in (ComplexityLevel.MEDIUM,)
	assert result.adjusted_complexity_score < 7.0


def test_architecture_escalation_requires_multiple_groups(policy) -> None:
	result = _analyze("Design secure architecture with compliance.", policy)
	assert not any("Regulated or security-sensitive architecture elevated to High" in r for r in result.applied_policy_rules)


def test_architecture_security_factor_range(policy) -> None:
	result = _analyze(
		"Design secure multi-region architecture with governance, compliance, private connectivity, and monitoring.",
		policy,
	)
	value = _factor_value(result, "architecture_security")
	assert 0.0 <= value <= 1.0


def test_requested_operations_factor_range(policy) -> None:
	result = _analyze(
		"Design architecture and compare options, evaluate risks, and recommend a strategy.",
		policy,
	)
	value = _factor_value(result, "requested_operations")
	assert 0.0 <= value <= 1.0


def test_repeated_keyword_does_not_inflate_indefinitely(policy) -> None:
	repeated = _analyze("security security security security security security architecture", policy)
	value = _factor_value(repeated, "architecture_security")
	assert value <= 1.0


def test_overlapping_phrases_not_double_counted_in_group_normalization(policy) -> None:
	result = _analyze(
		"Design architecture with private endpoint and private connectivity for compliance.",
		policy,
	)
	value = _factor_value(result, "architecture_security")
	assert value <= 1.0


def test_moderate_architecture_remains_medium(policy) -> None:
	moderate = _analyze(
		"Design an Azure architecture with an application tier, database, monitoring, and high availability.",
		policy,
	)
	assert moderate.complexity_level == ComplexityLevel.MEDIUM
	assert moderate.adjusted_complexity_score < 7.0
	assert not any("Regulated or security-sensitive architecture elevated to High" in r for r in moderate.applied_policy_rules)


def test_monitoring_plus_high_availability_no_regulated_escalation(policy) -> None:
	result = _analyze(
		"Design an architecture with monitoring and high availability.",
		policy,
	)
	assert result.complexity_level == ComplexityLevel.MEDIUM
	assert not any("Regulated or security-sensitive architecture elevated to High" in r for r in result.applied_policy_rules)


def test_compliance_alone_not_auto_high(policy) -> None:
	result = _analyze("Design an architecture with compliance controls.", policy)
	assert result.complexity_level == ComplexityLevel.MEDIUM
	assert result.adjusted_complexity_score < 7.0


def test_multi_region_alone_not_auto_high(policy) -> None:
	result = _analyze("Design a multi-region architecture.", policy)
	assert result.complexity_level == ComplexityLevel.MEDIUM
	assert result.adjusted_complexity_score < 7.0


def test_security_plus_high_availability_without_governance_or_compliance_not_high(policy) -> None:
	result = _analyze(
		"Design a secure architecture with high availability.",
		policy,
	)
	assert result.complexity_level == ComplexityLevel.MEDIUM
	assert result.adjusted_complexity_score < 7.0


def test_governance_plus_compliance_without_security_not_high(policy) -> None:
	result = _analyze(
		"Design an architecture with governance and compliance controls.",
		policy,
	)
	assert result.complexity_level == ComplexityLevel.MEDIUM
	assert result.adjusted_complexity_score < 7.0


def test_repeated_keywords_do_not_satisfy_multiple_signal_groups(policy) -> None:
	result = _analyze("secure secure secure architecture", policy)
	assert result.complexity_level == ComplexityLevel.MEDIUM
	assert not any("Regulated or security-sensitive architecture elevated to High" in r for r in result.applied_policy_rules)
