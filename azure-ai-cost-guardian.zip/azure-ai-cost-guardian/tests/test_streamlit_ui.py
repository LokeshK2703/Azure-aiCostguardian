"""Streamlit UI tests for the Demo-only Prompt 6B customer journey."""

from __future__ import annotations

import os
from pathlib import Path

from streamlit.testing.v1 import AppTest

from config import load_app_config
from models.enums import AppMode, LogicalTier
from models.request_models import PromptRequest
from services.request_orchestrator import execute_request
from services.telemetry import read_telemetry_records

APP_FILE = "app.py"
DASHBOARD_FILE = "pages/1_Savings_Dashboard.py"

ROUTINE_PROMPT = "Summarize these meeting notes into five key decisions and action items."
MODERATE_PROMPT = "Design an Azure web application architecture with an application tier, managed database, monitoring, and high availability."
COMPLEX_PROMPT = (
    "Design a secure multi-region Azure AI landing zone for a healthcare organization with private connectivity, "
    "identity governance, monitoring, disaster recovery, and compliance controls."
)


def _set_demo_env(tmp_path: Path) -> Path:
    telemetry_path = tmp_path / "telemetry_ui.json"
    os.environ["APP_MODE"] = "demo"
    os.environ["TELEMETRY_FILE_PATH"] = str(telemetry_path)
    return telemetry_path


def _app_test() -> AppTest:
    return AppTest.from_file(APP_FILE)


def _dashboard_test() -> AppTest:
    return AppTest.from_file(DASHBOARD_FILE)


def _button_labels(app: AppTest) -> list[str]:
    return [button.label for button in app.button]


def _text_values(app: AppTest) -> str:
    parts: list[str] = []
    parts.extend(item.value for item in app.title)
    parts.extend(item.value for item in app.subheader)
    parts.extend(item.value for item in app.caption)
    parts.extend(item.value for item in app.markdown)
    parts.extend(item.value for item in app.info)
    parts.extend(item.value for item in app.warning)
    parts.extend(metric.label for metric in app.metric)
    parts.extend(str(metric.value) for metric in app.metric)
    return "\n".join(str(value) for value in parts)


def _run_get_result(app: AppTest, prompt: str) -> AppTest:
    app.text_area[0].set_value(prompt)
    for button in app.button:
        if button.label == "Get Result":
            button.click()
            break
    app.run(timeout=90)
    return app


def _seed_dashboard_records(telemetry_path: Path) -> None:
    config = load_app_config(allow_unverified_pricing_preview=True)
    execute_request(
        PromptRequest(prompt=ROUTINE_PROMPT, app_mode=AppMode.DEMO),
        app_config=config,
        telemetry_file_path=telemetry_path,
    )
    execute_request(
        PromptRequest(prompt=MODERATE_PROMPT, app_mode=AppMode.DEMO),
        app_config=config,
        telemetry_file_path=telemetry_path,
    )
    execute_request(
        PromptRequest(prompt=COMPLEX_PROMPT, app_mode=AppMode.DEMO),
        app_config=config,
        telemetry_file_path=telemetry_path,
    )


def test_main_page_loads_and_shows_single_primary_input(tmp_path: Path) -> None:
    _set_demo_env(tmp_path)
    app = _app_test()
    app.run(timeout=90)

    assert len(app.text_area) == 1
    assert app.text_area[0].label == "What can we help with?"
    assert "Get Result" in _button_labels(app)
    assert "Assess Workload" not in _button_labels(app)
    text = _text_values(app)
    assert "Azure AI Cost Guardian" in text
    assert "Use the Right AI. Not the Most Expensive One." in text
    assert "Enter Your Request" in text
    assert "Cost Guardian automatically selects the most appropriate AI capability." in text
    assert "How Cost Guardian Works" in text
    for stage in ["Request", "Analyze", "Optimize", "Respond", "Track"]:
        assert stage in text
    assert "Demo Mode: Results are generated locally using deterministic examples. No live AI service is called." in text
    assert "Hackathon prototype. Not an official Microsoft product." in text
    assert text.count("Demo Mode: Results are generated locally using deterministic examples. No live AI service is called.") == 1
    assert "AI Usage Dashboard" in Path(APP_FILE).read_text(encoding="utf-8")


def test_azure_configuration_terms_not_visible_in_primary_ui(tmp_path: Path) -> None:
    _set_demo_env(tmp_path)
    app = _app_test()
    app.run(timeout=90)

    text = _text_values(app).lower()
    for forbidden in ["azure mode", "endpoint", "deployment", "api key", "subscription", "live mode", "azure openai"]:
        assert forbidden not in text


def test_admin_controls_are_not_primary_and_collapsed(tmp_path: Path) -> None:
    _set_demo_env(tmp_path)
    app = _app_test()
    app.run(timeout=90)

    expander_labels = [expander.label for expander in app.expander]
    assert "Admin and Technical Details" in expander_labels
    assert "Admin Controls" not in expander_labels

    technical_details = next(expander for expander in app.expander if expander.label == "Admin and Technical Details")
    assert technical_details.proto.expanded is False

    technical_text = "\n".join(item.value for item in technical_details.caption)
    assert "Run a request to view technical details." in technical_text

    main_text = _text_values(app)
    assert "Selection mode" not in main_text
    assert "Raw complexity score" not in main_text
    assert "Estimated input tokens" not in main_text
    assert "Recommendation confidence" not in main_text
    assert "Override" not in main_text

    # Verify details are present under the technical expander after execution.
    _run_get_result(app, ROUTINE_PROMPT)
    technical_details = next(expander for expander in app.expander if expander.label == "Admin and Technical Details")
    technical_markdown = "\n".join(item.value for item in technical_details.markdown)
    assert "Workload Type" in technical_markdown
    assert "Complexity Score" in technical_markdown
    assert "Estimated Usage" in technical_markdown
    assert "Selected Capability" in technical_markdown
    assert "Decision Source" in technical_markdown
    assert "Decision Confidence" in technical_markdown
    assert "Processing Status" in technical_markdown
    assert "Value origins" not in technical_markdown.lower()
    assert "response_text: synthetic" not in technical_markdown
    assert "latency_ms: synthetic" not in technical_markdown
    assert "actual_input_tokens: synthetic" not in technical_markdown
    assert "actual_output_tokens: synthetic" not in technical_markdown
    assert "actual_total_tokens: synthetic" not in technical_markdown
    assert "architecture_design" not in technical_markdown
    assert "general_qa" not in technical_markdown
    assert "user_override" not in technical_markdown
    assert "recommendation" not in technical_markdown


def test_get_result_generates_output_and_single_optimization_explanation(tmp_path: Path) -> None:
    telemetry_path = _set_demo_env(tmp_path)
    app = _app_test()
    app.run(timeout=90)

    _run_get_result(app, ROUTINE_PROMPT)
    text = _text_values(app)

    assert "Generated Result" in text
    assert "Cost Guardian Decision" in text
    assert "Why?" in text
    assert "Optimized for Efficiency" in text
    assert "Balanced for quality and cost" not in text
    assert "Premium capability justified" not in text
    assert "Demonstration result generated locally. No live AI service was called." in text
    assert "Privacy" in text
    assert text.count("Your request and generated result are not stored in telemetry.") == 1

    # Exactly one optimization title should be customer-visible for this routine request.
    assert text.count("Optimized for Efficiency") == 1
    assert "Balanced for quality and cost" not in text
    assert "Premium capability justified" not in text

    assert "Generate Response" not in _button_labels(app)
    assert "Assess Workload" not in text

    # Result should not be rendered as a disabled output text area.
    assert len(app.text_area) == 1
    assert app.text_area[0].label == "What can we help with?"

    why_lines = [line for line in text.splitlines() if line.strip() in {
        "Routine and clearly defined task",
        "Limited reasoning required",
        "Detailed technical analysis requested",
        "Multiple technical requirements detected",
        "Security requirements detected",
        "Identity or governance requirements detected",
        "Compliance considerations detected",
        "Multi-region or recovery planning requested",
        "Software development requested",
    }]
    assert len(why_lines) <= 3

    records = read_telemetry_records(telemetry_path)
    assert len(records) == 1


def test_expected_optimization_explanations_for_routing_outcomes(tmp_path: Path) -> None:
    _set_demo_env(tmp_path)
    app = _app_test()
    app.run(timeout=90)

    _run_get_result(app, ROUTINE_PROMPT)
    assert "Optimized for Efficiency" in _text_values(app)

    _run_get_result(app, MODERATE_PROMPT)
    assert "Balanced for Quality and Cost" in _text_values(app)

    _run_get_result(app, COMPLEX_PROMPT)
    assert "Premium Capability Justified" in _text_values(app)


def test_backend_routing_outcomes_unchanged_for_three_reference_prompts(tmp_path: Path) -> None:
    telemetry_path = _set_demo_env(tmp_path)
    config = load_app_config(allow_unverified_pricing_preview=True)

    routine = execute_request(
        PromptRequest(prompt=ROUTINE_PROMPT, app_mode=AppMode.DEMO),
        app_config=config,
        telemetry_file_path=telemetry_path,
    )
    moderate = execute_request(
        PromptRequest(prompt=MODERATE_PROMPT, app_mode=AppMode.DEMO),
        app_config=config,
        telemetry_file_path=telemetry_path,
    )
    complex_request = execute_request(
        PromptRequest(prompt=COMPLEX_PROMPT, app_mode=AppMode.DEMO),
        app_config=config,
        telemetry_file_path=telemetry_path,
    )

    assert routine.routing_decision is not None
    assert routine.routing_decision.recommended_tier == LogicalTier.ECONOMY

    assert moderate.routing_decision is not None
    assert moderate.routing_decision.recommended_tier == LogicalTier.BALANCED

    assert complex_request.routing_decision is not None
    assert complex_request.routing_decision.recommended_tier == LogicalTier.ADVANCED


def test_dashboard_uses_administrator_language(tmp_path: Path) -> None:
    telemetry_path = _set_demo_env(tmp_path)
    _seed_dashboard_records(telemetry_path)

    dashboard = _dashboard_test()
    dashboard.run(timeout=90)

    text = _text_values(dashboard)
    assert "AI Usage Dashboard" in text
    assert "See how Cost Guardian allocates AI capacity across requests." in text

    for required_label in [
        "Requests Processed",
        "Cost-Efficient Selections",
        "Standard Selections",
        "Premium Selections",
        "AI Capability Allocation",
        "Request Volume Over Time",
        "Workload Distribution",
    ]:
        assert required_label in text


def test_get_result_has_no_destructive_red_custom_style() -> None:
    source = Path(APP_FILE).read_text(encoding="utf-8").lower()
    assert "background-color: red" not in source
    assert "#ff0000" not in source
    assert "#dc2626" not in source
    assert "#ef4444" not in source
    assert "type=\"secondary\"" not in source
    assert "1d4ed8" in source or "2563eb" in source


def test_sidebar_navigation_labels_are_customer_facing() -> None:
    app_source = Path(APP_FILE).read_text(encoding="utf-8")
    dashboard_source = Path(DASHBOARD_FILE).read_text(encoding="utf-8")
    assert '💬 Chat & Analyze' in app_source
    assert '📊 AI Usage Dashboard' in app_source
    assert '🏗 Architecture' in app_source
    assert '📖 Project Story' in app_source
    assert 'ℹ️ About' in app_source
    assert '💬 Chat & Analyze' in dashboard_source
    assert '📊 AI Usage Dashboard' in dashboard_source
