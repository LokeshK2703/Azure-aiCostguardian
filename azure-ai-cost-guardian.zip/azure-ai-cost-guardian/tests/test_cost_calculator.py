"""Tests for cost calculator deterministic behavior."""

from __future__ import annotations

from decimal import Decimal

import pytest

from config import ModelPricing
from models.enums import LogicalTier, TokenEstimationMethod, ValueOrigin
from models.response_models import TokenEstimate
from services.cost_calculator import apply_actual_usage, calculate_tier_cost, estimate_costs


def _pricing() -> ModelPricing:
	return ModelPricing.model_validate(
		{
			"schema_version": "1.0",
			"currency": "USD",
			"baseline_tier": "advanced",
			"pricing_note": "test",
			"tiers": {
				"economy": {
					"display_name": "Economy",
					"model_family_hint": "nano",
					"input_price_per_million_tokens": "0.10",
					"output_price_per_million_tokens": "0.20",
					"effective_date_note": "test",
				},
				"balanced": {
					"display_name": "Balanced",
					"model_family_hint": "mini",
					"input_price_per_million_tokens": "0.40",
					"output_price_per_million_tokens": "0.80",
					"effective_date_note": "test",
				},
				"advanced": {
					"display_name": "Advanced",
					"model_family_hint": "4o",
					"input_price_per_million_tokens": "1.00",
					"output_price_per_million_tokens": "2.00",
					"effective_date_note": "test",
				},
			},
		}
	)


def _null_pricing() -> ModelPricing:
	return ModelPricing.model_validate(
		{
			"schema_version": "1.0",
			"currency": "USD",
			"baseline_tier": "advanced",
			"pricing_note": "test",
			"tiers": {
				"economy": {
					"display_name": "Economy",
					"model_family_hint": "nano",
					"input_price_per_million_tokens": None,
					"output_price_per_million_tokens": None,
					"effective_date_note": "test",
				},
				"balanced": {
					"display_name": "Balanced",
					"model_family_hint": "mini",
					"input_price_per_million_tokens": "0.40",
					"output_price_per_million_tokens": None,
					"effective_date_note": "test",
				},
				"advanced": {
					"display_name": "Advanced",
					"model_family_hint": "4o",
					"input_price_per_million_tokens": None,
					"output_price_per_million_tokens": "2.00",
					"effective_date_note": "test",
				},
			},
		}
	)


def _tokens(inp: int = 1000, out: int = 500) -> TokenEstimate:
	return TokenEstimate(
		method=TokenEstimationMethod.TIKTOKEN,
		estimated_input_tokens=inp,
		estimated_output_tokens=out,
		estimated_total_tokens=inp + out,
		explanation="test",
	)


def test_input_output_total_cost_calculation() -> None:
	pricing = _pricing()
	breakdown = calculate_tier_cost(
		input_tokens=1000,
		output_tokens=500,
		tier_pricing=pricing.tiers[LogicalTier.ECONOMY],
		origin=ValueOrigin.ESTIMATED,
	)
	assert breakdown.input_cost == Decimal("0.0001")
	assert breakdown.output_cost == Decimal("0.0001")
	assert breakdown.total_cost == Decimal("0.0002")


def test_estimated_routed_and_baseline_costs() -> None:
	result = estimate_costs(_tokens(), _pricing(), LogicalTier.ECONOMY)
	assert result.estimated_routed_cost is not None
	assert result.estimated_baseline_cost is not None


def test_positive_savings() -> None:
	result = estimate_costs(_tokens(), _pricing(), LogicalTier.ECONOMY)
	assert result.estimated_savings_amount is not None
	assert result.estimated_savings_amount > 0


def test_negative_savings() -> None:
	result = estimate_costs(_tokens(), _pricing(), LogicalTier.ADVANCED)
	assert result.estimated_savings_amount == Decimal("0")


def test_savings_percentage() -> None:
	result = estimate_costs(_tokens(), _pricing(), LogicalTier.BALANCED)
	assert result.estimated_savings_percentage is not None


def test_zero_baseline_gives_unavailable_percentage() -> None:
	pricing = _pricing()
	pricing.tiers[LogicalTier.ADVANCED].input_price_per_million_tokens = Decimal("0")
	pricing.tiers[LogicalTier.ADVANCED].output_price_per_million_tokens = Decimal("0")
	result = estimate_costs(_tokens(), pricing, LogicalTier.ECONOMY)
	assert result.estimated_savings_percentage is None


def test_null_pricing_gives_unavailable() -> None:
	result = estimate_costs(_tokens(), _null_pricing(), LogicalTier.ECONOMY)
	assert result.estimated_routed_cost is None
	assert result.estimated_value_origin == ValueOrigin.UNAVAILABLE


def test_missing_actual_usage_keeps_actual_unavailable() -> None:
	result = estimate_costs(_tokens(), _pricing(), LogicalTier.BALANCED)
	updated = apply_actual_usage(result, _pricing(), LogicalTier.BALANCED, None, None)
	assert updated.actual_value_origin == ValueOrigin.UNAVAILABLE


def test_actual_comparison_uses_actual_token_quantities() -> None:
	result = estimate_costs(_tokens(), _pricing(), LogicalTier.ECONOMY)
	updated = apply_actual_usage(result, _pricing(), LogicalTier.ECONOMY, 2000, 1000)
	assert updated.actual_value_origin == ValueOrigin.ACTUAL
	assert updated.actual_routed_cost is not None
	assert updated.actual_baseline_cost is not None


def test_negative_token_counts_rejected() -> None:
	with pytest.raises(ValueError):
		calculate_tier_cost(-1, 1, _pricing().tiers[LogicalTier.ECONOMY], ValueOrigin.ESTIMATED)


def test_zero_token_behavior() -> None:
	breakdown = calculate_tier_cost(0, 0, _pricing().tiers[LogicalTier.ECONOMY], ValueOrigin.ESTIMATED)
	assert breakdown.total_cost == Decimal("0")


def test_decimal_arithmetic_and_no_hardcoded_percentage() -> None:
	result = estimate_costs(_tokens(1234, 5678), _pricing(), LogicalTier.BALANCED)
	assert isinstance(result.estimated_routed_cost, Decimal)
	assert result.estimated_savings_percentage is None or isinstance(result.estimated_savings_percentage, Decimal)
