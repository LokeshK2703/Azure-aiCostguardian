"""Test package for Azure AI Cost Guardian."""
