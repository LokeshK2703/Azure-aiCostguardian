"""Tests for deterministic demo responder behavior."""

from __future__ import annotations

from uuid import uuid4

import pytest

from models.enums import AppMode, ExecutionStatus, LogicalTier, SelectionSource, TaskCategory, ValueOrigin
from models.request_models import ExecutionRequest
from services.demo_responder import generate_demo_response
from services.prompt_analyzer import analyze_prompt
from config import load_routing_policy
from models.request_models import AnalysisRequest, PromptRequest

_REQUIRED_SECTION_MARKERS: dict[TaskCategory, tuple[str, ...]] = {
	TaskCategory.SUMMARIZATION: (
		"Summary",
		"Key Decisions",
		"Action Items",
	),
	TaskCategory.EMAIL: ("Subject:", "Greeting", "Body", "Requested Action", "Closing"),
	TaskCategory.DOCUMENTATION: (
		"Purpose",
		"Requirements",
		"Implementation Notes",
		"Operational Considerations",
	),
	TaskCategory.TECHNICAL_EXPLANATION: (
		"TLS and mTLS Comparison",
		"When To Use",
		"Practical Enterprise Example",
		"Note",
	),
	TaskCategory.ARCHITECTURE_DESIGN: (
		"Demonstration Architecture (Conceptual, Not Production Guidance)",
		"Identity and Access",
		"Private Connectivity",
		"Application Tier",
		"Data Tier",
		"Monitoring",
		"Resilience",
		"Governance",
	),
	TaskCategory.CODE_GENERATION: ("Code Sample", "Explanation", "Validation Notes"),
	TaskCategory.GENERAL_QA: ("Answer", "Context", "Recommended Follow-Up"),
}


def _request(prompt: str, tier: LogicalTier = LogicalTier.BALANCED) -> ExecutionRequest:
	return ExecutionRequest(
		request_id=uuid4(),
		prompt=prompt,
		app_mode=AppMode.DEMO,
		selected_tier=tier,
		selection_source=SelectionSource.RECOMMENDATION,
	)


def _category_for(prompt: str) -> TaskCategory:
	policy, _ = load_routing_policy()
	analysis = analyze_prompt(AnalysisRequest(prompt_request=PromptRequest(prompt=prompt)), policy)
	return analysis.task_category


@pytest.mark.parametrize(
	("prompt", "expected_category"),
	[
		("Summarize these meeting notes into key points.", TaskCategory.SUMMARIZATION),
		("Draft an email reply with a subject line.", TaskCategory.EMAIL),
		("Create a readme and runbook guide for setup.", TaskCategory.DOCUMENTATION),
		("Explain the difference between TLS and mTLS.", TaskCategory.TECHNICAL_EXPLANATION),
		("Design a multi-region architecture with disaster recovery.", TaskCategory.ARCHITECTURE_DESIGN),
		("Write code for a Python function class validator.", TaskCategory.CODE_GENERATION),
		("What is tokenization?", TaskCategory.GENERAL_QA),
	],
)
def test_returns_response_for_all_categories(prompt: str, expected_category: TaskCategory) -> None:
	assert _category_for(prompt) == expected_category
	result = generate_demo_response(_request(prompt))
	assert result.execution_status == ExecutionStatus.SUCCESS
	assert result.response_text is not None
	assert "Deterministic Demo Mode Response" in result.response_text
	for marker in _REQUIRED_SECTION_MARKERS[expected_category]:
		assert marker in result.response_text


def test_tls_mtls_response_mentions_both_tls_and_mtls() -> None:
	result = generate_demo_response(_request("Explain the difference between TLS and mTLS with a practical enterprise example."))
	assert result.response_text is not None
	text = result.response_text.lower()
	assert "tls" in text
	assert "mtls" in text


def test_tls_mtls_response_explains_authentication_difference() -> None:
	result = generate_demo_response(_request("Explain the difference between TLS and mTLS with a practical enterprise example."))
	assert result.response_text is not None
	assert "tls authenticates the server to the client" in result.response_text.lower()
	assert "mtls authenticates both client and server" in result.response_text.lower()


def test_tls_mtls_response_contains_enterprise_example() -> None:
	result = generate_demo_response(_request("Explain the difference between TLS and mTLS with a practical enterprise example."))
	assert result.response_text is not None
	text = result.response_text.lower()
	assert "internal payment service" in text
	assert "transaction-processing api" in text
	assert "validates the payment service certificate" in text


def test_non_curated_prompt_includes_workflow_disclosure() -> None:
	result = generate_demo_response(_request("What are practical steps to improve change management meetings?"))
	assert result.response_text is not None
	assert (
		"This deterministic Demo Mode response demonstrates the product workflow. "
		"Connect an authorized live AI service for prompt-specific generated content."
	) in result.response_text


def test_response_marked_synthetic() -> None:
	result = generate_demo_response(_request("Summarize these meeting notes into key points."))
	assert result.value_origins["response_text"] == ValueOrigin.SYNTHETIC
	assert result.value_origins["latency_ms"] == ValueOrigin.SYNTHETIC
	assert result.value_origins["actual_input_tokens"] == ValueOrigin.SYNTHETIC
	assert result.value_origins["actual_output_tokens"] == ValueOrigin.SYNTHETIC
	assert result.value_origins["actual_total_tokens"] == ValueOrigin.SYNTHETIC


def test_response_length_improved() -> None:
	prompts = [
		"Summarize these meeting notes into key points.",
		"Draft an email reply with a subject line.",
		"Create a readme and runbook guide for setup.",
		"Explain the difference between TLS and mTLS.",
		"Design a multi-region architecture with disaster recovery.",
		"Write code for a Python function class validator.",
		"What is tokenization?",
	]
	for prompt in prompts:
		result = generate_demo_response(_request(prompt))
		assert result.response_text is not None
		assert len(result.response_text) >= 320


def test_deterministic_output() -> None:
	request = _request("Design a multi-region architecture with disaster recovery.", LogicalTier.ADVANCED)
	first = generate_demo_response(request)
	second = generate_demo_response(request)
	assert first.response_text == second.response_text
	assert first.latency_ms == second.latency_ms
	assert first.actual_total_tokens == second.actual_total_tokens


def test_no_randomness_across_request_ids() -> None:
	first = generate_demo_response(_request("What is tokenization?"))
	second = generate_demo_response(_request("What is tokenization?"))
	assert first.response_text == second.response_text
	assert first.latency_ms == second.latency_ms
	assert first.actual_total_tokens == second.actual_total_tokens


def test_no_prompt_persistence_in_result_dump() -> None:
	request = _request("Write code for a Python function class validator.")
	result = generate_demo_response(request)
	payload = result.model_dump()
	assert "prompt" not in payload
	assert request.prompt not in str(payload)


def test_non_demo_mode_rejected() -> None:
	request = ExecutionRequest(
		request_id=uuid4(),
		prompt="Summarize this",
		app_mode=AppMode.AZURE,
		selected_tier=LogicalTier.ECONOMY,
		selection_source=SelectionSource.RECOMMENDATION,
	)
	with pytest.raises(ValueError, match="demo mode"):
		generate_demo_response(request)
