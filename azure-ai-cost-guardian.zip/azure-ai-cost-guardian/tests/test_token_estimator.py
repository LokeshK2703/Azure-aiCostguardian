"""Tests for token estimator deterministic behavior."""

from __future__ import annotations

import pytest

from config import load_routing_policy
from models.enums import TaskCategory, TokenEstimationMethod
from models.request_models import PromptRequest
from services import token_estimator
from services.token_estimator import estimate_tokens


@pytest.fixture()
def policy():
	loaded, _ = load_routing_policy()
	return loaded


def test_successful_tiktoken_estimate(policy) -> None:
	request = PromptRequest(prompt="Summarize this meeting note into action items.")
	result = estimate_tokens(request, policy, TaskCategory.SUMMARIZATION, model_hint="gpt-4o")
	assert result.estimated_input_tokens > 0
	assert result.method in {TokenEstimationMethod.TIKTOKEN, TokenEstimationMethod.ENCODING_FALLBACK}


def test_general_encoding_fallback(policy, monkeypatch: pytest.MonkeyPatch) -> None:
	def fail_encoding_for_model(_model: str):
		raise KeyError("missing model")

	monkeypatch.setattr(token_estimator.tiktoken, "encoding_for_model", fail_encoding_for_model)
	request = PromptRequest(prompt="Explain this technical concept.")
	result = estimate_tokens(request, policy, TaskCategory.TECHNICAL_EXPLANATION, model_hint="missing-model")
	assert result.method == TokenEstimationMethod.ENCODING_FALLBACK


def test_character_fallback(policy, monkeypatch: pytest.MonkeyPatch) -> None:
	def fail_encoding_for_model(_model: str):
		raise KeyError("missing")

	def fail_get_encoding(_name: str):
		raise RuntimeError("tokenizer unavailable")

	monkeypatch.setattr(token_estimator.tiktoken, "encoding_for_model", fail_encoding_for_model)
	monkeypatch.setattr(token_estimator.tiktoken, "get_encoding", fail_get_encoding)

	prompt = "abcd" * 10
	request = PromptRequest(prompt=prompt)
	result = estimate_tokens(request, policy, TaskCategory.GENERAL_QA, model_hint="missing")
	assert result.method == TokenEstimationMethod.CHARACTER_FALLBACK
	assert result.estimated_input_tokens == 10


def test_output_ratio_by_task_category(policy) -> None:
	prompt = "Explain this concept in detail."
	request = PromptRequest(prompt=prompt)
	result_doc = estimate_tokens(request, policy, TaskCategory.DOCUMENTATION)
	result_email = estimate_tokens(request, policy, TaskCategory.EMAIL)
	assert result_doc.estimated_output_tokens >= result_email.estimated_output_tokens


def test_detailed_output_adjustment(policy) -> None:
	normal = estimate_tokens(
		PromptRequest(prompt="Write a guide."),
		policy,
		TaskCategory.DOCUMENTATION,
	)
	detailed = estimate_tokens(
		PromptRequest(prompt="Write a detailed comprehensive guide with all steps."),
		policy,
		TaskCategory.DOCUMENTATION,
	)
	assert detailed.estimated_output_tokens >= normal.estimated_output_tokens


def test_output_cap_enforced(policy) -> None:
	p = policy.model_copy(deep=True)
	p.input_limits.max_estimated_output_tokens = 3
	result = estimate_tokens(PromptRequest(prompt="Write a detailed comprehensive complete manual."), p, TaskCategory.DOCUMENTATION)
	assert result.estimated_output_tokens == 3
	assert result.output_was_clamped is True


def test_input_token_limit_enforced(policy) -> None:
	p = policy.model_copy(deep=True)
	p.input_limits.max_estimated_input_tokens = 1
	with pytest.raises(ValueError, match="max_estimated_input_tokens"):
		estimate_tokens(PromptRequest(prompt="This definitely exceeds one token."), p, TaskCategory.GENERAL_QA)


def test_total_equals_input_plus_output(policy) -> None:
	result = estimate_tokens(PromptRequest(prompt="Hello world"), policy, TaskCategory.GENERAL_QA)
	assert result.estimated_total_tokens == result.estimated_input_tokens + result.estimated_output_tokens


def test_empty_prompt_handling(policy) -> None:
	with pytest.raises(Exception):
		request = PromptRequest(prompt=" ")
		estimate_tokens(request, policy, TaskCategory.GENERAL_QA)


def test_explanation_identifies_estimation_method(policy) -> None:
	result = estimate_tokens(PromptRequest(prompt="Summarize notes"), policy, TaskCategory.SUMMARIZATION)
	assert "Used" in result.explanation


def test_estimate_is_deterministic(policy) -> None:
	request = PromptRequest(prompt="Explain root cause and propose strategy.")
	first = estimate_tokens(request, policy, TaskCategory.TECHNICAL_EXPLANATION)
	second = estimate_tokens(request, policy, TaskCategory.TECHNICAL_EXPLANATION)
	assert first.model_dump() == second.model_dump()
