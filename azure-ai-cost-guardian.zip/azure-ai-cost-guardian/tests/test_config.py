"""Tests for configuration and contract validation created in Prompt 2."""

from pathlib import Path

import pytest
from pydantic import ValidationError

from config import (
    ConfigurationError,
    ModelPricing,
    RuntimeSettings,
    load_app_config,
    load_model_pricing,
    validate_pricing_for_mode,
)
from models.enums import AppMode, ComplexityLevel, LogicalTier
from models.request_models import ExecutionRequest, PromptRequest

ENV_KEYS = [
    "APP_MODE",
    "AZURE_OPENAI_ENDPOINT",
    "AZURE_OPENAI_API_VERSION",
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_AUTH_MODE",
    "DEPLOYMENT_ECONOMY",
    "DEPLOYMENT_BALANCED",
    "DEPLOYMENT_ADVANCED",
    "BASELINE_TIER",
    "STORE_RAW_CONTENT",
]


def _clear_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for key in ENV_KEYS:
        monkeypatch.delenv(key, raising=False)


def test_enum_values_are_stable() -> None:
    assert AppMode.DEMO.value == "demo"
    assert AppMode.AZURE.value == "azure"
    assert LogicalTier.ADVANCED.value == "advanced"
    assert ComplexityLevel.MEDIUM.value == "medium"


def test_demo_mode_does_not_require_azure_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    _clear_env(monkeypatch)
    monkeypatch.setenv("APP_MODE", "demo")

    settings = RuntimeSettings(_env_file=None)

    assert settings.APP_MODE == AppMode.DEMO
    assert settings.AZURE_OPENAI_ENDPOINT == ""


def test_azure_mode_requires_configuration(monkeypatch: pytest.MonkeyPatch) -> None:
    _clear_env(monkeypatch)
    monkeypatch.setenv("APP_MODE", "azure")

    with pytest.raises(ValidationError) as exc:
        RuntimeSettings(_env_file=None)

    assert "Missing required Azure configuration" in str(exc.value)


def test_store_raw_content_true_is_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
    _clear_env(monkeypatch)
    monkeypatch.setenv("STORE_RAW_CONTENT", "true")

    with pytest.raises(ValidationError) as exc:
        RuntimeSettings()

    assert "STORE_RAW_CONTENT=true is not allowed" in str(exc.value)


def test_prompt_request_rejects_whitespace() -> None:
    with pytest.raises(ValidationError):
        PromptRequest(prompt="   ")


def test_request_ids_are_uuid4() -> None:
    prompt_request = PromptRequest(prompt="hello")
    execution_request = ExecutionRequest(
        prompt="hello",
        app_mode=AppMode.DEMO,
        selected_tier=LogicalTier.ECONOMY,
        selection_source="recommendation",
    )

    assert prompt_request.request_id.version == 4
    assert execution_request.request_id.version == 4


def test_model_pricing_schema_loads() -> None:
    pricing = load_model_pricing(Path("config/model_pricing.json"))

    assert pricing.schema_version == "1.0"
    assert pricing.baseline_tier == LogicalTier.ADVANCED
    assert pricing.tiers[LogicalTier.ECONOMY].input_price_per_million_tokens is not None


def test_null_pricing_allowed_in_demo_mode() -> None:
    pricing = load_model_pricing(Path("config/model_pricing.json"))

    validate_pricing_for_mode(pricing, AppMode.DEMO)


def test_null_pricing_rejected_in_azure_mode() -> None:
    null_pricing = ModelPricing.model_validate(
        {
            "schema_version": "1.0",
            "currency": "USD",
            "baseline_tier": "advanced",
            "pricing_note": "test",
            "tiers": {
                "economy": {
                    "display_name": "Economy",
                    "model_family_hint": "nano",
                    "input_price_per_million_tokens": None,
                    "output_price_per_million_tokens": None,
                    "effective_date_note": "test",
                },
                "balanced": {
                    "display_name": "Balanced",
                    "model_family_hint": "mini",
                    "input_price_per_million_tokens": None,
                    "output_price_per_million_tokens": None,
                    "effective_date_note": "test",
                },
                "advanced": {
                    "display_name": "Advanced",
                    "model_family_hint": "4o",
                    "input_price_per_million_tokens": None,
                    "output_price_per_million_tokens": None,
                    "effective_date_note": "test",
                },
            },
        }
    )

    with pytest.raises(ConfigurationError) as exc:
        validate_pricing_for_mode(null_pricing, AppMode.AZURE)

    assert "requires verified numeric pricing" in str(exc.value)


def test_load_app_config_demo_mode(monkeypatch: pytest.MonkeyPatch) -> None:
    _clear_env(monkeypatch)
    monkeypatch.setenv("APP_MODE", "demo")

    app_config = load_app_config()

    assert app_config.runtime.APP_MODE == AppMode.DEMO
    assert app_config.routing_policy.schema_version == "1.0"
