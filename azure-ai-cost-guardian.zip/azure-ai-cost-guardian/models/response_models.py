"""Response and domain-result Pydantic contracts."""

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, Field, field_validator

from models.enums import (
    AppMode,
    ComplexityLevel,
    ErrorCategory,
    ExecutionStatus,
    LogicalTier,
    SelectionSource,
    TaskCategory,
    TokenEstimationMethod,
    ValueOrigin,
)


class ComplexityFactor(BaseModel):
    """A single complexity signal used by the scoring explanation."""

    name: str = Field(min_length=1)
    contribution: float
    normalized_value: float | None = Field(default=None, ge=0.0, le=1.0)
    weight: float | None = Field(default=None, ge=0.0, le=1.0)
    weighted_contribution: float | None = None
    rationale: str = Field(min_length=1)


class TokenEstimate(BaseModel):
    """Estimated token usage metadata."""

    method: TokenEstimationMethod
    estimated_input_tokens: int = Field(ge=0)
    estimated_output_tokens: int = Field(ge=0)
    estimated_total_tokens: int = Field(ge=0)
    explanation: str = Field(default="", min_length=0)
    output_was_clamped: bool = False
    input_within_limit: bool = True


class PromptAnalysis(BaseModel):
    """Prompt analysis output contract."""

    prompt_character_count: int = Field(ge=0)
    meaningful_word_count: int = Field(ge=0)
    task_category: TaskCategory
    raw_complexity_score: float = Field(ge=0.0, le=10.0)
    adjusted_complexity_score: float = Field(ge=0.0, le=10.0)
    complexity_score: float = Field(ge=0.0, le=10.0)
    complexity_level: ComplexityLevel
    explanation: str = Field(min_length=1)
    complexity_factors: list[ComplexityFactor] = Field(default_factory=list)
    classification_evidence: dict[TaskCategory, int] = Field(default_factory=dict)
    category_precedence_used: bool = False
    is_short_prompt: bool = False
    is_ambiguous: bool = False
    ambiguity_reasons: list[str] = Field(default_factory=list)
    strong_agreement: bool = False
    applied_policy_rules: list[str] = Field(default_factory=list)


class ConfidenceAdjustment(BaseModel):
    """One confidence rule adjustment applied to recommendation confidence."""

    name: str = Field(min_length=1)
    delta: int
    applied: bool
    reason: str = Field(min_length=1)


class RoutingDecision(BaseModel):
    """Routing recommendation contract."""

    recommended_tier: LogicalTier
    complexity_score: float = Field(ge=0.0, le=10.0)
    confidence: int = Field(ge=0, le=100)
    reason: str = Field(min_length=1)
    confidence_explanation: str = Field(default="", min_length=0)
    confidence_scope: str = Field(
        default="Confidence reflects routing recommendation reliability, not generated-response correctness.",
        min_length=1,
    )
    factors_considered: list[str] = Field(default_factory=list)
    confidence_adjustments: list[ConfidenceAdjustment] = Field(default_factory=list)
    recommended_tier_configured: bool | None = None
    configured_alternatives: list[LogicalTier] = Field(default_factory=list)
    executed_tier: LogicalTier | None = None
    selection_source: SelectionSource | None = None
    execution_status: ExecutionStatus = ExecutionStatus.NOT_STARTED
    error_category: ErrorCategory | None = None
    error_message: str | None = None


class CostBreakdown(BaseModel):
    """Cost breakdown for a specific tier and token quantities."""

    input_cost: Decimal | None = None
    output_cost: Decimal | None = None
    total_cost: Decimal | None = None
    value_origin: ValueOrigin = Field(default=ValueOrigin.UNAVAILABLE)


class CostComparison(BaseModel):
    """Estimated and actual routed-vs-baseline cost comparison."""

    estimated_baseline_cost: Decimal | None = None
    estimated_routed_cost: Decimal | None = None
    estimated_savings_amount: Decimal | None = None
    estimated_savings_percentage: Decimal | None = None
    actual_baseline_cost: Decimal | None = None
    actual_routed_cost: Decimal | None = None
    actual_savings_amount: Decimal | None = None
    actual_savings_percentage: Decimal | None = None
    explanation: str = Field(default="", min_length=0)
    estimated_value_origin: ValueOrigin = ValueOrigin.UNAVAILABLE
    actual_value_origin: ValueOrigin = ValueOrigin.UNAVAILABLE


class SafeError(BaseModel):
    """Sanitized error contract safe for logs and UI."""

    category: ErrorCategory
    message: str = Field(min_length=1)
    retryable: bool = False


class ExecutionResult(BaseModel):
    """Normalized execution result from demo or Azure adapters."""

    request_id: UUID
    app_mode: AppMode
    execution_status: ExecutionStatus
    executed_tier: LogicalTier | None = None
    selection_source: SelectionSource | None = None
    response_text: str | None = None
    latency_ms: int | None = Field(default=None, ge=0)
    actual_input_tokens: int | None = Field(default=None, ge=0)
    actual_output_tokens: int | None = Field(default=None, ge=0)
    actual_total_tokens: int | None = Field(default=None, ge=0)
    error: SafeError | None = None
    value_origins: dict[str, ValueOrigin] = Field(default_factory=dict)


class TelemetryRecord(BaseModel):
    """Privacy-conscious telemetry metadata record.

    Raw prompt content and generated response content are intentionally excluded.
    """

    request_id: UUID
    timestamp_utc: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    app_mode: AppMode
    prompt_character_count: int = Field(ge=0)
    task_category: TaskCategory
    complexity_score: float = Field(ge=0.0, le=10.0)
    complexity_level: ComplexityLevel
    complexity_factors: list[ComplexityFactor] = Field(default_factory=list)
    token_estimation_method: TokenEstimationMethod
    estimated_input_tokens: int = Field(ge=0)
    estimated_output_tokens: int = Field(ge=0)
    estimated_total_tokens: int = Field(ge=0)
    actual_input_tokens: int | None = Field(default=None, ge=0)
    actual_output_tokens: int | None = Field(default=None, ge=0)
    actual_total_tokens: int | None = Field(default=None, ge=0)
    recommended_tier: LogicalTier
    executed_tier: LogicalTier
    selection_source: SelectionSource
    estimated_baseline_cost: Decimal | None = None
    estimated_routed_cost: Decimal | None = None
    estimated_savings_amount: Decimal | None = None
    estimated_savings_percentage: Decimal | None = None
    actual_baseline_cost: Decimal | None = None
    actual_routed_cost: Decimal | None = None
    actual_savings_amount: Decimal | None = None
    actual_savings_percentage: Decimal | None = None
    latency_ms: int | None = Field(default=None, ge=0)
    execution_status: ExecutionStatus
    error_category: ErrorCategory | None = None
    value_origins: dict[str, ValueOrigin] = Field(default_factory=dict)

    @field_validator("timestamp_utc")
    @classmethod
    def validate_timezone_aware_utc(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("timestamp_utc must be timezone-aware.")
        return value.astimezone(timezone.utc)


class OrchestrationResult(BaseModel):
    """Top-level orchestration result returned to the Streamlit layer."""

    request_id: UUID
    prompt_analysis: PromptAnalysis | None = None
    routing_decision: RoutingDecision | None = None
    token_estimate: TokenEstimate | None = None
    cost_comparison: CostComparison | None = None
    execution_result: ExecutionResult | None = None
    telemetry_record: TelemetryRecord | None = None
    warnings: list[str] = Field(default_factory=list)


class DashboardSummary(BaseModel):
    """Aggregated dashboard metrics contract."""

    total_requests: int = Field(ge=0)
    tier_utilization: dict[LogicalTier, int] = Field(default_factory=dict)
    average_complexity: float | None = Field(default=None, ge=0.0, le=10.0)
    estimated_baseline_spend: Decimal | None = None
    estimated_optimized_spend: Decimal | None = None
    estimated_savings: Decimal | None = None
    actual_spend: Decimal | None = None
    actual_savings: Decimal | None = None
    mode_breakdown: dict[AppMode, int] = Field(default_factory=dict)
