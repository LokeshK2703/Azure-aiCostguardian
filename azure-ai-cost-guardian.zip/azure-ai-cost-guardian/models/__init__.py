"""Shared data models for Azure AI Cost Guardian."""
