"""Request-side Pydantic contracts.

The prompt text in PromptRequest is transient for active processing and must not be
persisted to telemetry, logs, or local data files in this MVP.
"""

from __future__ import annotations

from uuid import UUID, uuid4

from pydantic import BaseModel, Field, field_validator

from models.enums import AppMode, LogicalTier, SelectionSource


class PromptRequest(BaseModel):
    """Raw prompt payload for in-memory processing only."""

    request_id: UUID = Field(default_factory=uuid4)
    prompt: str = Field(min_length=1, description="Transient prompt content.")
    app_mode: AppMode = Field(default=AppMode.DEMO)

    @field_validator("prompt")
    @classmethod
    def validate_prompt_not_whitespace(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Prompt must not be empty or whitespace-only.")
        return value


class AnalysisRequest(BaseModel):
    """Request contract for analysis-only operations."""

    prompt_request: PromptRequest
    estimated_input_tokens: int | None = Field(
        default=None,
        ge=0,
        description="Optional precomputed input-token estimate used for guardrail validation.",
    )


class ModelSelection(BaseModel):
    """User or router tier selection metadata."""

    tier: LogicalTier
    source: SelectionSource = Field(default=SelectionSource.RECOMMENDATION)


class ExecutionRequest(BaseModel):
    """Execution contract for demo or Azure mode adapters."""

    request_id: UUID = Field(default_factory=uuid4)
    prompt: str = Field(min_length=1)
    app_mode: AppMode
    selected_tier: LogicalTier
    selection_source: SelectionSource

    @field_validator("prompt")
    @classmethod
    def validate_prompt_not_whitespace(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Prompt must not be empty or whitespace-only.")
        return value
