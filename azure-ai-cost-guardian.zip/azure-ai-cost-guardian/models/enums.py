"""Central enum definitions for Azure AI Cost Guardian."""

from enum import StrEnum


class AppMode(StrEnum):
    DEMO = "demo"
    AZURE = "azure"


class LogicalTier(StrEnum):
    ECONOMY = "economy"
    BALANCED = "balanced"
    ADVANCED = "advanced"


class ComplexityLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class TaskCategory(StrEnum):
    SUMMARIZATION = "summarization"
    EMAIL = "email"
    DOCUMENTATION = "documentation"
    TECHNICAL_EXPLANATION = "technical_explanation"
    ARCHITECTURE_DESIGN = "architecture_design"
    CODE_GENERATION = "code_generation"
    GENERAL_QA = "general_qa"


class SelectionSource(StrEnum):
    RECOMMENDATION = "recommendation"
    USER_OVERRIDE = "user_override"


class ValueOrigin(StrEnum):
    ESTIMATED = "estimated"
    ACTUAL = "actual"
    SYNTHETIC = "synthetic"
    UNAVAILABLE = "unavailable"


class ExecutionStatus(StrEnum):
    NOT_STARTED = "not_started"
    SUCCESS = "success"
    FAILED = "failed"
    BLOCKED = "blocked"


class ErrorCategory(StrEnum):
    VALIDATION = "validation"
    CONFIGURATION = "configuration"
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    RATE_LIMIT = "rate_limit"
    TIMEOUT = "timeout"
    NETWORK = "network"
    SERVICE = "service"
    DEPLOYMENT_UNAVAILABLE = "deployment_unavailable"
    USAGE_UNAVAILABLE = "usage_unavailable"
    TELEMETRY = "telemetry"
    DEMO_GENERATION = "demo_generation"
    UNKNOWN = "unknown"


class TokenEstimationMethod(StrEnum):
    TIKTOKEN = "tiktoken"
    ENCODING_FALLBACK = "encoding_fallback"
    CHARACTER_FALLBACK = "character_fallback"
