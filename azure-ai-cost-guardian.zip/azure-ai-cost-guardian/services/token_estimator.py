"""Deterministic token estimation service."""

from __future__ import annotations

import math
import re

import tiktoken

from config import RoutingPolicy
from models.enums import TaskCategory, TokenEstimationMethod
from models.request_models import PromptRequest
from models.response_models import TokenEstimate

_DETAIL_TERMS = (
    "detailed", "comprehensive", "complete", "long-form", "in-depth", "all steps", "full implementation",
)


def _normalize(text: str) -> str:
    return " ".join(text.lower().split())


def _contains_detailed_output_request(normalized: str) -> bool:
    for term in _DETAIL_TERMS:
        if " " in term and term in normalized:
            return True
        if " " not in term and re.search(rf"\b{re.escape(term)}\b", normalized):
            return True
    return False


def _estimate_input_tokens(prompt: str, model_hint: str | None = None) -> tuple[int, TokenEstimationMethod, str]:
    if model_hint:
        try:
            encoding = tiktoken.encoding_for_model(model_hint)
            return len(encoding.encode(prompt)), TokenEstimationMethod.TIKTOKEN, "Used model-specific tiktoken encoding."
        except Exception:
            pass

    try:
        encoding = tiktoken.get_encoding("cl100k_base")
        return len(encoding.encode(prompt)), TokenEstimationMethod.ENCODING_FALLBACK, "Used cl100k_base encoding fallback."
    except Exception:
        estimate = math.ceil(len(prompt) / 4)
        return estimate, TokenEstimationMethod.CHARACTER_FALLBACK, "Used character-based fallback estimate."


def estimate_tokens(
    request: PromptRequest,
    routing_policy: RoutingPolicy,
    task_category: TaskCategory,
    model_hint: str | None = None,
) -> TokenEstimate:
    """Estimate input/output/total tokens using configured policy and safe fallbacks."""

    prompt = request.prompt
    if not prompt.strip():
        raise ValueError("Prompt must not be empty or whitespace-only.")

    input_tokens, method, method_note = _estimate_input_tokens(prompt, model_hint=model_hint)
    max_input = routing_policy.input_limits.max_estimated_input_tokens
    if input_tokens > max_input:
        raise ValueError(f"Estimated input tokens exceed max_estimated_input_tokens ({max_input}).")

    ratio = routing_policy.output_token_ratios_by_task[task_category]
    normalized = _normalize(prompt)
    detail_multiplier = 1.2 if _contains_detailed_output_request(normalized) else 1.0

    MIN_OUTPUT_TOKENS = 150  # floor: models always generate at least ~150 tokens for real responses
    output_tokens = math.ceil(input_tokens * ratio * detail_multiplier)
    output_tokens = max(MIN_OUTPUT_TOKENS, output_tokens)

    max_output = routing_policy.input_limits.max_estimated_output_tokens
    output_was_clamped = False
    if output_tokens > max_output:
        output_tokens = max_output
        output_was_clamped = True

    total_tokens = input_tokens + output_tokens
    output_floored = output_tokens == MIN_OUTPUT_TOKENS and math.ceil(input_tokens * ratio * detail_multiplier) < MIN_OUTPUT_TOKENS
    explanation = (
        f"{method_note} Output ratio for {task_category.value}={ratio:.2f}; "
        f"detail_multiplier={detail_multiplier:.1f}; min_floor={MIN_OUTPUT_TOKENS}; "
        f"output_floored={output_floored}; output_clamped={output_was_clamped}."
    )

    return TokenEstimate(
        method=method,
        estimated_input_tokens=input_tokens,
        estimated_output_tokens=output_tokens,
        estimated_total_tokens=total_tokens,
        explanation=explanation,
        output_was_clamped=output_was_clamped,
        input_within_limit=True,
    )
