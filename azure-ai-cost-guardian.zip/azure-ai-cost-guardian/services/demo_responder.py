"""Deterministic demo response adapter for local MVP execution."""

from __future__ import annotations

import math
from typing import Final

from models.enums import AppMode, ExecutionStatus, TaskCategory, ValueOrigin
from models.request_models import ExecutionRequest
from models.response_models import ExecutionResult
from services.prompt_analyzer import analyze_prompt
from config import load_routing_policy
from models.request_models import AnalysisRequest, PromptRequest

_RESPONSE_TEMPLATES: Final[dict[TaskCategory, str]] = {
    TaskCategory.SUMMARIZATION: (
        "Deterministic Demo Mode Response\n"
        "Summary\n"
        "This deterministic Demo Mode response shows how Cost Guardian presents a structured meeting-notes outcome.\n"
        "\n"
        "Key Decisions\n"
        "- Proceed with the phased delivery plan beginning with the highest-risk dependency track.\n"
        "- Confirm one accountable owner per workstream to reduce cross-team delays.\n"
        "- Standardize weekly reporting with a shared milestone dashboard.\n"
        "\n"
        "Action Items\n"
        "- Publish the decision log by end of day and circulate it to project stakeholders.\n"
        "- Document owners and target dates for each approved deliverable.\n"
        "- Schedule a checkpoint meeting to review progress and blockers."
    ),
    TaskCategory.EMAIL: (
        "Deterministic Demo Mode Response\n"
        "Subject: Request for Project Timeline Confirmation and Next Steps\n"
        "\n"
        "Greeting\n"
        "Hello Team,\n"
        "\n"
        "Body\n"
        "Thank you for the recent planning discussion. We aligned on deliverables, dependencies, and ownership for the next milestone window.\n"
        "\n"
        "Please confirm whether the current timeline and milestone dates are still accurate based on your team capacity and dependency status.\n"
        "\n"
        "Requested Action\n"
        "Please reply by Thursday with one of the following: confirmed as-is, requires date adjustments, or blocked by dependency risk.\n"
        "\n"
        "Closing\n"
        "Best regards,\nProgram Lead"
    ),
    TaskCategory.DOCUMENTATION: (
        "Deterministic Demo Mode Response\n"
        "Purpose\n"
        "Define a repeatable operating approach so teams can execute the workflow consistently and safely.\n"
        "\n"
        "Requirements\n"
        "- Confirm required access roles before execution.\n"
        "- Validate configuration values in a non-production environment first.\n"
        "- Ensure rollback and support contacts are documented.\n"
        "\n"
        "Implementation Notes\n"
        "- Execute steps in phase order and capture outcomes after each stage.\n"
        "- Record decision points and exceptions in an operational log.\n"
        "- Use consistent naming and versioning to simplify audits.\n"
        "\n"
        "Operational Considerations\n"
        "- Monitor key indicators after rollout for early anomaly detection.\n"
        "- Review incident handling ownership before go-live windows."
    ),
    TaskCategory.TECHNICAL_EXPLANATION: (
        "Deterministic Demo Mode Response\n"
        "TLS and mTLS Comparison\n"
        "- TLS authenticates the server to the client and encrypts communication.\n"
        "- mTLS authenticates both client and server and encrypts communication.\n"
        "\n"
        "When To Use\n"
        "- TLS is commonly suitable for public-facing applications where clients need to trust the service endpoint.\n"
        "- mTLS is useful for service-to-service communication, APIs, and regulated environments requiring strong client identity.\n"
        "\n"
        "Practical Enterprise Example\n"
        "- An internal payment service calls a transaction-processing API.\n"
        "- The API validates the payment service certificate before accepting requests.\n"
        "- The payment service validates the API certificate before sending sensitive transaction data.\n"
        "\n"
        "Note\n"
        "This deterministic demonstration is illustrative and is not an exhaustive security recommendation."
    ),
    TaskCategory.ARCHITECTURE_DESIGN: (
        "Deterministic Demo Mode Response\n"
        "Demonstration Architecture (Conceptual, Not Production Guidance)\n"
        "This deterministic example demonstrates how a secure cloud architecture summary can be presented in Demo Mode.\n"
        "\n"
        "Identity and Access\n"
        "- Central identity provider with role-based access and least-privilege controls.\n"
        "- Managed identities for workloads and certificate-based workload authentication where needed.\n"
        "\n"
        "Private Connectivity\n"
        "- Private endpoints for platform services and restricted egress through controlled network boundaries.\n"
        "- Encrypted service-to-service traffic over private network paths.\n"
        "\n"
        "Application Tier\n"
        "- Stateless application services behind a managed ingress with policy inspection and rate controls.\n"
        "\n"
        "Data Tier\n"
        "- Managed data services with encryption at rest, backup policies, and strict access segmentation.\n"
        "\n"
        "Monitoring\n"
        "- Centralized logs, metrics, and alerts with security-event forwarding for operations and audit teams.\n"
        "\n"
        "Resilience\n"
        "- Multi-zone deployment baseline with planned regional recovery and tested failover procedures.\n"
        "\n"
        "Governance\n"
        "- Policy baselines for security, networking, and data controls with exception tracking and ownership."
    ),
    TaskCategory.CODE_GENERATION: (
        "Deterministic Demo Mode Response\n"
        "Code Sample\n"
        "```python\n"
        "def normalize_records(records: list[dict[str, str]]) -> list[dict[str, str]]:\n"
        "    normalized: list[dict[str, str]] = []\n"
        "    for record in records:\n"
        "        item = {\n"
        "            \"id\": record.get(\"id\", \"\").strip(),\n"
        "            \"owner\": record.get(\"owner\", \"\").strip().title(),\n"
        "            \"status\": record.get(\"status\", \"unknown\").strip().lower(),\n"
        "        }\n"
        "        if item[\"id\"]:\n"
        "            normalized.append(item)\n"
        "    return normalized\n"
        "```\n"
        "\n"
        "Explanation\n"
        "The function standardizes key fields, applies consistent casing, and ignores incomplete records without identifiers.\n"
        "\n"
        "Validation Notes\n"
        "- Verify that empty identifiers are excluded as expected.\n"
        "- Confirm owner and status normalization rules with representative samples."
    ),
    TaskCategory.GENERAL_QA: (
        "Deterministic Demo Mode Response\n"
        "Answer\n"
        "This topic can be understood as a combination of clear definitions, practical constraints, and decision trade-offs that affect implementation quality.\n"
        "\n"
        "Context\n"
        "Teams typically evaluate this area by balancing reliability, maintainability, security expectations, and delivery timelines.\n"
        "\n"
        "Recommended Follow-Up\n"
        "Identify the highest-priority decision criteria first, then validate options against those criteria with a small pilot review."
    ),
}

_GENERIC_DEMO_SUFFIX: Final[str] = (
    "This deterministic Demo Mode response demonstrates the product workflow. "
    "Connect an authorized live AI service for prompt-specific generated content."
)


def _normalize_text(value: str) -> str:
    return " ".join(value.lower().split())


def _has_all_terms(prompt: str, terms: tuple[str, ...]) -> bool:
    text = _normalize_text(prompt)
    return all(term in text for term in terms)


def _curated_response_for_prompt(prompt: str) -> str | None:
    if _has_all_terms(prompt, ("summarize", "meeting", "decisions", "action")):
        return _RESPONSE_TEMPLATES[TaskCategory.SUMMARIZATION]
    if _has_all_terms(prompt, ("draft", "business", "email")):
        return _RESPONSE_TEMPLATES[TaskCategory.EMAIL]
    if _has_all_terms(prompt, ("tls", "mtls")):
        return _RESPONSE_TEMPLATES[TaskCategory.TECHNICAL_EXPLANATION]
    if _has_all_terms(prompt, ("design", "secure")) and _has_all_terms(prompt, ("architecture",)):
        return _RESPONSE_TEMPLATES[TaskCategory.ARCHITECTURE_DESIGN]
    return None


def _fallback_response(category: TaskCategory) -> str:
    return f"{_RESPONSE_TEMPLATES[category]}\n\n{_GENERIC_DEMO_SUFFIX}"

_CATEGORY_LATENCY_MS: Final[dict[TaskCategory, int]] = {
    TaskCategory.SUMMARIZATION: 120,
    TaskCategory.EMAIL: 110,
    TaskCategory.DOCUMENTATION: 150,
    TaskCategory.TECHNICAL_EXPLANATION: 140,
    TaskCategory.ARCHITECTURE_DESIGN: 180,
    TaskCategory.CODE_GENERATION: 160,
    TaskCategory.GENERAL_QA: 100,
}

_TIER_LATENCY_MS: Final[dict[str, int]] = {
    "economy": 15,
    "balanced": 25,
    "advanced": 35,
}

_CATEGORY_OUTPUT_RATIO: Final[dict[TaskCategory, float]] = {
    TaskCategory.SUMMARIZATION: 0.45,
    TaskCategory.EMAIL: 0.60,
    TaskCategory.DOCUMENTATION: 0.85,
    TaskCategory.TECHNICAL_EXPLANATION: 0.80,
    TaskCategory.ARCHITECTURE_DESIGN: 0.90,
    TaskCategory.CODE_GENERATION: 0.70,
    TaskCategory.GENERAL_QA: 0.55,
}


def _detect_task_category(prompt: str) -> TaskCategory:
    policy, _ = load_routing_policy()
    analysis = analyze_prompt(
        AnalysisRequest(prompt_request=PromptRequest(prompt=prompt)),
        policy,
    )
    return analysis.task_category


def _synthetic_input_tokens(prompt: str) -> int:
    return max(1, math.ceil(len(prompt) / 4))


def _synthetic_output_tokens(prompt: str, category: TaskCategory) -> int:
    input_tokens = _synthetic_input_tokens(prompt)
    output_tokens = math.ceil(input_tokens * _CATEGORY_OUTPUT_RATIO[category])
    return max(1, output_tokens)


def generate_demo_response(request: ExecutionRequest) -> ExecutionResult:
    """Generate a deterministic synthetic response for local demo mode."""

    if request.app_mode != AppMode.DEMO:
        raise ValueError("Demo responder only supports demo mode.")

    category = _detect_task_category(request.prompt)
    response_text = _curated_response_for_prompt(request.prompt) or _fallback_response(category)
    input_tokens = _synthetic_input_tokens(request.prompt)
    output_tokens = _synthetic_output_tokens(request.prompt, category)
    latency_ms = _CATEGORY_LATENCY_MS[category] + _TIER_LATENCY_MS[request.selected_tier.value]

    return ExecutionResult(
        request_id=request.request_id,
        app_mode=request.app_mode,
        execution_status=ExecutionStatus.SUCCESS,
        executed_tier=request.selected_tier,
        selection_source=request.selection_source,
        response_text=response_text,
        latency_ms=latency_ms,
        actual_input_tokens=input_tokens,
        actual_output_tokens=output_tokens,
        actual_total_tokens=input_tokens + output_tokens,
        value_origins={
            "response_text": ValueOrigin.SYNTHETIC,
            "latency_ms": ValueOrigin.SYNTHETIC,
            "actual_input_tokens": ValueOrigin.SYNTHETIC,
            "actual_output_tokens": ValueOrigin.SYNTHETIC,
            "actual_total_tokens": ValueOrigin.SYNTHETIC,
        },
    )
