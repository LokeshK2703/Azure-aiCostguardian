"""Deterministic configurable cost calculator."""

from __future__ import annotations

from decimal import Decimal

from config import ModelPricing, TierPricing
from models.enums import LogicalTier, ValueOrigin
from models.response_models import CostBreakdown, CostComparison, TokenEstimate

_MILLION = Decimal("1000000")


def _as_decimal(value: int) -> Decimal:
    return Decimal(value)


def _validate_tokens(input_tokens: int, output_tokens: int) -> None:
    if input_tokens < 0 or output_tokens < 0:
        raise ValueError("Token counts must be non-negative.")


def calculate_tier_cost(
    input_tokens: int,
    output_tokens: int,
    tier_pricing: TierPricing,
    origin: ValueOrigin,
) -> CostBreakdown:
    """Calculate tier cost for a token pair, or mark unavailable when pricing is null."""

    _validate_tokens(input_tokens, output_tokens)

    if (
        tier_pricing.input_price_per_million_tokens is None
        or tier_pricing.output_price_per_million_tokens is None
    ):
        return CostBreakdown(
            input_cost=None,
            output_cost=None,
            total_cost=None,
            value_origin=ValueOrigin.UNAVAILABLE,
        )

    input_cost = (_as_decimal(input_tokens) / _MILLION) * tier_pricing.input_price_per_million_tokens
    output_cost = (_as_decimal(output_tokens) / _MILLION) * tier_pricing.output_price_per_million_tokens
    total_cost = input_cost + output_cost
    return CostBreakdown(
        input_cost=input_cost,
        output_cost=output_cost,
        total_cost=total_cost,
        value_origin=origin,
    )


def _savings_percentage(savings: Decimal, baseline_total: Decimal) -> Decimal | None:
    if baseline_total == 0:
        return None
    return (savings / baseline_total) * Decimal("100")


def estimate_costs(
    tokens: TokenEstimate,
    pricing: ModelPricing,
    routed_tier: LogicalTier,
) -> CostComparison:
    """Calculate estimated routed-vs-baseline costs using estimated token quantities."""

    routed_breakdown = calculate_tier_cost(
        input_tokens=tokens.estimated_input_tokens,
        output_tokens=tokens.estimated_output_tokens,
        tier_pricing=pricing.tiers[routed_tier],
        origin=ValueOrigin.ESTIMATED,
    )
    baseline_breakdown = calculate_tier_cost(
        input_tokens=tokens.estimated_input_tokens,
        output_tokens=tokens.estimated_output_tokens,
        tier_pricing=pricing.tiers[pricing.baseline_tier],
        origin=ValueOrigin.ESTIMATED,
    )

    if routed_breakdown.total_cost is None or baseline_breakdown.total_cost is None:
        return CostComparison(
            explanation="Estimated cost comparison unavailable until verified tier pricing is configured.",
            estimated_value_origin=ValueOrigin.UNAVAILABLE,
            actual_value_origin=ValueOrigin.UNAVAILABLE,
        )

    savings_amount = baseline_breakdown.total_cost - routed_breakdown.total_cost
    savings_pct = _savings_percentage(savings_amount, baseline_breakdown.total_cost)

    return CostComparison(
        estimated_baseline_cost=baseline_breakdown.total_cost,
        estimated_routed_cost=routed_breakdown.total_cost,
        estimated_savings_amount=savings_amount,
        estimated_savings_percentage=savings_pct,
        explanation="Estimated comparison calculated from configured pricing and estimated token counts.",
        estimated_value_origin=ValueOrigin.ESTIMATED,
        actual_value_origin=ValueOrigin.UNAVAILABLE,
    )


def apply_actual_usage(
    existing: CostComparison,
    pricing: ModelPricing,
    routed_tier: LogicalTier,
    actual_input_tokens: int | None,
    actual_output_tokens: int | None,
) -> CostComparison:
    """Add actual routed-vs-baseline costs when API-reported usage is available."""

    if actual_input_tokens is None or actual_output_tokens is None:
        existing.actual_value_origin = ValueOrigin.UNAVAILABLE
        return existing

    routed_actual = calculate_tier_cost(
        input_tokens=actual_input_tokens,
        output_tokens=actual_output_tokens,
        tier_pricing=pricing.tiers[routed_tier],
        origin=ValueOrigin.ACTUAL,
    )
    baseline_actual = calculate_tier_cost(
        input_tokens=actual_input_tokens,
        output_tokens=actual_output_tokens,
        tier_pricing=pricing.tiers[pricing.baseline_tier],
        origin=ValueOrigin.ACTUAL,
    )

    if routed_actual.total_cost is None or baseline_actual.total_cost is None:
        existing.actual_value_origin = ValueOrigin.UNAVAILABLE
        return existing

    actual_savings = baseline_actual.total_cost - routed_actual.total_cost
    actual_savings_pct = _savings_percentage(actual_savings, baseline_actual.total_cost)
    existing.actual_baseline_cost = baseline_actual.total_cost
    existing.actual_routed_cost = routed_actual.total_cost
    existing.actual_savings_amount = actual_savings
    existing.actual_savings_percentage = actual_savings_pct
    existing.actual_value_origin = ValueOrigin.ACTUAL
    return existing
