"""Privacy-safe local telemetry persistence service."""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from models.response_models import TelemetryRecord


def _coerce_path(file_path: str | Path) -> Path:
    return file_path if isinstance(file_path, Path) else Path(file_path)


def _read_raw_records(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []

    try:
        payload = path.read_text(encoding="utf-8").strip()
    except OSError:
        return []

    if not payload:
        return []

    try:
        data = json.loads(payload)
    except json.JSONDecodeError:
        return []

    if not isinstance(data, list):
        return []

    return [item for item in data if isinstance(item, dict)]


def read_telemetry_records(file_path: str | Path = "data/telemetry.json") -> list[TelemetryRecord]:
    """Load persisted telemetry records, recovering safely from missing or invalid files."""

    path = _coerce_path(file_path)
    records: list[TelemetryRecord] = []
    for item in _read_raw_records(path):
        try:
            records.append(TelemetryRecord.model_validate(item))
        except ValidationError:
            continue
    return records


def _apply_retention(
    records: list[TelemetryRecord],
    *,
    max_records: int,
    retention_days: int,
    now: datetime,
) -> list[TelemetryRecord]:
    cutoff = now - timedelta(days=retention_days)
    retained = [record for record in records if record.timestamp_utc >= cutoff]
    retained.sort(key=lambda record: record.timestamp_utc)
    if len(retained) > max_records:
        retained = retained[-max_records:]
    return retained


def _atomic_write_records(path: Path, records: list[TelemetryRecord]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    payload = [record.model_dump(mode="json") for record in records]

    try:
        temp_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        os.replace(temp_path, path)
    finally:
        if temp_path.exists():
            temp_path.unlink(missing_ok=True)


def persist_telemetry(
    record: TelemetryRecord,
    file_path: str | Path = "data/telemetry.json",
    *,
    max_records: int = 1000,
    retention_days: int = 30,
    now: datetime | None = None,
) -> None:
    """Persist one telemetry record using atomic JSON writes and retention enforcement."""

    path = _coerce_path(file_path)
    current_records = read_telemetry_records(path)
    effective_now = now or datetime.now(timezone.utc)
    retained = _apply_retention(
        [*current_records, record],
        max_records=max_records,
        retention_days=retention_days,
        now=effective_now,
    )
    _atomic_write_records(path, retained)
