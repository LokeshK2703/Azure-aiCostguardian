"""Deterministic model routing service with explainable confidence."""

from __future__ import annotations

from decimal import Decimal

from config import RoutingPolicy
from models.enums import (
    ErrorCategory,
    ExecutionStatus,
    LogicalTier,
    SelectionSource,
    TokenEstimationMethod,
)
from models.response_models import ConfidenceAdjustment, PromptAnalysis, RoutingDecision, TokenEstimate


def _nearest_boundary_distance(score: float, low_to_medium: float, medium_to_high: float) -> Decimal:
    d_score = Decimal(str(score))
    d_low = Decimal(str(low_to_medium))
    d_high = Decimal(str(medium_to_high))
    return min(abs(d_score - d_low), abs(d_score - d_high))


def _tier_for_score(score: float, low_to_medium: float, medium_to_high: float) -> LogicalTier:
    d_score = Decimal(str(score))
    if d_score < Decimal(str(low_to_medium)):
        return LogicalTier.ECONOMY
    if d_score < Decimal(str(medium_to_high)):
        return LogicalTier.BALANCED
    return LogicalTier.ADVANCED


def recommend_tier(
    analysis: PromptAnalysis,
    token_estimate: TokenEstimate,
    routing_policy: RoutingPolicy,
    configured_tiers: set[LogicalTier] | None = None,
) -> RoutingDecision:
    """Recommend a logical tier and confidence without performing fallback or execution."""

    thresholds = routing_policy.complexity_thresholds
    cpolicy = routing_policy.confidence_policy
    score = analysis.adjusted_complexity_score

    recommended = _tier_for_score(score, thresholds.low_to_medium, thresholds.medium_to_high)
    confidence = cpolicy.base_confidence

    distance = _nearest_boundary_distance(score, thresholds.low_to_medium, thresholds.medium_to_high)
    boundary_applies = distance <= Decimal(str(cpolicy.boundary_window))
    if boundary_applies:
        confidence += cpolicy.boundary_penalty

    short_or_ambiguous = analysis.is_short_prompt or analysis.is_ambiguous
    if short_or_ambiguous:
        confidence += cpolicy.short_or_ambiguous_penalty

    char_fallback = token_estimate.method == TokenEstimationMethod.CHARACTER_FALLBACK
    if char_fallback:
        confidence += cpolicy.character_fallback_penalty

    if analysis.strong_agreement:
        confidence += cpolicy.strong_agreement_bonus

    confidence = max(cpolicy.minimum_confidence, min(cpolicy.maximum_confidence, confidence))

    adjustments = [
        ConfidenceAdjustment(
            name="boundary_window_penalty",
            delta=cpolicy.boundary_penalty,
            applied=boundary_applies,
            reason=f"Applied when distance to nearest boundary <= {cpolicy.boundary_window}.",
        ),
        ConfidenceAdjustment(
            name="short_or_ambiguous_penalty",
            delta=cpolicy.short_or_ambiguous_penalty,
            applied=short_or_ambiguous,
            reason="Applied once when prompt is short or ambiguous (or both).",
        ),
        ConfidenceAdjustment(
            name="character_fallback_penalty",
            delta=cpolicy.character_fallback_penalty,
            applied=char_fallback,
            reason="Applied when character-based token estimation fallback is used.",
        ),
        ConfidenceAdjustment(
            name="strong_agreement_bonus",
            delta=cpolicy.strong_agreement_bonus,
            applied=analysis.strong_agreement,
            reason="Applied when category and complexity indicators strongly agree.",
        ),
    ]

    configured_list = sorted(configured_tiers or set(), key=lambda tier: tier.value)
    tier_configured = None
    status = ExecutionStatus.NOT_STARTED
    error_category = None
    error_message = None
    if configured_tiers is not None:
        tier_configured = recommended in configured_tiers
        if not tier_configured:
            status = ExecutionStatus.BLOCKED
            error_category = ErrorCategory.DEPLOYMENT_UNAVAILABLE
            error_message = "Recommended logical tier is not currently configured."

    explanation = (
        "Confidence reflects routing recommendation reliability, not generated-response correctness. "
        f"Base={cpolicy.base_confidence}; final={confidence}."
    )
    reason = (
        f"Complexity score {score:.1f} maps to {recommended.value} tier using configured thresholds "
        f"({thresholds.low_to_medium}, {thresholds.medium_to_high})."
    )

    return RoutingDecision(
        recommended_tier=recommended,
        complexity_score=score,
        confidence=confidence,
        reason=reason,
        confidence_explanation=explanation,
        factors_considered=[
            "adjusted_complexity_score",
            "boundary_proximity",
            "short_or_ambiguous",
            "token_estimation_method",
            "strong_agreement",
        ],
        confidence_adjustments=adjustments,
        recommended_tier_configured=tier_configured,
        configured_alternatives=[tier for tier in configured_list if tier != recommended],
        execution_status=status,
        error_category=error_category,
        error_message=error_message,
    )


def resolve_executed_tier(
    recommended_tier: LogicalTier,
    user_selected_tier: LogicalTier | None,
    configured_tiers: set[LogicalTier] | None = None,
    require_configured: bool = True,
) -> tuple[LogicalTier | None, SelectionSource | None, ExecutionStatus, str | None, list[LogicalTier]]:
    """Resolve executed tier with explicit override handling and no automatic fallback."""

    configured_alternatives = sorted(
        [tier for tier in (configured_tiers or set()) if tier != recommended_tier],
        key=lambda tier: tier.value,
    )

    if require_configured and configured_tiers is not None:
        if user_selected_tier is None and recommended_tier not in configured_tiers:
            return (
                None,
                None,
                ExecutionStatus.BLOCKED,
                "Recommended logical tier is not configured.",
                configured_alternatives,
            )

    if user_selected_tier is None:
        return (
            recommended_tier,
            SelectionSource.RECOMMENDATION,
            ExecutionStatus.NOT_STARTED,
            None,
            configured_alternatives,
        )

    if configured_tiers is not None and user_selected_tier not in configured_tiers:
        raise ValueError("Selected logical tier is not configured.")

    if user_selected_tier == recommended_tier:
        return (
            recommended_tier,
            SelectionSource.RECOMMENDATION,
            ExecutionStatus.NOT_STARTED,
            None,
            configured_alternatives,
        )

    return (
        user_selected_tier,
        SelectionSource.USER_OVERRIDE,
        ExecutionStatus.NOT_STARTED,
        None,
        configured_alternatives,
    )
