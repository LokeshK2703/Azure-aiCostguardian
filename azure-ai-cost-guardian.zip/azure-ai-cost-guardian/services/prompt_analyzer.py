"""Deterministic prompt analysis service.

This module performs prompt validation, category classification, complexity scoring,
and explainability signal extraction without network calls or side effects.
"""

from __future__ import annotations

import math
import re
from decimal import Decimal

from config import RoutingPolicy
from models.enums import ComplexityLevel, TaskCategory
from models.request_models import AnalysisRequest
from models.response_models import ComplexityFactor, PromptAnalysis

_WORD_RE = re.compile(r"[a-zA-Z0-9_]+")

_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "has", "have",
    "how", "i", "in", "is", "it", "of", "on", "or", "that", "the", "this", "to", "was",
    "were", "what", "when", "where", "which", "who", "why", "with", "you", "your",
}

_CATEGORY_INDICATORS: dict[TaskCategory, tuple[str, ...]] = {
    TaskCategory.SUMMARIZATION: (
        "summarize", "summary", "condense", "key points", "action items", "meeting notes",
        "transcript", "brief overview",
    ),
    TaskCategory.EMAIL: (
        "email", "reply", "draft message", "subject line", "recipient", "follow-up",
        "professional message",
    ),
    TaskCategory.DOCUMENTATION: (
        "documentation", "readme", "runbook", "guide", "standard operating procedure",
        "procedure", "user manual", "technical document",
    ),
    TaskCategory.TECHNICAL_EXPLANATION: (
        "explain", "elaborate", "compare", "difference between", "how does", "technical concept",
        "troubleshoot", "root cause",
    ),
    TaskCategory.ARCHITECTURE_DESIGN: (
        "architecture", "landing zone", "high availability", "disaster recovery", "multi-region",
        "network topology", "private endpoint", "identity architecture", "governance design",
        "scalability", "system design",
    ),
    TaskCategory.CODE_GENERATION: (
        "write code", "generate code", "implement", "function", "class", "script", "python",
        "powershell", "terraform", "bicep", "api implementation", "refactor code",
    ),
    TaskCategory.GENERAL_QA: (),
}

_CATEGORY_PRECEDENCE: tuple[TaskCategory, ...] = (
    TaskCategory.ARCHITECTURE_DESIGN,
    TaskCategory.CODE_GENERATION,
    TaskCategory.SUMMARIZATION,
    TaskCategory.EMAIL,
    TaskCategory.DOCUMENTATION,
    TaskCategory.TECHNICAL_EXPLANATION,
    TaskCategory.GENERAL_QA,
)

_ACTION_SIGNALS = (
    "summarize", "write", "generate", "implement", "explain", "design", "compare", "analyze",
    "evaluate", "recommend", "create", "draft", "review", "optimize", "troubleshoot", "validate",
)

_TARGET_SIGNALS = (
    "email", "function", "class", "architecture", "runbook", "guide", "report", "json", "yaml",
    "plan", "summary", "script", "code", "system", "policy", "model", "deployment",
)

_DEICTIC_PATTERNS = (
    "do this", "fix it", "explain that", "make this better", "what about this",
)

_REASONING_TERMS = (
    "analyze", "evaluate", "recommend", "trade-off", "tradeoff", "justify", "root cause", "strategy", "decision",
    "optimize", "compare alternatives",
)

_ARCH_SECURITY_TERMS = (
    "architecture", "architectural design", "landing zone", "azure ai landing zone", "system design",
    "multi-region", "high availability", "scalability", "secure", "security", "private connectivity",
    "private endpoint", "identity", "identity governance", "managed identity", "zero trust", "governance",
    "compliance", "regulatory", "policy", "healthcare", "data protection", "disaster recovery", "resilience",
    "business continuity", "failover", "recovery", "availability", "monitoring",
)

_CODE_TERMS = (
    "write code", "generate code", "implement", "debug", "refactor", "function", "class",
    "script", "python", "powershell", "terraform", "bicep",
)

_OUTPUT_SIZE_TERMS = (
    "detailed", "comprehensive", "complete", "long-form", "in-depth", "all steps", "full implementation",
)

_OUTPUT_STRUCTURE_TERMS = (
    "table", "json", "yaml", "numbered plan", "multiple sections", "architecture diagram",
    "code plus explanation", "formal report",
)

_ARCH_SECURITY_GROUPS: dict[str, tuple[str, ...]] = {
    "core_architecture": (
        "architecture", "architectural design", "landing zone", "azure ai landing zone", "system design",
        "application tier", "database", "scalability",
    ),
    "availability_operations": (
        "monitoring", "high availability", "availability", "observability",
    ),
    "security_private_connectivity": (
        "secure", "security", "private connectivity", "private endpoint", "zero trust",
    ),
    "identity_governance": (
        "identity", "identity governance", "managed identity", "access control", "governance", "policy",
    ),
    "compliance_regulated": (
        "compliance", "regulatory", "healthcare", "financial services", "data protection",
    ),
    "multi_region_resilience_recovery": (
        "multi-region", "disaster recovery", "business continuity", "failover", "recovery", "resilience",
    ),
}


def _normalize(text: str) -> str:
    return " ".join(text.lower().split())


def _meaningful_words(text: str) -> list[str]:
    words = [w.lower() for w in _WORD_RE.findall(text)]
    return [w for w in words if w not in _STOPWORDS]


def _score_category(normalized: str, indicators: tuple[str, ...]) -> int:
    score = 0
    for indicator in indicators:
        if " " in indicator:
            if indicator in normalized:
                score += 2
        else:
            if re.search(rf"\b{re.escape(indicator)}\b", normalized):
                score += 1
    return score


def _detect_category(normalized: str) -> tuple[TaskCategory, dict[TaskCategory, int], bool]:
    scores: dict[TaskCategory, int] = {
        category: _score_category(normalized, indicators)
        for category, indicators in _CATEGORY_INDICATORS.items()
    }

    max_score = max(scores.values())
    if max_score <= 0:
        return TaskCategory.GENERAL_QA, scores, False

    winners = [category for category, value in scores.items() if value == max_score]
    if len(winners) == 1:
        return winners[0], scores, False

    for category in _CATEGORY_PRECEDENCE:
        if category in winners:
            return category, scores, True

    return TaskCategory.GENERAL_QA, scores, True


def _count_matches(normalized: str, terms: tuple[str, ...]) -> int:
    count = 0
    for term in terms:
        if " " in term:
            if term in normalized:
                count += 1
        else:
            if re.search(rf"\b{re.escape(term)}\b", normalized):
                count += 1
    return count


def _group_match_count(normalized: str, groups: dict[str, tuple[str, ...]]) -> int:
    matched = 0
    for terms in groups.values():
        if _count_matches(normalized, terms) > 0:
            matched += 1
    return matched


def _matched_groups(normalized: str, groups: dict[str, tuple[str, ...]]) -> set[str]:
    matched: set[str] = set()
    for group_name, terms in groups.items():
        if _count_matches(normalized, terms) > 0:
            matched.add(group_name)
    return matched


def _clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def _to_level(score: float, low_to_medium: float, medium_to_high: float) -> ComplexityLevel:
    d_score = Decimal(str(score))
    d_low = Decimal(str(low_to_medium))
    d_high = Decimal(str(medium_to_high))
    if d_score < d_low:
        return ComplexityLevel.LOW
    if d_score < d_high:
        return ComplexityLevel.MEDIUM
    return ComplexityLevel.HIGH


def _prior_band(prior: float) -> ComplexityLevel:
    if prior < 0.4:
        return ComplexityLevel.LOW
    if prior < 0.75:
        return ComplexityLevel.MEDIUM
    return ComplexityLevel.HIGH


def analyze_prompt(request: AnalysisRequest, routing_policy: RoutingPolicy) -> PromptAnalysis:
    """Analyze prompt complexity and routing-relevant explainability signals."""

    prompt = request.prompt_request.prompt
    normalized = _normalize(prompt)
    char_count = len(prompt)

    if not prompt.strip():
        raise ValueError("Prompt must not be empty or whitespace-only.")

    limits = routing_policy.input_limits
    if char_count > limits.max_prompt_characters:
        raise ValueError(
            f"Prompt exceeds max_prompt_characters limit ({limits.max_prompt_characters})."
        )

    if request.estimated_input_tokens is not None and request.estimated_input_tokens > limits.max_estimated_input_tokens:
        raise ValueError(
            f"Estimated input tokens exceed max_estimated_input_tokens ({limits.max_estimated_input_tokens})."
        )

    meaningful_words = _meaningful_words(prompt)
    category, evidence, used_precedence = _detect_category(normalized)

    action_present = _count_matches(normalized, _ACTION_SIGNALS) > 0 or "?" in prompt
    target_present = _count_matches(normalized, _TARGET_SIGNALS) > 0

    ambiguity_reasons: list[str] = []
    if len(meaningful_words) < 3:
        ambiguity_reasons.append("Fewer than three meaningful words.")

    if not action_present and not target_present:
        ambiguity_reasons.append("Missing recognizable action/question and subject signals.")

    if any(pattern in normalized for pattern in _DEICTIC_PATTERNS):
        ambiguity_reasons.append("Relies on deictic wording without context.")

    non_zero_scores = [score for score in evidence.values() if score > 0]
    sorted_scores = sorted(non_zero_scores, reverse=True)
    if len(sorted_scores) >= 3:
        top = sorted_scores[0]
        second = sorted_scores[1]
        if (top - second) < 1:
            ambiguity_reasons.append("Competing category evidence with no dominant lead margin.")

    is_ambiguous = len(ambiguity_reasons) > 0
    short_threshold = routing_policy.confidence_policy.short_prompt_threshold_characters
    is_short = char_count < short_threshold

    matched_arch_groups = _matched_groups(normalized, _ARCH_SECURITY_GROUPS)
    architecture_group_count = len(matched_arch_groups)
    action_count = _count_matches(normalized, _ACTION_SIGNALS)
    numbered_count = len(re.findall(r"\b\d+[\.)]\s", prompt))
    and_count = normalized.count(" and ")
    comma_count = normalized.count(",")
    architectural_dimensions = 0
    if category == TaskCategory.ARCHITECTURE_DESIGN:
        architectural_dimensions = max(0, architecture_group_count - 1)

    operation_units = (
        action_count
        + numbered_count
        + and_count
        + min(2, comma_count // 2)
        + architectural_dimensions
    )
    ops_signal = min(1.0, operation_units / 5.0)
    multistep_signal = min(
        1.0,
        (
            _count_matches(normalized, ("step-by-step", "steps", "phase", "stages", "first", "then", "finally"))
            + len(re.findall(r"\b\d+[\.)]\s", prompt))
        ) / 4.0,
    )
    reasoning_signal = min(1.0, (_count_matches(normalized, _REASONING_TERMS) + _count_matches(normalized, ("design",))) / 4.0)
    arch_sec_signal = min(1.0, architecture_group_count / 6.0)
    code_signal = min(1.0, _count_matches(normalized, _CODE_TERMS) / 4.0)
    output_size_signal = min(1.0, _count_matches(normalized, _OUTPUT_SIZE_TERMS) / 3.0)
    output_structure_signal = min(1.0, _count_matches(normalized, _OUTPUT_STRUCTURE_TERMS) / 3.0)

    max_chars = float(limits.max_prompt_characters)
    prompt_length_signal = _clamp01(math.sqrt(char_count / max_chars))
    task_prior_signal = routing_policy.task_category_priors[category]

    weights = routing_policy.complexity_factor_weights
    factor_values: dict[str, float] = {
        "task_prior": task_prior_signal,
        "prompt_length": prompt_length_signal,
        "requested_operations": ops_signal,
        "multi_step": multistep_signal,
        "reasoning_terms": reasoning_signal,
        "architecture_security": arch_sec_signal,
        "code_generation": code_signal,
        "requested_output_size": output_size_signal,
        "requested_output_structure": output_structure_signal,
    }

    weight_map: dict[str, float] = {
        "task_prior": weights.task_prior,
        "prompt_length": weights.prompt_length,
        "requested_operations": weights.requested_operations,
        "multi_step": weights.multi_step,
        "reasoning_terms": weights.reasoning_terminology,
        "architecture_security": weights.architecture_security_terminology,
        "code_generation": weights.code_generation_indicators,
        "requested_output_size": weights.requested_output_size,
        "requested_output_structure": weights.requested_output_structure,
    }

    complexity_factors: list[ComplexityFactor] = []
    weighted_sum = 0.0
    for name, normalized_value in factor_values.items():
        weight = weight_map[name]
        contribution = normalized_value * weight
        weighted_sum += contribution
        complexity_factors.append(
            ComplexityFactor(
                name=name,
                contribution=contribution,
                normalized_value=normalized_value,
                weight=weight,
                weighted_contribution=contribution,
                rationale=f"{name} signal={normalized_value:.2f}, weight={weight:.2f}",
            )
        )

    raw_score = round(max(0.0, min(10.0, 10.0 * weighted_sum)), 1)
    adjusted_score = raw_score
    applied_policy_rules: list[str] = []

    low_to_medium = routing_policy.complexity_thresholds.low_to_medium
    medium_to_high = routing_policy.complexity_thresholds.medium_to_high

    for floor_task, floor_level in routing_policy.minimum_complexity_by_task.items():
        if category == floor_task and floor_level == ComplexityLevel.MEDIUM and adjusted_score < low_to_medium:
            adjusted_score = low_to_medium
            applied_policy_rules.append(f"{floor_task.value} minimum complexity floor applied.")

    if (
        category == TaskCategory.TECHNICAL_EXPLANATION
        and arch_sec_signal >= 0.5
        and reasoning_signal >= 0.5
        and adjusted_score < medium_to_high
    ):
        adjusted_score = medium_to_high
        applied_policy_rules.append("Security-sensitive technical analysis elevated to High complexity.")

    has_security_private = "security_private_connectivity" in matched_arch_groups
    has_identity_or_compliance = (
        "identity_governance" in matched_arch_groups
        or "compliance_regulated" in matched_arch_groups
    )
    has_resilience = "multi_region_resilience_recovery" in matched_arch_groups

    if (
        category == TaskCategory.ARCHITECTURE_DESIGN
        and has_security_private
        and has_identity_or_compliance
        and has_resilience
        and architecture_group_count >= 4
        and ops_signal >= 0.6
        and reasoning_signal >= 0.25
        and adjusted_score < medium_to_high
    ):
        adjusted_score = medium_to_high
        applied_policy_rules.append(
            "Regulated or security-sensitive architecture elevated to High based on combined security, governance or compliance, and resilience requirements."
        )

    simple_summary = (
        category == TaskCategory.SUMMARIZATION
        and ops_signal <= 0.34
        and reasoning_signal < 0.5
        and arch_sec_signal < 0.5
        and output_structure_signal < 0.5
        and char_count < int(limits.max_prompt_characters * 0.4)
    )
    if simple_summary and adjusted_score >= low_to_medium:
        adjusted_score = round(low_to_medium - 0.1, 1)
        applied_policy_rules.append("Simple summarization kept in Low complexity band.")

    adjusted_score = round(max(0.0, min(10.0, adjusted_score)), 1)
    level = _to_level(adjusted_score, low_to_medium, medium_to_high)

    winner_score = evidence.get(category, 0)
    sorted_evidence = sorted(evidence.values(), reverse=True)
    second_score = sorted_evidence[1] if len(sorted_evidence) > 1 else -999
    no_close_contradiction = (winner_score - second_score) >= 1

    consistent_indicator_map: dict[TaskCategory, tuple[str, ...]] = {
        TaskCategory.ARCHITECTURE_DESIGN: ("architecture_security", "task_prior", "requested_operations"),
        TaskCategory.CODE_GENERATION: ("code_generation", "requested_output_structure", "requested_operations"),
        TaskCategory.SUMMARIZATION: ("task_prior", "prompt_length", "requested_operations"),
        TaskCategory.EMAIL: ("task_prior", "requested_output_structure", "requested_operations"),
        TaskCategory.DOCUMENTATION: ("requested_output_structure", "requested_output_size", "reasoning_terms"),
        TaskCategory.TECHNICAL_EXPLANATION: ("reasoning_terms", "requested_operations", "task_prior"),
        TaskCategory.GENERAL_QA: ("task_prior", "requested_operations", "prompt_length"),
    }
    high_consistent_count = sum(
        1 for key in consistent_indicator_map[category] if factor_values[key] >= 0.5
    )
    expected_band = _prior_band(task_prior_signal)
    strong_agreement = (
        winner_score >= 2
        and high_consistent_count >= 2
        and no_close_contradiction
        and expected_band == level
    )

    explanation = (
        f"Classified as {category.value}; raw score {raw_score:.1f}, adjusted score {adjusted_score:.1f} ({level.value}). "
        "This score is deterministic and based on configured policy weights."
    )

    return PromptAnalysis(
        prompt_character_count=char_count,
        meaningful_word_count=len(meaningful_words),
        task_category=category,
        raw_complexity_score=raw_score,
        adjusted_complexity_score=adjusted_score,
        complexity_score=adjusted_score,
        complexity_level=level,
        explanation=explanation,
        complexity_factors=complexity_factors,
        classification_evidence=evidence,
        category_precedence_used=used_precedence,
        is_short_prompt=is_short,
        is_ambiguous=is_ambiguous,
        ambiguity_reasons=ambiguity_reasons,
        strong_agreement=strong_agreement,
        applied_policy_rules=applied_policy_rules,
    )
