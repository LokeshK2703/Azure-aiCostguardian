"""Azure OpenAI client adapter for Azure mode execution."""

from __future__ import annotations

from time import perf_counter

from openai import (
    APIConnectionError,
    APIError,
    APITimeoutError,
    AuthenticationError,
    AzureOpenAI,
    BadRequestError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
)

from config import AppConfig, ConfigurationError, load_app_config
from models.enums import AppMode, ErrorCategory, ExecutionStatus, LogicalTier, ValueOrigin
from models.request_models import ExecutionRequest
from models.response_models import ExecutionResult, SafeError


def _deployment_for_tier(app_config: AppConfig, tier: LogicalTier) -> str:
    runtime = app_config.runtime
    mapping = {
        LogicalTier.ECONOMY: runtime.DEPLOYMENT_ECONOMY,
        LogicalTier.BALANCED: runtime.DEPLOYMENT_BALANCED,
        LogicalTier.ADVANCED: runtime.DEPLOYMENT_ADVANCED,
    }
    deployment = mapping[tier].strip()
    if not deployment:
        raise ConfigurationError("Deployment mapping is missing for the selected logical tier.")
    return deployment


def _build_client(app_config: AppConfig) -> AzureOpenAI:
    runtime = app_config.runtime
    if runtime.AZURE_OPENAI_AUTH_MODE == "entra":
        from azure.identity import AzureCliCredential, get_bearer_token_provider
        credential = AzureCliCredential()
        token_provider = get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")
        return AzureOpenAI(
            azure_ad_token_provider=token_provider,
            api_version=runtime.AZURE_OPENAI_API_VERSION,
            azure_endpoint=runtime.AZURE_OPENAI_ENDPOINT,
            timeout=runtime.AZURE_OPENAI_TIMEOUT_SECONDS,
        )
    return AzureOpenAI(
        api_key=runtime.AZURE_OPENAI_API_KEY,
        api_version=runtime.AZURE_OPENAI_API_VERSION,
        azure_endpoint=runtime.AZURE_OPENAI_ENDPOINT,
        timeout=runtime.AZURE_OPENAI_TIMEOUT_SECONDS,
    )


def _safe_error(category: ErrorCategory, message: str, retryable: bool) -> SafeError:
    return SafeError(category=category, message=message, retryable=retryable)


def _error_result(request: ExecutionRequest, tier: LogicalTier, error: SafeError) -> ExecutionResult:
    return ExecutionResult(
        request_id=request.request_id,
        app_mode=request.app_mode,
        execution_status=ExecutionStatus.BLOCKED if error.category in {ErrorCategory.CONFIGURATION, ErrorCategory.DEPLOYMENT_UNAVAILABLE, ErrorCategory.AUTHENTICATION, ErrorCategory.AUTHORIZATION} else ExecutionStatus.FAILED,
        executed_tier=tier,
        selection_source=request.selection_source,
        error=error,
        value_origins={
            "response_text": ValueOrigin.UNAVAILABLE,
            "latency_ms": ValueOrigin.UNAVAILABLE,
            "actual_input_tokens": ValueOrigin.UNAVAILABLE,
            "actual_output_tokens": ValueOrigin.UNAVAILABLE,
            "actual_total_tokens": ValueOrigin.UNAVAILABLE,
        },
    )


def _extract_message_text(response) -> str:
    choices = getattr(response, "choices", None) or []
    if not choices:
        return ""
    message = getattr(choices[0], "message", None)
    content = getattr(message, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            text = getattr(item, "text", None)
            if isinstance(text, str):
                parts.append(text)
        return "\n".join(part for part in parts if part)
    return ""


def _map_usage(response) -> tuple[int | None, int | None, int | None]:
    usage = getattr(response, "usage", None)
    if usage is None:
        return None, None, None
    input_tokens = getattr(usage, "prompt_tokens", None)
    output_tokens = getattr(usage, "completion_tokens", None)
    total_tokens = getattr(usage, "total_tokens", None)
    return input_tokens, output_tokens, total_tokens


def execute_azure_request(
    request: ExecutionRequest,
    app_config: AppConfig | None = None,
) -> ExecutionResult:
    """Execute one Azure OpenAI request and normalize the result."""

    if request.app_mode != AppMode.AZURE:
        raise ValueError("Azure OpenAI client only supports azure mode.")

    try:
        config = app_config or load_app_config()
        deployment = _deployment_for_tier(config, request.selected_tier)
    except ConfigurationError:
        return _error_result(
            request,
            request.selected_tier,
            _safe_error(ErrorCategory.CONFIGURATION, "Azure mode configuration is incomplete or invalid.", retryable=False),
        )

    try:
        client = _build_client(config)
        started = perf_counter()
        response = client.chat.completions.create(
            model=deployment,
            messages=[{"role": "user", "content": request.prompt}],
        )
        latency_ms = int(round((perf_counter() - started) * 1000))
        response_text = _extract_message_text(response)
        actual_input_tokens, actual_output_tokens, actual_total_tokens = _map_usage(response)

        value_origins = {
            "response_text": ValueOrigin.ACTUAL,
            "latency_ms": ValueOrigin.ACTUAL,
            "actual_input_tokens": ValueOrigin.ACTUAL if actual_input_tokens is not None else ValueOrigin.UNAVAILABLE,
            "actual_output_tokens": ValueOrigin.ACTUAL if actual_output_tokens is not None else ValueOrigin.UNAVAILABLE,
            "actual_total_tokens": ValueOrigin.ACTUAL if actual_total_tokens is not None else ValueOrigin.UNAVAILABLE,
        }

        return ExecutionResult(
            request_id=request.request_id,
            app_mode=request.app_mode,
            execution_status=ExecutionStatus.SUCCESS,
            executed_tier=request.selected_tier,
            selection_source=request.selection_source,
            response_text=response_text,
            latency_ms=latency_ms,
            actual_input_tokens=actual_input_tokens,
            actual_output_tokens=actual_output_tokens,
            actual_total_tokens=actual_total_tokens,
            value_origins=value_origins,
        )
    except AuthenticationError:
        return _error_result(
            request,
            request.selected_tier,
            _safe_error(ErrorCategory.AUTHENTICATION, "Azure OpenAI authentication failed.", retryable=False),
        )
    except PermissionDeniedError:
        return _error_result(
            request,
            request.selected_tier,
            _safe_error(ErrorCategory.AUTHORIZATION, "Azure OpenAI authorization failed.", retryable=False),
        )
    except RateLimitError:
        return _error_result(
            request,
            request.selected_tier,
            _safe_error(ErrorCategory.RATE_LIMIT, "Azure OpenAI rate limit reached. Try again later.", retryable=True),
        )
    except APITimeoutError:
        return _error_result(
            request,
            request.selected_tier,
            _safe_error(ErrorCategory.TIMEOUT, "Azure OpenAI request timed out.", retryable=True),
        )
    except APIConnectionError:
        return _error_result(
            request,
            request.selected_tier,
            _safe_error(ErrorCategory.NETWORK, "Azure OpenAI network connection failed.", retryable=True),
        )
    except (NotFoundError, BadRequestError):
        return _error_result(
            request,
            request.selected_tier,
            _safe_error(ErrorCategory.DEPLOYMENT_UNAVAILABLE, "Requested Azure OpenAI deployment is unavailable.", retryable=False),
        )
    except APIError:
        return _error_result(
            request,
            request.selected_tier,
            _safe_error(ErrorCategory.SERVICE, "Azure OpenAI service request failed.", retryable=True),
        )
    except Exception:
        return _error_result(
            request,
            request.selected_tier,
            _safe_error(ErrorCategory.UNKNOWN, "Azure OpenAI request failed unexpectedly.", retryable=False),
        )
