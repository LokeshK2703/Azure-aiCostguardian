"""Local request orchestration for demo-mode MVP execution."""

from __future__ import annotations

from pathlib import Path

from config import AppConfig, load_app_config, validate_pricing_for_mode
from models.enums import AppMode, ErrorCategory, ExecutionStatus, LogicalTier, SelectionSource, ValueOrigin
from models.request_models import AnalysisRequest, ExecutionRequest, PromptRequest
from models.response_models import CostComparison, ExecutionResult, OrchestrationResult, SafeError, TelemetryRecord
from services.cost_calculator import apply_actual_usage, estimate_costs
from services.azure_openai_client import execute_azure_request
from services.demo_responder import generate_demo_response
from services.model_router import recommend_tier, resolve_executed_tier
from services.prompt_analyzer import analyze_prompt
from services.telemetry import persist_telemetry
from services.token_estimator import estimate_tokens


def _validate_user_selected_tier(user_selected_tier: LogicalTier | str | None) -> LogicalTier | None:
    if user_selected_tier is None:
        return None
    if isinstance(user_selected_tier, LogicalTier):
        return user_selected_tier
    try:
        return LogicalTier(user_selected_tier)
    except ValueError as exc:
        raise ValueError("Selected logical tier is invalid.") from exc


def _default_configured_tiers(app_mode: AppMode, app_config: AppConfig) -> set[LogicalTier]:
    if app_mode == AppMode.DEMO:
        return set(LogicalTier)

    runtime = app_config.runtime
    configured: set[LogicalTier] = set()
    if runtime.DEPLOYMENT_ECONOMY.strip():
        configured.add(LogicalTier.ECONOMY)
    if runtime.DEPLOYMENT_BALANCED.strip():
        configured.add(LogicalTier.BALANCED)
    if runtime.DEPLOYMENT_ADVANCED.strip():
        configured.add(LogicalTier.ADVANCED)
    return configured


def _build_value_origins(costs: CostComparison, execution: ExecutionResult) -> dict[str, ValueOrigin]:
    estimated_origin = costs.estimated_value_origin
    actual_origin = costs.actual_value_origin
    value_origins = dict(execution.value_origins)
    value_origins.update(
        {
            "estimated_input_tokens": ValueOrigin.ESTIMATED,
            "estimated_output_tokens": ValueOrigin.ESTIMATED,
            "estimated_total_tokens": ValueOrigin.ESTIMATED,
            "estimated_baseline_cost": estimated_origin,
            "estimated_routed_cost": estimated_origin,
            "estimated_savings_amount": estimated_origin,
            "estimated_savings_percentage": estimated_origin,
            "actual_baseline_cost": actual_origin,
            "actual_routed_cost": actual_origin,
            "actual_savings_amount": actual_origin,
            "actual_savings_percentage": actual_origin,
        }
    )
    return value_origins


def _blocked_execution_result(
    *,
    request_id,
    app_mode: AppMode,
    executed_tier: LogicalTier,
    selection_source: SelectionSource,
    error_category: ErrorCategory,
    message: str,
) -> ExecutionResult:
    return ExecutionResult(
        request_id=request_id,
        app_mode=app_mode,
        execution_status=ExecutionStatus.BLOCKED,
        executed_tier=executed_tier,
        selection_source=selection_source,
        error=SafeError(category=error_category, message=message, retryable=False),
        value_origins={
            "actual_input_tokens": ValueOrigin.UNAVAILABLE,
            "actual_output_tokens": ValueOrigin.UNAVAILABLE,
            "actual_total_tokens": ValueOrigin.UNAVAILABLE,
            "latency_ms": ValueOrigin.UNAVAILABLE,
        },
    )


def execute_request(
    prompt_request: PromptRequest,
    *,
    user_selected_tier: LogicalTier | str | None = None,
    app_config: AppConfig | None = None,
    configured_tiers: set[LogicalTier] | None = None,
    telemetry_file_path: str | Path | None = None,
) -> OrchestrationResult:
    """Execute the local MVP request pipeline with demo-mode response generation."""

    config = app_config or load_app_config(allow_unverified_pricing_preview=True)
    validate_pricing_for_mode(
        config.model_pricing,
        prompt_request.app_mode,
        allow_unverified_pricing_preview=prompt_request.app_mode == AppMode.DEMO,
    )

    selected_tier = _validate_user_selected_tier(user_selected_tier)
    available_tiers = configured_tiers or _default_configured_tiers(prompt_request.app_mode, config)

    seed_analysis = analyze_prompt(AnalysisRequest(prompt_request=prompt_request), config.routing_policy)
    token_estimate = estimate_tokens(prompt_request, config.routing_policy, seed_analysis.task_category)
    prompt_analysis = analyze_prompt(
        AnalysisRequest(
            prompt_request=prompt_request,
            estimated_input_tokens=token_estimate.estimated_input_tokens,
        ),
        config.routing_policy,
    )

    routing_decision = recommend_tier(
        prompt_analysis,
        token_estimate,
        config.routing_policy,
        configured_tiers=available_tiers,
    )

    resolved_tier, selection_source, resolution_status, resolution_message, _ = resolve_executed_tier(
        routing_decision.recommended_tier,
        selected_tier,
        configured_tiers=available_tiers,
        require_configured=True,
    )

    executed_tier = resolved_tier or routing_decision.recommended_tier
    actual_selection_source = selection_source or SelectionSource.RECOMMENDATION
    routing_decision.executed_tier = executed_tier
    routing_decision.selection_source = actual_selection_source
    routing_decision.execution_status = resolution_status
    if resolution_status == ExecutionStatus.BLOCKED:
        routing_decision.error_category = ErrorCategory.DEPLOYMENT_UNAVAILABLE
        routing_decision.error_message = resolution_message

    if resolution_status == ExecutionStatus.BLOCKED:
        execution_result = _blocked_execution_result(
            request_id=prompt_request.request_id,
            app_mode=prompt_request.app_mode,
            executed_tier=executed_tier,
            selection_source=actual_selection_source,
            error_category=ErrorCategory.DEPLOYMENT_UNAVAILABLE,
            message=resolution_message or "Recommended logical tier is not configured.",
        )
    elif prompt_request.app_mode == AppMode.AZURE:
        execution_result = execute_azure_request(
            ExecutionRequest(
                request_id=prompt_request.request_id,
                prompt=prompt_request.prompt,
                app_mode=prompt_request.app_mode,
                selected_tier=executed_tier,
                selection_source=actual_selection_source,
            ),
            app_config=config,
        )
    else:
        execution_result = generate_demo_response(
            ExecutionRequest(
                request_id=prompt_request.request_id,
                prompt=prompt_request.prompt,
                app_mode=prompt_request.app_mode,
                selected_tier=executed_tier,
                selection_source=actual_selection_source,
            )
        )

    cost_comparison = estimate_costs(token_estimate, config.model_pricing, executed_tier)
    cost_comparison = apply_actual_usage(
        cost_comparison,
        config.model_pricing,
        executed_tier,
        execution_result.actual_input_tokens,
        execution_result.actual_output_tokens,
    )

    telemetry_record = TelemetryRecord(
        request_id=prompt_request.request_id,
        app_mode=prompt_request.app_mode,
        prompt_character_count=prompt_analysis.prompt_character_count,
        task_category=prompt_analysis.task_category,
        complexity_score=prompt_analysis.adjusted_complexity_score,
        complexity_level=prompt_analysis.complexity_level,
        complexity_factors=prompt_analysis.complexity_factors,
        token_estimation_method=token_estimate.method,
        estimated_input_tokens=token_estimate.estimated_input_tokens,
        estimated_output_tokens=token_estimate.estimated_output_tokens,
        estimated_total_tokens=token_estimate.estimated_total_tokens,
        actual_input_tokens=execution_result.actual_input_tokens,
        actual_output_tokens=execution_result.actual_output_tokens,
        actual_total_tokens=execution_result.actual_total_tokens,
        recommended_tier=routing_decision.recommended_tier,
        executed_tier=executed_tier,
        selection_source=actual_selection_source,
        estimated_baseline_cost=cost_comparison.estimated_baseline_cost,
        estimated_routed_cost=cost_comparison.estimated_routed_cost,
        estimated_savings_amount=cost_comparison.estimated_savings_amount,
        estimated_savings_percentage=cost_comparison.estimated_savings_percentage,
        actual_baseline_cost=cost_comparison.actual_baseline_cost,
        actual_routed_cost=cost_comparison.actual_routed_cost,
        actual_savings_amount=cost_comparison.actual_savings_amount,
        actual_savings_percentage=cost_comparison.actual_savings_percentage,
        latency_ms=execution_result.latency_ms,
        execution_status=execution_result.execution_status,
        error_category=execution_result.error.category if execution_result.error else None,
        value_origins=_build_value_origins(cost_comparison, execution_result),
    )

    persist_telemetry(
        telemetry_record,
        file_path=telemetry_file_path or config.runtime.TELEMETRY_FILE_PATH,
        max_records=config.runtime.TELEMETRY_MAX_RECORDS,
        retention_days=config.runtime.TELEMETRY_RETENTION_DAYS,
    )

    warnings = list(config.warnings)
    return OrchestrationResult(
        request_id=prompt_request.request_id,
        prompt_analysis=prompt_analysis,
        routing_decision=routing_decision,
        token_estimate=token_estimate,
        cost_comparison=cost_comparison,
        execution_result=execution_result,
        telemetry_record=telemetry_record,
        warnings=warnings,
    )
