"""Configuration loading and validation for Azure AI Cost Guardian.

Prompt 2 scope:
- Validated runtime settings
- Routing policy loading with embedded safe defaults
- Model pricing loading and validation
- No network calls, Azure checks, or deployment availability checks
"""

from __future__ import annotations

import json
from decimal import Decimal
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from models.enums import AppMode, ComplexityLevel, LogicalTier, TaskCategory


class ConfigurationError(Exception):
    """Safe configuration error for user-displayable diagnostics."""


class ComplexityThresholds(BaseModel):
    """Routing boundaries for complexity level transitions."""

    low_to_medium: float = Field(ge=0.0, le=10.0)
    medium_to_high: float = Field(ge=0.0, le=10.0)

    @model_validator(mode="after")
    def validate_order(self) -> "ComplexityThresholds":
        if self.low_to_medium >= self.medium_to_high:
            raise ValueError("Complexity thresholds are out of order.")
        return self


class ComplexityFactorWeights(BaseModel):
    """Weights for complexity score factors; must sum to 1.0."""

    task_prior: float = Field(ge=0.0)
    prompt_length: float = Field(ge=0.0)
    requested_operations: float = Field(ge=0.0)
    multi_step: float = Field(ge=0.0)
    reasoning_terminology: float = Field(ge=0.0)
    architecture_security_terminology: float = Field(ge=0.0)
    code_generation_indicators: float = Field(ge=0.0)
    requested_output_size: float = Field(ge=0.0)
    requested_output_structure: float = Field(ge=0.0)

    @model_validator(mode="after")
    def validate_sum(self) -> "ComplexityFactorWeights":
        total = (
            self.task_prior
            + self.prompt_length
            + self.requested_operations
            + self.multi_step
            + self.reasoning_terminology
            + self.architecture_security_terminology
            + self.code_generation_indicators
            + self.requested_output_size
            + self.requested_output_structure
        )
        if abs(total - 1.0) > 1e-6:
            raise ValueError("Complexity factor weights must sum to 1.0.")
        return self


class InputLimits(BaseModel):
    """Prompt and token guardrails for the MVP."""

    max_prompt_characters: int = Field(gt=0)
    max_estimated_input_tokens: int = Field(gt=0)
    max_estimated_output_tokens: int = Field(gt=0)


class ConfidencePolicy(BaseModel):
    """Configurable constants for routing-confidence adjustments."""

    base_confidence: int = Field(ge=0, le=100)
    minimum_confidence: int = Field(ge=0, le=100)
    maximum_confidence: int = Field(ge=0, le=100)
    boundary_window: float = Field(gt=0.0)
    short_prompt_threshold_characters: int = Field(gt=0)
    boundary_penalty: int
    short_or_ambiguous_penalty: int
    character_fallback_penalty: int
    strong_agreement_bonus: int

    @model_validator(mode="after")
    def validate_confidence_order(self) -> "ConfidencePolicy":
        if not (self.minimum_confidence <= self.base_confidence <= self.maximum_confidence):
            raise ValueError("Confidence min/base/max ordering is invalid.")
        return self


class RoutingPolicy(BaseModel):
    """Versioned routing-policy configuration."""

    schema_version: Literal["1.0"]
    complexity_thresholds: ComplexityThresholds
    task_category_priors: dict[TaskCategory, float]
    complexity_factor_weights: ComplexityFactorWeights
    minimum_complexity_by_task: dict[TaskCategory, ComplexityLevel]
    output_token_ratios_by_task: dict[TaskCategory, float]
    input_limits: InputLimits
    confidence_policy: ConfidencePolicy

    @model_validator(mode="after")
    def validate_ranges(self) -> "RoutingPolicy":
        required_tasks = set(TaskCategory)

        if set(self.task_category_priors.keys()) != required_tasks:
            raise ValueError("task_category_priors must contain all task categories.")

        if set(self.output_token_ratios_by_task.keys()) != required_tasks:
            raise ValueError("output_token_ratios_by_task must contain all task categories.")

        for prior in self.task_category_priors.values():
            if not 0.0 <= prior <= 1.0:
                raise ValueError("Task category priors must be between 0.0 and 1.0.")

        for ratio in self.output_token_ratios_by_task.values():
            if ratio <= 0:
                raise ValueError("Output token ratios must be greater than zero.")

        mandatory_minimums = {
            TaskCategory.ARCHITECTURE_DESIGN: ComplexityLevel.MEDIUM,
            TaskCategory.CODE_GENERATION: ComplexityLevel.MEDIUM,
        }
        for task, expected_level in mandatory_minimums.items():
            if self.minimum_complexity_by_task.get(task) != expected_level:
                raise ValueError("minimum_complexity_by_task missing required policy floors.")

        return self


class TierPricing(BaseModel):
    """Pricing details per logical tier."""

    display_name: str = Field(min_length=1)
    model_family_hint: str = Field(min_length=1)
    input_price_per_million_tokens: Decimal | None = None
    output_price_per_million_tokens: Decimal | None = None
    effective_date_note: str = Field(min_length=1)

    @field_validator("input_price_per_million_tokens", "output_price_per_million_tokens")
    @classmethod
    def validate_non_negative_if_set(cls, value: Decimal | None) -> Decimal | None:
        if value is not None and value < 0:
            raise ValueError("Pricing values must be non-negative when provided.")
        return value


class ModelPricing(BaseModel):
    """Versioned model-pricing configuration."""

    schema_version: Literal["1.0"]
    currency: str = Field(min_length=1)
    baseline_tier: LogicalTier
    pricing_note: str = Field(min_length=1)
    tiers: dict[LogicalTier, TierPricing]

    @model_validator(mode="after")
    def validate_tiers(self) -> "ModelPricing":
        required_tiers = set(LogicalTier)
        present_tiers = set(self.tiers.keys())
        if required_tiers != present_tiers:
            raise ValueError("Model pricing must define economy, balanced, and advanced tiers.")
        if self.baseline_tier not in self.tiers:
            raise ValueError("baseline_tier must exist in tiers.")
        return self


class RuntimeSettings(BaseSettings):
    """Runtime settings sourced from environment variables."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    APP_MODE: AppMode = AppMode.DEMO
    AZURE_OPENAI_ENDPOINT: str = ""
    AZURE_OPENAI_API_VERSION: str = ""
    AZURE_OPENAI_API_KEY: str = ""
    AZURE_OPENAI_AUTH_MODE: str = "api_key"
    AZURE_OPENAI_TIMEOUT_SECONDS: int = Field(default=60, gt=0)

    DEPLOYMENT_ECONOMY: str = ""
    DEPLOYMENT_BALANCED: str = ""
    DEPLOYMENT_ADVANCED: str = ""

    BASELINE_TIER: LogicalTier = LogicalTier.ADVANCED

    TELEMETRY_FILE_PATH: str = "data/telemetry.json"
    TELEMETRY_MAX_RECORDS: int = Field(default=1000, gt=0)
    TELEMETRY_RETENTION_DAYS: int = Field(default=30, gt=0)

    LOG_LEVEL: str = "INFO"

    STORE_RAW_CONTENT: bool = False

    @field_validator("AZURE_OPENAI_AUTH_MODE")
    @classmethod
    def validate_auth_mode(cls, value: str) -> str:
        valid = {"api_key", "entra"}
        if value not in valid:
            raise ValueError("AZURE_OPENAI_AUTH_MODE must be 'api_key' or 'entra'.")
        return value

    @field_validator("STORE_RAW_CONTENT")
    @classmethod
    def validate_store_raw_content(cls, value: bool) -> bool:
        if value:
            raise ValueError("STORE_RAW_CONTENT=true is not allowed in this MVP.")
        return value

    @model_validator(mode="after")
    def validate_mode_requirements(self) -> "RuntimeSettings":
        if self.APP_MODE == AppMode.AZURE:
            missing: list[str] = []
            required: dict[str, str] = {
                "AZURE_OPENAI_ENDPOINT": self.AZURE_OPENAI_ENDPOINT,
                "AZURE_OPENAI_API_VERSION": self.AZURE_OPENAI_API_VERSION,
                "DEPLOYMENT_ECONOMY": self.DEPLOYMENT_ECONOMY,
                "DEPLOYMENT_BALANCED": self.DEPLOYMENT_BALANCED,
                "DEPLOYMENT_ADVANCED": self.DEPLOYMENT_ADVANCED,
            }
            # API key only required for key-based auth
            if self.AZURE_OPENAI_AUTH_MODE == "api_key":
                required["AZURE_OPENAI_API_KEY"] = self.AZURE_OPENAI_API_KEY

            for key, value in required.items():
                if not value.strip():
                    missing.append(key)

            if missing:
                joined = ", ".join(sorted(missing))
                raise ValueError(f"Missing required Azure configuration: {joined}")

        return self


class AppConfig(BaseModel):
    """Combined configuration payload for application startup."""

    runtime: RuntimeSettings
    routing_policy: RoutingPolicy
    model_pricing: ModelPricing
    warnings: list[str] = Field(default_factory=list)


DEFAULT_ROUTING_POLICY_DATA: dict[str, Any] = {
    "schema_version": "1.0",
    "complexity_thresholds": {
        "low_to_medium": 4.0,
        "medium_to_high": 7.0,
    },
    "task_category_priors": {
        "summarization": 0.2,
        "email": 0.25,
        "documentation": 0.45,
        "technical_explanation": 0.55,
        "architecture_design": 0.7,
        "code_generation": 0.7,
        "general_qa": 0.35,
    },
    "complexity_factor_weights": {
        "task_prior": 0.18,
        "prompt_length": 0.16,
        "requested_operations": 0.12,
        "multi_step": 0.1,
        "reasoning_terminology": 0.12,
        "architecture_security_terminology": 0.1,
        "code_generation_indicators": 0.12,
        "requested_output_size": 0.05,
        "requested_output_structure": 0.05,
    },
    "minimum_complexity_by_task": {
        "architecture_design": "medium",
        "code_generation": "medium",
    },
    "output_token_ratios_by_task": {
        "summarization": 0.25,
        "email": 0.35,
        "documentation": 0.6,
        "technical_explanation": 0.7,
        "architecture_design": 0.9,
        "code_generation": 1.1,
        "general_qa": 0.4,
    },
    "input_limits": {
        "max_prompt_characters": 30000,
        "max_estimated_input_tokens": 8000,
        "max_estimated_output_tokens": 2000,
    },
    "confidence_policy": {
        "base_confidence": 85,
        "minimum_confidence": 40,
        "maximum_confidence": 95,
        "boundary_window": 0.5,
        "short_prompt_threshold_characters": 40,
        "boundary_penalty": -20,
        "short_or_ambiguous_penalty": -15,
        "character_fallback_penalty": -10,
        "strong_agreement_bonus": 5,
    },
}


def _read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as file:
        loaded = json.load(file)
    if not isinstance(loaded, dict):
        raise ConfigurationError(f"Configuration file is not a JSON object: {path}")
    return loaded


def load_routing_policy(path: Path | str = "config/routing_policy.json") -> tuple[RoutingPolicy, list[str]]:
    """Load routing policy from JSON; fallback to embedded defaults if needed."""

    warnings: list[str] = []
    policy_path = Path(path)

    try:
        data = _read_json(policy_path)
        return RoutingPolicy.model_validate(data), warnings
    except FileNotFoundError:
        warnings.append("Routing policy file missing; embedded defaults were applied.")
    except json.JSONDecodeError:
        warnings.append("Routing policy file is malformed JSON; embedded defaults were applied.")
    except ValidationError:
        warnings.append("Routing policy failed validation; embedded defaults were applied.")
    except ConfigurationError:
        warnings.append("Routing policy file format invalid; embedded defaults were applied.")

    try:
        return RoutingPolicy.model_validate(DEFAULT_ROUTING_POLICY_DATA), warnings
    except ValidationError as exc:
        raise ConfigurationError("Embedded routing policy defaults are invalid.") from exc


def load_model_pricing(path: Path | str = "config/model_pricing.json") -> ModelPricing:
    """Load and validate model-pricing configuration."""

    pricing_path = Path(path)

    try:
        data = _read_json(pricing_path)
    except FileNotFoundError as exc:
        raise ConfigurationError("Model pricing configuration file is missing.") from exc
    except json.JSONDecodeError as exc:
        raise ConfigurationError("Model pricing configuration file is malformed JSON.") from exc

    try:
        return ModelPricing.model_validate(data)
    except ValidationError as exc:
        raise ConfigurationError("Model pricing configuration validation failed.") from exc


def validate_pricing_for_mode(
    pricing: ModelPricing,
    app_mode: AppMode,
    allow_unverified_pricing_preview: bool = False,
) -> None:
    """Validate whether null pricing is allowed for the selected mode."""

    if allow_unverified_pricing_preview:
        return

    has_null_pricing = any(
        tier.input_price_per_million_tokens is None or tier.output_price_per_million_tokens is None
        for tier in pricing.tiers.values()
    )

    if app_mode == AppMode.AZURE and has_null_pricing:
        raise ConfigurationError(
            "Azure Mode requires verified numeric pricing values for all tiers."
        )


def load_runtime_settings() -> RuntimeSettings:
    """Load and validate runtime environment settings."""

    try:
        return RuntimeSettings()
    except ValidationError as exc:
        raise ConfigurationError("Runtime settings validation failed.") from exc


def load_app_config(
    routing_policy_path: Path | str = "config/routing_policy.json",
    pricing_path: Path | str = "config/model_pricing.json",
    allow_unverified_pricing_preview: bool = False,
) -> AppConfig:
    """Load full application configuration with safe validation behavior."""

    runtime = load_runtime_settings()
    routing_policy, warnings = load_routing_policy(routing_policy_path)
    model_pricing = load_model_pricing(pricing_path)
    validate_pricing_for_mode(
        pricing=model_pricing,
        app_mode=runtime.APP_MODE,
        allow_unverified_pricing_preview=allow_unverified_pricing_preview,
    )

    if runtime.BASELINE_TIER != model_pricing.baseline_tier:
        raise ConfigurationError(
            "BASELINE_TIER must match baseline_tier in model_pricing.json."
        )

    return AppConfig(
        runtime=runtime,
        routing_policy=routing_policy,
        model_pricing=model_pricing,
        warnings=warnings,
    )
