"""Customer-facing UI presentation helpers."""
