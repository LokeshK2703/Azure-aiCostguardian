"""Pure presentation helpers for customer-facing UI labels and explanations."""

from __future__ import annotations

from collections.abc import Iterable

from models.enums import AppMode, ComplexityLevel, ExecutionStatus, LogicalTier, SelectionSource, TaskCategory
from models.response_models import CostComparison, ExecutionResult, PromptAnalysis

TASK_CATEGORY_LABELS: dict[TaskCategory, str] = {
    TaskCategory.SUMMARIZATION: "summarization",
    TaskCategory.EMAIL: "email drafting",
    TaskCategory.DOCUMENTATION: "documentation",
    TaskCategory.TECHNICAL_EXPLANATION: "technical explanation",
    TaskCategory.ARCHITECTURE_DESIGN: "architecture design",
    TaskCategory.CODE_GENERATION: "code generation",
    TaskCategory.GENERAL_QA: "general question",
}

TIER_LABELS: dict[LogicalTier, str] = {
    LogicalTier.ECONOMY: "Cost-efficient capability",
    LogicalTier.BALANCED: "Standard capability",
    LogicalTier.ADVANCED: "Premium reasoning capability",
}

COMPLEXITY_LABELS: dict[ComplexityLevel, str] = {
    ComplexityLevel.LOW: "Routine",
    ComplexityLevel.MEDIUM: "Moderate",
    ComplexityLevel.HIGH: "Complex",
}

MODE_LABELS: dict[AppMode, str] = {
    AppMode.DEMO: "Demo",
    AppMode.AZURE: "Azure",
}

MODE_MESSAGES: dict[AppMode, str] = {
    AppMode.DEMO: "Demo Mode: Results are generated locally using deterministic examples. No live AI service is called.",
    AppMode.AZURE: "Azure Mode: Requests are routed to live Azure OpenAI deployments using intelligent complexity analysis.",
}

OPTIMIZATION_MESSAGES: dict[LogicalTier, tuple[str, str]] = {
    LogicalTier.ECONOMY: (
        "Optimized for efficiency",
        "This request is routine and well-defined. Cost Guardian selected a cost-efficient capability instead of using premium reasoning unnecessarily.",
    ),
    LogicalTier.BALANCED: (
        "Balanced for quality and cost",
        "This request needs moderate reasoning. Cost Guardian selected a balanced capability without consuming premium capacity unnecessarily.",
    ),
    LogicalTier.ADVANCED: (
        "Premium capability justified",
        "This request includes complex or risk-sensitive requirements. Cost Guardian selected stronger reasoning because premium capability is justified for this workload.",
    ),
}

ADMIN_OVERRIDE_LABELS = [
    "Automatic selection",
    "Cost-efficient capability",
    "Standard capability",
    "Premium reasoning capability",
]


def mode_label(mode: AppMode) -> str:
    return MODE_LABELS[mode]


def mode_message(mode: AppMode) -> str:
    return MODE_MESSAGES[mode]


def optimization_explanation(tier: LogicalTier) -> tuple[str, str]:
    return OPTIMIZATION_MESSAGES[tier]


def selected_capability_from_label(label: str) -> LogicalTier | None:
    if label == "Automatic selection":
        return None
    for tier, tier_label in TIER_LABELS.items():
        if label == tier_label:
            return tier
    return None


def admin_control_labels() -> list[str]:
    return list(ADMIN_OVERRIDE_LABELS)


def workload_type_label(task_category: TaskCategory) -> str:
    return TASK_CATEGORY_LABELS[task_category]


def complexity_descriptor(level: ComplexityLevel) -> str:
    return COMPLEXITY_LABELS[level]


def _factor_value(analysis: PromptAnalysis, name: str) -> float:
    for factor in analysis.complexity_factors:
        if factor.name == name and factor.normalized_value is not None:
            return float(factor.normalized_value)
    return 0.0


def optimization_reasons(analysis: PromptAnalysis, recommended_tier: LogicalTier) -> list[str]:
    reasons: list[str] = []
    arch_signal = _factor_value(analysis, "architecture_security")
    multi_step_signal = _factor_value(analysis, "multi_step")
    operations_signal = _factor_value(analysis, "requested_operations")
    structure_signal = _factor_value(analysis, "requested_output_structure")

    if recommended_tier == LogicalTier.ECONOMY:
        reasons.append("Routine and clearly defined task")
        reasons.append("Detailed technical analysis requested" if structure_signal >= 0.25 else "Limited reasoning required")
        if structure_signal >= 0.25:
            reasons.append("Detailed technical analysis requested")
    else:
        if analysis.task_category == TaskCategory.TECHNICAL_EXPLANATION:
            reasons.append("Detailed technical analysis requested")
        if analysis.task_category == TaskCategory.CODE_GENERATION:
            reasons.append("Software development requested")
        if analysis.task_category == TaskCategory.ARCHITECTURE_DESIGN:
            reasons.append("Multiple technical requirements detected")
        if arch_signal >= 0.25 or any("compliance" in rule.lower() for rule in analysis.applied_policy_rules):
            reasons.append("Security requirements detected")
        if arch_signal >= 0.25:
            reasons.append("Identity or governance requirements detected")
            reasons.append("Compliance considerations detected")
        if any(term in " ".join(analysis.applied_policy_rules).lower() for term in ["multi-region", "disaster recovery"]):
            reasons.append("Multi-region or recovery planning requested")
        if multi_step_signal >= 0.25 or operations_signal >= 0.35:
            reasons.append("Multiple technical requirements detected")
        if structure_signal >= 0.25:
            reasons.append("Detailed technical analysis requested")

        if not reasons:
            reasons.append("Detailed technical analysis requested")

    ordered: list[str] = []
    for reason in reasons:
        if reason not in ordered:
            ordered.append(reason)
    return ordered[:3]


def pricing_available(cost_comparison: CostComparison) -> bool:
    return cost_comparison.estimated_routed_cost is not None and cost_comparison.estimated_baseline_cost is not None


def pricing_unavailable_caption() -> str:
    return "Monetary savings will appear after approved pricing is configured."


def response_banner_text(execution_result: ExecutionResult) -> str:
    if execution_result.app_mode == AppMode.DEMO:
        return "Demonstration result."
    return "Demonstration result."


def response_text_for_display(execution_result: ExecutionResult) -> str:
    text = execution_result.response_text or "No response generated."
    if execution_result.app_mode != AppMode.DEMO:
        return text

    lines = [line for line in text.splitlines() if line.strip()]
    if lines and lines[0].strip() == "Demo Mode Synthetic Response":
        remaining = "\n".join(lines[1:]).strip()
        return remaining or "Simulated demo response generated successfully."
    return text


def execution_status_label(status: ExecutionStatus) -> str:
    return status.value.replace("_", " ").title()


def selection_source_label(selection_source: SelectionSource | None) -> str:
    if selection_source == SelectionSource.USER_OVERRIDE:
        return "user_override"
    if selection_source == SelectionSource.RECOMMENDATION:
        return "recommendation"
    return "not_started"


def safe_text_list(values: Iterable[str]) -> list[str]:
    return [value for value in values if value]
